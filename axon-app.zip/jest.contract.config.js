// Contract tests: the app's real API code against the real supabase/schema.sql (run by test/contract/server.mjs).
module.exports = {
  preset: 'jest-expo',
  testEnvironment: 'node',
  testMatch: ['<rootDir>/test/contract/*.test.ts'],
  testTimeout: 60000,
};
