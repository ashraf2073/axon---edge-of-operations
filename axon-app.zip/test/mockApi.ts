/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Test doubles for src/api/* and src/lib/supabase, backed by test/fakeBackend.
 * They are typed against the real modules, so if a real function changes shape
 * the type-check of the test folder fails and the double is updated with it.
 */
import { AppError } from '../src/lib/errors';
import type * as AccountReal from '../src/api/account';
import type * as CustomerReal from '../src/api/customer';
import type * as OwnerReal from '../src/api/owner';
import type { Analytics, Expense, Feedback, Order, OrderItem, Product, Sale } from '../src/types';
import { backend, emitAuth, nextId } from './fakeBackend';

const NOW = () => new Date().toISOString();
const round2 = (n: number) => Math.round(n * 100) / 100;
const need = <T>(v: T | undefined | null, msg: string): T => {
  if (v === undefined || v === null) throw new AppError(msg);
  return v;
};
const uid = () => need(backend.session?.user.id, 'Sign in first');
const netError = () => new Error('Network request failed');

/** While the pretend connection is down, every call fails the way a real one does. */
function guard<T extends Record<string, (...args: any[]) => Promise<any>>>(api: T): T {
  const out: Record<string, unknown> = {};
  for (const [name, fn] of Object.entries(api)) {
    out[name] = async (...args: unknown[]) => {
      if (backend.offline) throw netError();
      return fn(...args);
    };
  }
  return out as T;
}

/** The cloud does the work but the reply is lost on the way back (a weak signal). */
function maybeLoseReply() {
  if (backend.loseNextReply) {
    backend.loseNextReply = false;
    throw netError();
  }
}
const ownsStore = (storeId: string) => backend.stores.some((s) => s.id === storeId && s.owner_id === uid());
const code = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;

// ---------------------------------------------------------------- supabase

const channelStub: any = { on: () => channelStub, subscribe: () => channelStub };

export const supabase: any = {
  auth: {
    getSession: async () => {
      if (backend.offline && backend.tokenExpired) {
        return { data: { session: null }, error: { name: 'AuthRetryableFetchError', message: 'Network request failed' } };
      }
      return { data: { session: backend.session }, error: null };
    },
    onAuthStateChange: (cb: (e: string, s: unknown) => void) => {
      backend.listeners.add(cb as any);
      setTimeout(() => cb('INITIAL_SESSION', backend.session), 0);
      return { data: { subscription: { unsubscribe: () => backend.listeners.delete(cb as any) } } };
    },
    signOut: async (opts?: { scope?: string }) => {
      backend.lastSignOutScope = opts?.scope ?? 'global';
      backend.session = null;
      emitAuth('SIGNED_OUT');
      return { error: null };
    },
    startAutoRefresh: async () => undefined,
    stopAutoRefresh: async () => undefined,
  },
  from: (table: string) => {
    if (table !== 'axon_profiles') throw new Error(`fake supabase: table ${table} is not faked`);
    let patch: Record<string, unknown> | null = null;
    let id: string | null = null;
    const api: any = {
      select: () => api,
      update: (p: Record<string, unknown>) => {
        patch = p;
        return api;
      },
      eq: (_col: string, value: string) => {
        id = value;
        return api;
      },
      maybeSingle: async () =>
        backend.offline
          ? { data: null, error: { message: 'TypeError: Network request failed' } }
          : { data: backend.profiles.find((p) => p.id === id) ?? null, error: null },
      then: (resolve: (v: unknown) => unknown, reject: (e: unknown) => unknown) => {
        const row = backend.profiles.find((p) => p.id === id);
        if (patch && row) Object.assign(row, patch);
        return Promise.resolve({ data: null, error: null }).then(resolve, reject);
      },
    };
    return api;
  },
  channel: () => channelStub,
  removeChannel: async () => 'ok',
  storage: {
    from: () => ({
      list: async () => ({ data: [], error: null }),
      remove: async () => ({ data: [], error: null }),
      upload: async () => ({ data: {}, error: null }),
      getPublicUrl: (p: string) => ({ data: { publicUrl: `https://cdn.test/${p}` } }),
    }),
  },
};

// ----------------------------------------------------------------- account

export const accountApi: typeof AccountReal = guard({
  signUp: async (input) => {
    if (backend.accounts.some((a) => a.email === input.email.trim().toLowerCase())) {
      throw new AppError('An account with this email already exists. Try logging in instead.');
    }
    const id = nextId(input.role);
    backend.accounts.push({ id, email: input.email.trim().toLowerCase(), password: input.password });
    backend.profiles.push({
      id,
      role: input.role,
      full_name: input.fullName.trim(),
      phone: input.phone.trim(),
      email: input.email.trim().toLowerCase(),
      date_format: 'DD/MM/YYYY',
      consent_at: null,
      consent_contact: false,
    });
    return { needsConfirmation: false };
  },
  passwordLogin: async (email, password) => {
    const acc = backend.accounts.find((a) => a.email === email.trim().toLowerCase());
    if (!acc || acc.password !== password) throw new AppError('Wrong email or password.');
    backend.session = { user: { id: acc.id, email: acc.email } };
    emitAuth('SIGNED_IN');
  },
  changePassword: async (pw) => {
    const acc = backend.accounts.find((a) => a.id === uid());
    if (acc) acc.password = pw;
  },
  updateProfile: async (userId, patch) => {
    const row = backend.profiles.find((p) => p.id === userId);
    if (row) Object.assign(row, patch);
  },
  requestResetCode: async (email) => {
    if (backend.offline) throw new AppError('No internet connection. Check your data or Wi-Fi and try again.');
    const e = email.trim().toLowerCase();
    // like the real service, the answer is the same whether or not the email has an account
    if (backend.accounts.some((a) => a.email === e)) backend.resetCodes[e] = '123456';
  },
  resetWithCode: async (email, code, newPassword) => {
    if (backend.offline) throw new AppError('No internet connection. Check your data or Wi-Fi and try again.');
    const e = email.trim().toLowerCase();
    const acc = backend.accounts.find((a) => a.email === e);
    if (!acc || backend.resetCodes[e] !== code.replace(/\s+/g, '')) {
      throw new AppError('That code is wrong or has expired. Check the newest email, or ask for a new code.');
    }
    // the real service logs the person in for a moment once the code checks out
    backend.session = { user: { id: acc.id, email: acc.email } };
    emitAuth('SIGNED_IN');
    await new Promise((r) => setTimeout(r, 30));
    acc.password = newPassword;
    delete backend.resetCodes[e];
    backend.session = null;
    emitAuth('SIGNED_OUT');
  },
  submitFeedback: async (input) => {
    backend.feedback.push({
      id: nextId('fb'),
      user_id: uid(),
      type: input.type,
      priority: input.priority,
      message: input.message.trim(),
      status: 'new',
      role: backend.profiles.find((p) => p.id === uid())?.role ?? '',
      store_name: '',
      created_at: NOW(),
    });
  },
  myFeedback: async () => backend.feedback.filter((f) => f.user_id === uid()) as Feedback[],
  adminCall: async <T = unknown>(c: string, action: string, args: Record<string, unknown> = {}): Promise<T> => {
    if (c !== backend.adminCode) throw new AppError('Wrong passcode.');
    switch (action) {
      case 'login':
        return undefined as T;
      case 'stats':
        return {
          owners: backend.profiles.filter((p) => p.role === 'owner').length,
          customers: backend.profiles.filter((p) => p.role === 'customer').length,
          stores: backend.stores.length,
          products: backend.products.length,
          orders: backend.orders.length,
          feedback: backend.feedback.reduce<Record<string, number>>((m, f) => ({ ...m, [f.status]: (m[f.status] ?? 0) + 1 }), {}),
        } as T;
      case 'list_feedback':
        return backend.feedback as T;
      case 'set_status': {
        const f = need(backend.feedback.find((x) => x.id === args.id), 'That item no longer exists.');
        f.status = args.status as Feedback['status'];
        return undefined as T;
      }
      case 'delete_feedback':
        backend.feedback = backend.feedback.filter((x) => x.id !== args.id);
        return undefined as T;
      case 'change_code':
        if (String(args.new_code).length < 8) throw new AppError('The new passcode must be 8 to 64 characters.');
        backend.adminCode = String(args.new_code);
        return undefined as T;
      default:
        throw new AppError('The admin request failed.');
    }
  },
  deleteMyAccount: async () => {
    const id = uid();
    backend.profiles = backend.profiles.filter((p) => p.id !== id);
    backend.accounts = backend.accounts.filter((a) => a.id !== id);
    backend.stores = backend.stores.filter((s) => s.owner_id !== id);
  },
});

// ------------------------------------------------------------------- owner

function analyticsFor(storeId: string, from: string | null, to: string | null): Analytics {
  const inRange = (iso: string) => (!from || iso >= from) && (!to || iso < to);
  const sales = backend.sales.filter((s) => s.store_id === storeId && inRange(s.sold_at));
  const exps = backend.expenses.filter((e) => e.store_id === storeId && inRange(e.spent_on));
  const byProduct = new Map<string, { name: string; units: number; revenue: number }>();
  sales.forEach((s) => {
    const cur = byProduct.get(s.product_name) ?? { name: s.product_name, units: 0, revenue: 0 };
    cur.units += Number(s.qty);
    cur.revenue += Number(s.total);
    byProduct.set(s.product_name, cur);
  });
  const byCat = new Map<string, number>();
  exps.forEach((e) => byCat.set(e.category, (byCat.get(e.category) ?? 0) + Number(e.amount)));
  const now = new Date();
  const monthly = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    return {
      month: key,
      revenue: backend.sales.filter((s) => s.store_id === storeId && s.sold_at.startsWith(key)).reduce((t, s) => t + Number(s.total), 0),
      expenses: backend.expenses.filter((e) => e.store_id === storeId && e.spent_on.startsWith(key)).reduce((t, e) => t + Number(e.amount), 0),
    };
  });
  const orders = backend.orders.filter((o) => o.store_id === storeId);
  const products = backend.products.filter((p) => p.store_id === storeId);
  return {
    revenue: round2(sales.reduce((t, s) => t + Number(s.total), 0)),
    expenses: round2(exps.reduce((t, e) => t + Number(e.amount), 0)),
    units: sales.reduce((t, s) => t + Number(s.qty), 0),
    sales_count: sales.length,
    monthly,
    top_products: [...byProduct.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 5),
    expense_breakdown: [...byCat.entries()].map(([category, amount]) => ({ category, amount })).sort((a, b) => b.amount - a.amount),
    low_stock: products
      .filter((p) => p.track_stock && p.low_alert > 0 && p.stock <= p.low_alert)
      .map((p) => ({ id: p.id, name: p.name, stock: p.stock, low_alert: p.low_alert, unit: p.unit })),
    new_orders: orders.filter((o) => o.status === 'placed').length,
    open_orders: orders.filter((o) => o.status === 'placed' || o.status === 'processing').length,
    product_count: products.length,
  };
}

export const ownerApi: typeof OwnerReal = guard({
  listMyStores: async (ownerId) => backend.stores.filter((s) => s.owner_id === ownerId),
  createStore: async (ownerId, input) => {
    const s = { id: nextId('store'), owner_id: ownerId, code: code('S').slice(0, 8), logo_url: null, created_at: NOW(), ...input } as any;
    backend.stores.push(s);
    return s;
  },
  updateStore: async (id, patch) => {
    const s = need(backend.stores.find((x) => x.id === id), 'Store not found');
    Object.assign(s, patch);
    return { ...s };
  },
  deleteStore: async (store) => {
    backend.stores = backend.stores.filter((s) => s.id !== store.id);
    backend.products = backend.products.filter((p) => p.store_id !== store.id);
  },
  listProducts: async (storeId) => backend.products.filter((p) => p.store_id === storeId).map((p) => ({ ...p })),
  saveProduct: async (storeId, input, id) => {
    if (id) {
      const p = need(backend.products.find((x) => x.id === id), 'Item not found');
      Object.assign(p, input);
      return { ...p };
    }
    const p: Product = { id: nextId('prod'), store_id: storeId, created_at: NOW(), ...input };
    backend.products.push(p);
    return p;
  },
  deleteProduct: async (p) => {
    backend.products = backend.products.filter((x) => x.id !== p.id);
  },
  listSales: async (storeId, limit = 50, offset = 0) =>
    backend.sales
      .filter((s) => s.store_id === storeId)
      .sort((a, b) => b.sold_at.localeCompare(a.sold_at))
      .slice(offset, offset + limit),
  lastSaleAt: async (storeId) => backend.sales.filter((s) => s.store_id === storeId).map((s) => s.sold_at).sort().pop() ?? null,
  recordSale: async (input) => {
    if (!ownsStore(input.storeId)) throw new AppError('You do not own this business');
    const counted = input.clientId ? backend.counted.get(`${input.storeId}|${input.clientId}`) : undefined;
    if (counted) {
      maybeLoseReply();
      return counted as Sale;
    }
    if (!(input.qty > 0)) throw new AppError('Quantity must be more than zero');
    const p = need(backend.products.find((x) => x.id === input.productId && x.store_id === input.storeId), 'Item not found');
    if (p.track_stock) {
      if (p.stock < input.qty) throw new AppError(`Only ${p.stock} ${p.unit} in stock`);
      p.stock -= input.qty;
    }
    const price = input.price ?? p.price;
    const sale: Sale = {
      id: nextId('sale'),
      store_id: input.storeId,
      product_id: p.id,
      order_id: null,
      product_name: p.name,
      unit: p.unit,
      txn_id: code('TXN'),
      qty: input.qty,
      unit_price: price,
      total: round2(input.qty * price),
      customer: input.customer,
      note: input.note,
      sold_at: (input.soldAt ?? new Date()).toISOString(),
    };
    backend.sales.push(sale);
    if (input.clientId) backend.counted.set(`${input.storeId}|${input.clientId}`, sale);
    maybeLoseReply();
    return sale;
  },
  deleteSale: async (id) => {
    const s = need(backend.sales.find((x) => x.id === id), 'Sale not found');
    const p = backend.products.find((x) => x.id === s.product_id);
    if (p && p.track_stock) p.stock += Number(s.qty);
    backend.sales = backend.sales.filter((x) => x.id !== id);
  },
  listExpenses: async (storeId, limit = 100, offset = 0) =>
    backend.expenses.filter((e) => e.store_id === storeId).sort((a, b) => b.spent_on.localeCompare(a.spent_on)).slice(offset, offset + limit),
  addExpense: async (input) => {
    if (!ownsStore(input.storeId)) throw new AppError('You do not own this business');
    if (input.clientId && backend.counted.has(`${input.storeId}|${input.clientId}`)) {
      maybeLoseReply();
      return;
    }
    const e: Expense = {
      id: nextId('exp'),
      store_id: input.storeId,
      category: input.category,
      description: input.description,
      payee: input.payee,
      amount: input.amount,
      spent_on: input.spentOn,
      created_at: NOW(),
    };
    backend.expenses.push(e);
    if (input.clientId) backend.counted.set(`${input.storeId}|${input.clientId}`, e);
    maybeLoseReply();
  },
  deleteExpense: async (id) => {
    backend.expenses = backend.expenses.filter((e) => e.id !== id);
  },
  listStoreOrders: async (storeId) =>
    backend.orders.filter((o) => o.store_id === storeId).sort((a, b) => b.created_at.localeCompare(a.created_at)),
  approvePayment: async (id) => {
    const o = need(backend.orders.find((x) => x.id === id), 'Order not found');
    if (!ownsStore(o.store_id)) throw new AppError('Not allowed');
    if (o.status !== 'placed' && o.status !== 'processing') {
      throw new AppError(`An order that is ${o.status} cannot have its payment approved`);
    }
    if (o.payment_status === 'approved') return;
    o.payment_status = 'approved';
    o.payment_approved_at = NOW();
    if (o.status === 'placed') o.status = 'processing';
    o.updated_at = NOW();
  },
  setOrderStatus: async (id, status) => {
    const o = need(backend.orders.find((x) => x.id === id), 'Order not found');
    const allowed =
      (o.status === 'placed' && ['processing', 'complete', 'cancelled'].includes(status)) ||
      (o.status === 'processing' && ['complete', 'cancelled'].includes(status)) ||
      (o.status === 'complete' && status === 'cancelled');
    if (!allowed) throw new AppError(`An order that is ${o.status} cannot be set to ${status}`);
    if (status === 'complete') {
      (o.items ?? []).forEach((it) =>
        backend.sales.push({
          id: nextId('sale'),
          store_id: o.store_id,
          product_id: it.product_id,
          order_id: o.id,
          product_name: it.name,
          unit: it.unit,
          txn_id: o.code,
          qty: it.qty,
          unit_price: it.price,
          total: round2(it.qty * it.price),
          customer: o.customer_name,
          note: `Store order - ${o.pay_method}`,
          sold_at: NOW(),
        }),
      );
    } else if (status === 'cancelled') {
      if (o.status === 'complete') backend.sales = backend.sales.filter((s) => s.order_id !== o.id);
      (o.items ?? []).forEach((it) => {
        const p = backend.products.find((x) => x.id === it.product_id);
        if (p && p.track_stock) p.stock += Number(it.qty);
      });
    }
    o.status = status;
    if (status === 'complete' && o.payment_status !== 'approved') {
      o.payment_status = 'approved';
      o.payment_approved_at = NOW();
    }
    o.updated_at = NOW();
  },
  getAnalytics: async (storeId, from = null, to = null) => {
    if (!ownsStore(storeId)) throw new AppError('You do not own this business');
    return analyticsFor(storeId, from, to);
  },
});

// ---------------------------------------------------------------- customer

const storeBrief = (storeId: string) => {
  const s = need(backend.stores.find((x) => x.id === storeId), 'Store not found');
  return { id: s.id, name: s.name, currency: s.currency, phone: s.phone, payment_info: s.payment_info, logo_url: s.logo_url };
};

export const customerApi: typeof CustomerReal = guard({
  searchStores: async (q) => {
    const c = q.trim().toLowerCase();
    return backend.stores
      .filter((s) => !c || [s.name, s.location, s.description, s.code].some((v) => v.toLowerCase().includes(c)))
      .map((s) => ({ ...s, products: [{ count: backend.products.filter((p) => p.store_id === s.id && p.active).length }] }));
  },
  searchProducts: async (q) => {
    const c = q.trim().toLowerCase();
    return backend.products
      .filter((p) => p.active && (!c || p.name.toLowerCase().includes(c) || p.category.toLowerCase().includes(c)))
      .map((p) => ({ ...p, store: storeBrief(p.store_id) }));
  },
  getStore: async (id) => ({ ...need(backend.stores.find((s) => s.id === id), 'Store not found') }),
  listStoreProducts: async (storeId) => backend.products.filter((p) => p.store_id === storeId && p.active).map((p) => ({ ...p })),
  getProduct: async (id) => {
    const p = need(backend.products.find((x) => x.id === id), 'Item not found');
    return { ...p, store: storeBrief(p.store_id) };
  },
  wishlistIds: async () => backend.wishlist.filter((w) => w.user === uid()).map((w) => w.product),
  listWishlist: async () =>
    backend.wishlist
      .filter((w) => w.user === uid())
      .map((w) => backend.products.find((p) => p.id === w.product))
      .filter((p): p is Product => !!p && p.active)
      .map((p) => ({ ...p, store: storeBrief(p.store_id) })),
  setWished: async (userId, productId, wished) => {
    backend.wishlist = backend.wishlist.filter((w) => !(w.user === userId && w.product === productId));
    if (wished) backend.wishlist.push({ user: userId, product: productId });
  },
  placeOrder: async (input) => {
    const profile = need(backend.profiles.find((p) => p.id === uid()), 'Sign in to place an order');
    if (profile.role !== 'customer') throw new AppError('Only customer accounts can place orders');
    if (input.name.trim().length < 2) throw new AppError('Enter your name');
    if (input.phone.trim().length < 7) throw new AppError('Enter a valid phone number');
    if (!input.items.length) throw new AppError('Your cart is empty');
    const store = need(backend.stores.find((s) => s.id === input.storeId), 'Store not found');
    const order: Order = {
      id: nextId('order'),
      code: code('ORD'),
      store_id: store.id,
      customer_id: profile.id,
      customer_name: input.name.trim(),
      customer_phone: input.phone.trim(),
      pay_method: input.payMethod,
      notes: input.notes,
      total: 0,
      currency: store.currency,
      status: 'placed',
      payment_status: 'awaiting',
      payment_approved_at: null,
      created_at: NOW(),
      updated_at: NOW(),
      items: [],
    };
    const items: OrderItem[] = [];
    let total = 0;
    for (const line of input.items) {
      const p = need(backend.products.find((x) => x.id === line.productId && x.store_id === store.id && x.active), 'An item in your cart is no longer available');
      if (p.track_stock && p.stock < line.qty) throw new AppError(`${p.name} has only ${p.stock} ${p.unit} left`);
      if (p.track_stock) p.stock -= line.qty;
      items.push({ id: nextId('oi'), order_id: order.id, product_id: p.id, name: p.name, unit: p.unit, image_url: p.image_url, price: p.price, qty: line.qty });
      total += round2(p.price * line.qty);
    }
    order.items = items;
    order.total = round2(total);
    backend.orders.push(order);
    return { ...order };
  },
  listMyOrders: async (userId) =>
    backend.orders
      .filter((o) => o.customer_id === userId)
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .map((o) => ({ ...o, store: storeBrief(o.store_id) })),
  cancelMyOrder: async (id) => {
    const o = need(backend.orders.find((x) => x.id === id && x.customer_id === uid()), 'Order not found');
    if (o.status !== 'placed') throw new AppError('You can only cancel an order the store has not accepted yet');
    (o.items ?? []).forEach((it) => {
      const p = backend.products.find((x) => x.id === it.product_id);
      if (p && p.track_stock) p.stock += Number(it.qty);
    });
    o.status = 'cancelled';
  },
});
