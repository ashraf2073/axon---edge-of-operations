/**
 * An in-memory stand-in for the Supabase backend, used only by tests.
 * It follows the same rules as supabase/schema.sql (stock held when ordered,
 * revenue created when an order is completed, and so on) so the screens can be
 * exercised end to end without a network.
 */
import type { Expense, Feedback, Order, Product, Profile, Sale, Store } from '../src/types';

export interface FakeSession {
  user: { id: string; email: string };
}

interface Account {
  id: string;
  email: string;
  password: string;
}

export const backend = {
  session: null as FakeSession | null,
  listeners: new Set<(event: string, s: FakeSession | null) => void>(),
  accounts: [] as Account[],
  profiles: [] as Profile[],
  stores: [] as Store[],
  products: [] as Product[],
  sales: [] as Sale[],
  expenses: [] as Expense[],
  orders: [] as Order[],
  wishlist: [] as { user: string; product: string }[],
  feedback: [] as (Feedback & { user_id: string })[],
  adminCode: 'axon2026',
  seq: 0,
  /** codes the pretend email service "sent", by email address */
  resetCodes: {} as Record<string, string>,
  /** how the last sign-out was asked for: this phone only, or every device */
  lastSignOutScope: '' as string,
  /** every request fails like a dead connection */
  offline: false,
  /** the saved login has run out, so it can only be renewed with a connection */
  tokenExpired: false,
  /** the next sale or expense is applied by the cloud but its reply never arrives */
  loseNextReply: false,
  /** sales and expenses already counted, by "store|client id" */
  counted: new Map<string, unknown>(),
};

export function nextId(prefix: string): string {
  backend.seq += 1;
  return `${prefix}-${backend.seq}`;
}

export function emitAuth(event: 'SIGNED_IN' | 'SIGNED_OUT' | 'INITIAL_SESSION') {
  backend.listeners.forEach((cb) => cb(event, backend.session));
}

export function resetBackend() {
  backend.session = null;
  backend.listeners.clear();
  backend.accounts = [];
  backend.profiles = [];
  backend.stores = [];
  backend.products = [];
  backend.sales = [];
  backend.expenses = [];
  backend.orders = [];
  backend.wishlist = [];
  backend.feedback = [];
  backend.adminCode = 'axon2026';
  backend.seq = 0;
  backend.resetCodes = {};
  backend.lastSignOutScope = '';
  backend.offline = false;
  backend.tokenExpired = false;
  backend.loseNextReply = false;
  backend.counted = new Map();
}

const NOW = () => new Date().toISOString();

export function addAccount(opts: {
  role: 'owner' | 'customer';
  name: string;
  email: string;
  password?: string;
}): Profile {
  const id = nextId(opts.role);
  const password = opts.password ?? 'secret-pass-1';
  backend.accounts.push({ id, email: opts.email, password });
  const profile: Profile = {
    id,
    role: opts.role,
    full_name: opts.name,
    phone: '0712345678',
    email: opts.email,
    date_format: 'DD/MM/YYYY',
    consent_at: null,
    consent_contact: false,
  };
  backend.profiles.push(profile);
  return profile;
}

export function addStore(ownerId: string, over: Partial<Store> = {}): Store {
  const s: Store = {
    id: nextId('store'),
    owner_id: ownerId,
    code: 'FARM2345',
    name: 'Mama Njeri Farm',
    kind: 'farm',
    description: 'Fresh milk, eggs and livestock from our farm.',
    location: 'Nakuru',
    phone: '0722000111',
    currency: 'KES',
    payment_info: 'M-Pesa Till 123456',
    logo_url: null,
    created_at: NOW(),
    ...over,
  };
  backend.stores.push(s);
  return s;
}

export function addProduct(storeId: string, over: Partial<Product> = {}): Product {
  const p: Product = {
    id: nextId('prod'),
    store_id: storeId,
    name: 'Fresh milk',
    category: 'Dairy',
    kind: 'farm',
    description: 'Fresh cow milk, delivered cold.',
    unit: 'litre',
    price: 130,
    cost: 90,
    stock: 40,
    track_stock: true,
    low_alert: 10,
    image_url: null,
    active: true,
    created_at: NOW(),
    ...over,
  };
  backend.products.push(p);
  return p;
}

/** One owner with a farm, one customer, three items. */
export function seedWorld() {
  resetBackend();
  const owner = addAccount({ role: 'owner', name: 'Amina Owner', email: 'owner@axon.test' });
  const customer = addAccount({ role: 'customer', name: 'Brian Buyer', email: 'cust@axon.test' });
  const store = addStore(owner.id);
  const milk = addProduct(store.id);
  const eggs = addProduct(store.id, { name: 'Eggs tray', category: 'Eggs', unit: 'tray', price: 450, stock: 5, low_alert: 5, kind: 'farm' });
  const cow = addProduct(store.id, { name: 'Friesian cow A', category: 'Cattle', kind: 'animal', unit: 'head', price: 85000, stock: 1, low_alert: 0 });
  addProduct(store.id, { name: 'Hidden item', active: false });
  return { owner, customer, store, milk, eggs, cow };
}
