// A small stand-in for Supabase's REST layer (PostgREST), used only by the contract tests.
//
// It runs the real supabase/schema.sql inside an in-process Postgres (PGlite) and answers the
// HTTP requests that supabase-js sends, with the same row-level security a real project applies.
// Each request runs as the database role `authenticated` (when a test user is named) or `anon`.
//
//   node server.mjs        prints "READY <port>" when it is listening
import { PGlite } from '@electric-sql/pglite';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
import http from 'node:http';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const db = new PGlite({ extensions: { pgcrypto } });
await db.exec(readFileSync(path.join(here, 'stubs.sql'), 'utf8'));
await db.exec(readFileSync(path.join(here, '../../supabase/schema.sql'), 'utf8'));

// ---------------------------------------------------------------- metadata

const fks = (
  await db.query(`
    select c.conrelid::regclass::text as child, ca.attname as child_col,
           c.confrelid::regclass::text as parent, pa.attname as parent_col
      from pg_constraint c
      join pg_attribute ca on ca.attrelid = c.conrelid and ca.attnum = c.conkey[1]
      join pg_attribute pa on pa.attrelid = c.confrelid and pa.attnum = c.confkey[1]
     where c.contype = 'f' and c.connamespace = 'public'::regnamespace`)
).rows;

const fns = new Map(
  (
    await db.query(`
      select p.proname as name, coalesce(p.proargnames, '{}') as argnames,
             (select coalesce(array_agg(format_type(u.t, null) order by u.ord), '{}')
                from unnest(p.proargtypes::oid[]) with ordinality as u(t, ord)) as argtypes,
             format_type(p.prorettype, null) as rettype
        from pg_proc p
       where p.pronamespace = 'public'::regnamespace and p.prokind = 'f'`)
  ).rows.map((r) => [r.name, r]),
);

// ----------------------------------------------------------------- helpers

class HttpError extends Error {
  constructor(status, code, message, details = null) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

const ident = (s) => {
  if (!/^[a-z_][a-z0-9_]*$/i.test(s)) throw new HttpError(400, 'PGRST100', `bad name ${s}`);
  return s;
};

const RESERVED = new Set(['select', 'order', 'limit', 'offset', 'on_conflict', 'columns']);

function parseSelect(s) {
  let i = 0;
  const list = () => {
    const nodes = [];
    while (i < s.length) {
      const start = i;
      while (i < s.length && !',()'.includes(s[i])) i++;
      const tok = s.slice(start, i).trim();
      if (s[i] === '(') {
        i++;
        const children = list();
        const left = tok.split('!')[0];
        const [alias, table] = left.includes(':') ? left.split(':') : [left, left];
        const isCount = children.length === 1 && children[0].kind === 'col' && children[0].name === 'count';
        nodes.push({ kind: isCount ? 'count' : 'embed', alias, table: ident(table), children });
      } else if (tok === '*') nodes.push({ kind: 'star' });
      else if (tok) nodes.push({ kind: 'col', name: ident(tok.split(':').pop()) });
      if (s[i] === ')') {
        i++;
        return nodes;
      }
      if (s[i] === ',') i++;
    }
    return nodes;
  };
  return list();
}

function relation(parent, target) {
  const one = fks.find((f) => f.child === parent && f.parent === target);
  if (one) return { many: false, targetCol: one.parent_col, parentCol: one.child_col };
  const many = fks.find((f) => f.child === target && f.parent === parent);
  if (many) return { many: true, targetCol: many.child_col, parentCol: many.parent_col };
  throw new HttpError(400, 'PGRST200', `Could not find a relationship between '${parent}' and '${target}'`);
}

/** SQL that builds the JSON of one row, with any embedded rows, from a parsed select list. */
function rowExpr(nodes, table, alias, depth) {
  const parts = [];
  const cols = nodes.filter((n) => n.kind === 'col');
  if (nodes.some((n) => n.kind === 'star')) parts.push(`to_jsonb(${alias}.*)`);
  else if (cols.length) parts.push(`jsonb_build_object(${cols.map((c) => `'${c.name}', ${alias}."${c.name}"`).join(', ')})`);
  else parts.push(`'{}'::jsonb`);
  for (const n of nodes) {
    if (n.kind !== 'embed' && n.kind !== 'count') continue;
    const rel = relation(table, n.table);
    const a = `e${depth + 1}`;
    const cond = `${a}."${rel.targetCol}" = ${alias}."${rel.parentCol}"`;
    let expr;
    if (n.kind === 'count') {
      expr = `jsonb_build_array(jsonb_build_object('count', (select count(*) from public.${n.table} ${a} where ${cond})))`;
    } else if (rel.many) {
      expr = `coalesce((select jsonb_agg(${rowExpr(n.children, n.table, a, depth + 1)}) from public.${n.table} ${a} where ${cond}), '[]'::jsonb)`;
    } else {
      expr = `(select ${rowExpr(n.children, n.table, a, depth + 1)} from public.${n.table} ${a} where ${cond} limit 1)`;
    }
    parts.push(`jsonb_build_object('${ident(n.alias)}', ${expr})`);
  }
  return parts.join(' || ');
}

function condition(alias, col, spec, vals) {
  let negate = false;
  if (spec.startsWith('not.')) {
    negate = true;
    spec = spec.slice(4);
  }
  const dot = spec.indexOf('.');
  const op = spec.slice(0, dot);
  const val = spec.slice(dot + 1);
  const c = `${alias}."${ident(col)}"`;
  const bind = (v) => {
    vals.push(v);
    return `$${vals.length}`;
  };
  let sql;
  switch (op) {
    case 'eq': sql = `${c} = ${bind(val)}`; break;
    case 'neq': sql = `${c} <> ${bind(val)}`; break;
    case 'gt': sql = `${c} > ${bind(val)}`; break;
    case 'gte': sql = `${c} >= ${bind(val)}`; break;
    case 'lt': sql = `${c} < ${bind(val)}`; break;
    case 'lte': sql = `${c} <= ${bind(val)}`; break;
    case 'like': sql = `${c}::text like ${bind(val.replace(/\*/g, '%'))}`; break;
    case 'ilike': sql = `${c}::text ilike ${bind(val.replace(/\*/g, '%'))}`; break;
    case 'is': sql = `${c} is ${['null', 'true', 'false'].includes(val) ? val : 'null'}`; break;
    case 'in': sql = `${c} in (${val.replace(/^\(|\)$/g, '').split(',').map((x) => bind(x.replace(/^"|"$/g, ''))).join(', ')})`; break;
    default: throw new HttpError(400, 'PGRST100', `unsupported operator ${op}`);
  }
  return negate ? `not (${sql})` : sql;
}

function splitTop(s) {
  const out = [];
  let depth = 0;
  let cur = '';
  for (const ch of s) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === ',' && depth === 0) {
      out.push(cur);
      cur = '';
    } else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function groupCondition(kind, value, alias, vals) {
  const inner = value.replace(/^\(|\)$/g, '');
  const items = splitTop(inner).map((item) => {
    const first = item.indexOf('.');
    return condition(alias, item.slice(0, first), item.slice(first + 1), vals);
  });
  return `(${items.join(kind === 'or' ? ' or ' : ' and ')})`;
}

function whereClause(params, alias, vals) {
  const conds = [];
  for (const [k, v] of params) {
    if (RESERVED.has(k)) continue;
    conds.push(k === 'or' || k === 'and' ? groupCondition(k, v, alias, vals) : condition(alias, k, v, vals));
  }
  return conds.length ? ` where ${conds.join(' and ')}` : '';
}

function orderClause(params, alias) {
  const raw = params.get('order');
  if (!raw) return '';
  const parts = raw.split(',').map((p) => {
    const [col, ...mods] = p.split('.');
    const dir = mods.includes('desc') ? 'desc' : 'asc';
    const nulls = mods.includes('nullsfirst') ? ' nulls first' : mods.includes('nullslast') ? ' nulls last' : '';
    return `${alias}."${ident(col)}" ${dir}${nulls}`;
  });
  return ` order by ${parts.join(', ')}`;
}

const pgValue = (v) => (v !== null && typeof v === 'object' ? JSON.stringify(v) : v);

/** Runs `fn` inside a transaction as the role a real request would have. */
async function asRole(headers, fn) {
  const user = headers['x-test-user'];
  const claims = user ? { sub: user, role: 'authenticated' } : { role: 'anon' };
  return db.transaction(async (tx) => {
    await tx.query("select set_config('request.jwt.claims', $1, true)", [JSON.stringify(claims)]);
    await tx.query("select set_config('request.headers', $1, true)", [JSON.stringify(headers)]);
    await tx.exec(`set local role ${user ? 'authenticated' : 'anon'}`);
    return fn(tx);
  });
}

// ------------------------------------------------------------ table access

async function tableRequest(method, table, url, headers, body) {
  ident(table);
  const params = url.searchParams;
  const prefer = String(headers.prefer || '');
  const wantsRows = method === 'GET' || prefer.includes('return=representation');
  const single = String(headers.accept || '').includes('vnd.pgrst.object+json');
  const nodes = parseSelect(params.get('select') || '*');
  const vals = [];
  let sql;

  if (method === 'GET') {
    sql =
      `select ${rowExpr(nodes, table, 't', 0)} as r from public.${table} t` +
      whereClause(params, 't', vals) +
      orderClause(params, 't') +
      (params.get('limit') ? ` limit ${parseInt(params.get('limit'), 10)}` : '') +
      (params.get('offset') ? ` offset ${parseInt(params.get('offset'), 10)}` : '');
  } else {
    let dml;
    if (method === 'POST') {
      const rows = Array.isArray(body) ? body : [body];
      const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))].map(ident);
      const tuples = rows.map(
        (r) => `(${cols.map((c) => (c in r ? (vals.push(pgValue(r[c])), `$${vals.length}`) : 'default')).join(', ')})`,
      );
      let conflict = '';
      if (prefer.includes('resolution=merge-duplicates') || prefer.includes('resolution=ignore-duplicates')) {
        const target = (params.get('on_conflict') || '').split(',').filter(Boolean).map(ident);
        const update = cols.filter((c) => !target.includes(c));
        conflict =
          prefer.includes('ignore-duplicates') || !update.length
            ? ` on conflict (${target.join(',')}) do nothing`
            : ` on conflict (${target.join(',')}) do update set ${update.map((c) => `"${c}" = excluded."${c}"`).join(', ')}`;
      }
      dml = `insert into public.${table} (${cols.map((c) => `"${c}"`).join(', ')}) values ${tuples.join(', ')}${conflict} returning *`;
    } else if (method === 'PATCH') {
      const cols = Object.keys(body).map(ident);
      const sets = cols.map((c) => (vals.push(pgValue(body[c])), `"${c}" = $${vals.length}`));
      dml = `update public.${table} as t set ${sets.join(', ')}${whereClause(params, 't', vals)} returning t.*`;
    } else if (method === 'DELETE') {
      dml = `delete from public.${table} as t${whereClause(params, 't', vals)} returning t.*`;
    } else throw new HttpError(405, 'PGRST000', 'method not allowed');
    sql = `with m as (${dml}) select ${rowExpr(nodes, table, 't', 0)} as r from m t`;
  }

  const rows = await asRole(headers, async (tx) => {
    const res = await tx.query(sql, vals);
    const out = res.rows.map((x) => x.r);
    if (single && out.length !== 1) {
      throw new HttpError(406, 'PGRST116', 'Cannot coerce the result to a single JSON object', `The result contains ${out.length} rows`);
    }
    return out;
  });

  const status = method === 'POST' ? 201 : method === 'GET' ? 200 : wantsRows ? 200 : 204;
  if (!wantsRows) return { status: method === 'POST' ? 201 : 204, body: null };
  return { status, body: single ? rows[0] : rows };
}

// -------------------------------------------------------------------- RPC

const arrayLiteral = (arr) =>
  '{' + arr.map((x) => (x === null ? 'NULL' : '"' + String(x).replace(/(["\\])/g, '\\$1') + '"')).join(',') + '}';

async function rpcRequest(name, headers, body) {
  const fn = fns.get(ident(name));
  if (!fn) throw new HttpError(404, 'PGRST202', `Could not find the function public.${name} in the schema cache`);
  const args = body && typeof body === 'object' ? body : {};
  const vals = [];
  const named = [];
  for (const key of Object.keys(args)) {
    const idx = fn.argnames.indexOf(key);
    if (idx < 0) {
      throw new HttpError(404, 'PGRST202', `Could not find the function public.${name}(${Object.keys(args).join(', ')}) in the schema cache`);
    }
    const type = fn.argtypes[idx];
    let v = args[key];
    if (v !== null && v !== undefined) {
      if (type === 'jsonb' || type === 'json') v = JSON.stringify(v);
      else if (type.endsWith('[]')) v = arrayLiteral(v);
    }
    vals.push(v ?? null);
    named.push(`${ident(key)} := $${vals.length}::${type}`);
  }
  const call = `public.${name}(${named.join(', ')})`;
  const isVoid = fn.rettype === 'void';
  const rows = await asRole(headers, async (tx) => {
    const res = await tx.query(isVoid ? `select ${call}` : `select to_jsonb(${call}) as r`, vals);
    return res.rows;
  });
  if (isVoid) return { status: 204, body: null };
  return { status: 200, body: rows[0]?.r ?? null };
}

// ------------------------------------------------------------ test control

async function control(pathname, body) {
  if (pathname === '/__test/signup') {
    const id = randomUUID();
    await db.query(
      `insert into auth.users (id, email, encrypted_password, raw_user_meta_data)
       values ($1, $2, extensions.crypt($3, extensions.gen_salt('bf')), $4)`,
      [id, body.email, body.password || 'secret-pass-1', JSON.stringify({ axon_role: body.role, full_name: body.name, phone: body.phone || '0700000000' })],
    );
    return { id };
  }
  if (pathname === '/__test/sql') {
    const res = await db.query(body.sql, body.params || []);
    return { rows: res.rows };
  }
  throw new HttpError(404, 'TEST404', 'unknown control path');
}

// ----------------------------------------------------------------- server

const STATUS_FOR = { '42501': 403, '23505': 409, '42883': 404, '42P01': 404 };

const server = http.createServer(async (req, res) => {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const text = Buffer.concat(chunks).toString('utf8');
  const send = (status, payload) => {
    const data = payload === null || payload === undefined ? '' : JSON.stringify(payload);
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
    res.end(status === 204 ? undefined : data);
  };
  try {
    const url = new URL(req.url, 'http://localhost');
    const headers = Object.fromEntries(Object.entries(req.headers).map(([k, v]) => [k.toLowerCase(), String(v)]));
    const body = text ? JSON.parse(text) : null;
    if (url.pathname.startsWith('/__test/')) {
      const out = await control(url.pathname, body);
      return send(200, out);
    }
    let out;
    if (url.pathname.startsWith('/rest/v1/rpc/')) {
      out = await rpcRequest(url.pathname.slice('/rest/v1/rpc/'.length), headers, body);
    } else if (url.pathname.startsWith('/rest/v1/')) {
      out = await tableRequest(req.method, url.pathname.slice('/rest/v1/'.length), url, headers, body);
    } else throw new HttpError(404, 'PGRST404', 'not found');
    send(out.status, out.body);
  } catch (e) {
    if (e instanceof HttpError) return send(e.status, { code: e.code, message: e.message, details: e.details, hint: null });
    const code = e.code || 'P0001';
    send(STATUS_FOR[code] || 400, { code, message: e.message, details: e.detail || null, hint: e.hint || null });
  }
});

server.listen(0, '127.0.0.1', () => {
  console.log(`READY ${server.address().port}`);
});
