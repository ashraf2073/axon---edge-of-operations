/**
 * The app's real API code (src/api) talking to the real database rules (supabase/schema.sql).
 * Every call is made as a particular signed-in person, so row-level security applies exactly as it will
 * in a live Supabase project. Run with: npm run test:contract
 */
jest.mock('../../src/lib/supabase', () => ({ supabase: require('./client').supabaseProxy }));
jest.mock('../../src/lib/images', () => ({ deleteImageByUrl: async () => undefined, uploadImage: async () => '' }));

import * as account from '../../src/api/account';
import * as customer from '../../src/api/customer';
import * as owner from '../../src/api/owner';
import { useBiz } from '../../src/state/biz';
import type { Product, Store } from '../../src/types';
import { as, signup, sql, startServer, stopServer } from './client';

let o1: string;
let o2: string;
let c1: string;
let c2: string;
let farm: Store;
let milk: Product;
let cow: Product;
let svc: Product;

const act = (id: string | null, ip = '10.0.0.1') => {
  as.user = id;
  as.ip = ip;
};
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const item = (over: Partial<owner.ProductInput> = {}): owner.ProductInput => ({
  name: 'Item',
  category: 'General',
  kind: 'good',
  description: '',
  unit: 'piece',
  price: 100,
  cost: 60,
  stock: 20,
  track_stock: true,
  low_alert: 5,
  image_url: null,
  active: true,
  ...over,
});
const stockOf = async (id: string) => Number((await sql<{ stock: string }>('select stock from axon_products where id = $1', [id]))[0].stock);

beforeAll(async () => {
  await startServer();
  o1 = await signup('owner', 'Owner1@Shop.test', 'Olivia Owner');
  o2 = await signup('owner', 'owner2@shop.test', 'Other Owner');
  c1 = await signup('customer', 'cust1@x.test', 'Chris Customer');
  c2 = await signup('customer', 'cust2@x.test', 'Casey Customer');
}, 90000);
afterAll(stopServer);

describe('accounts and businesses', () => {
  test('sign-up creates the right kind of profile, and a person can edit only their own details', async () => {
    const rows = await sql<{ role: string; email: string }>('select role, email from axon_profiles order by email');
    expect(rows.map((r) => r.role)).toEqual(['customer', 'customer', 'owner', 'owner']);
    expect(rows.map((r) => r.email)).toContain('owner1@shop.test');

    act(c1);
    await account.updateProfile(c1, { full_name: 'Chris C', phone: '0711000111', date_format: 'YYYY-MM-DD' });
    const [p] = await sql<{ full_name: string; date_format: string; role: string }>('select * from axon_profiles where id = $1', [c1]);
    expect(p).toMatchObject({ full_name: 'Chris C', date_format: 'YYYY-MM-DD', role: 'customer' });

    // changing someone else's details quietly changes nothing
    await account.updateProfile(o1, { full_name: 'Hacked' });
    expect((await sql<{ full_name: string }>('select full_name from axon_profiles where id = $1', [o1]))[0].full_name).toBe('Olivia Owner');
  });

  test('an owner creates, edits and lists a business; others cannot', async () => {
    act(o1);
    farm = await owner.createStore(o1, {
      name: 'Green Farm Shop',
      kind: 'farm',
      description: 'Milk and livestock',
      location: 'Nakuru',
      phone: '0722000111',
      currency: 'KES',
      payment_info: 'M-Pesa Till 123456',
    });
    expect(farm.code).toMatch(/^[A-Z2-9]{6}$/);
    expect((await owner.listMyStores(o1)).map((s) => s.name)).toEqual(['Green Farm Shop']);

    const edited = await owner.updateStore(farm.id, { name: 'Green Farm', location: 'Naivasha' });
    expect(edited).toMatchObject({ name: 'Green Farm', location: 'Naivasha' });
    farm = edited;

    act(o2);
    await expect(owner.updateStore(farm.id, { name: 'Stolen' })).rejects.toThrow(/could not be found/);
    expect(await owner.listMyStores(o2)).toEqual([]);

    act(c1);
    await expect(
      owner.createStore(c1, { name: 'Customer shop', kind: 'shop', description: '', location: '', phone: '', currency: 'KES', payment_info: '' }),
    ).rejects.toThrow(/permission/);
  });

  test('a person can have at most ten businesses', async () => {
    act(o2);
    for (let i = 1; i <= 10; i++) {
      await owner.createStore(o2, { name: `Shop ${i}`, kind: 'shop', description: '', location: '', phone: '', currency: 'KES', payment_info: '' });
    }
    await expect(
      owner.createStore(o2, { name: 'Shop 11', kind: 'shop', description: '', location: '', phone: '', currency: 'KES', payment_info: '' }),
    ).rejects.toThrow(/up to 10 businesses/);
  });
});

describe('items, sales and expenses', () => {
  test('an owner manages items; customers only see the ones shown to them', async () => {
    act(o1);
    milk = await owner.saveProduct(farm.id, item({ name: 'Fresh milk', category: 'Dairy', kind: 'farm', unit: 'litre', price: 130, cost: 90, stock: 50, low_alert: 10 }));
    cow = await owner.saveProduct(farm.id, item({ name: 'Friesian cow', category: 'Livestock', kind: 'animal', unit: 'head', price: 85000, stock: 3, low_alert: 1 }));
    svc = await owner.saveProduct(farm.id, item({ name: 'Delivery run', kind: 'service', unit: 'trip', price: 500, cost: 0, stock: 0, track_stock: false, low_alert: 0 }));
    await owner.saveProduct(farm.id, item({ name: 'Hidden item', active: false }));
    expect(await owner.listProducts(farm.id)).toHaveLength(4);

    const updated = await owner.saveProduct(farm.id, { ...item({ name: 'Fresh milk', category: 'Dairy', kind: 'farm', unit: 'litre', price: 140, cost: 90, stock: 50, low_alert: 10 }) }, milk.id);
    expect(updated.price).toBe(140);
    milk = updated;

    act(c1);
    const visible = await customer.listStoreProducts(farm.id);
    expect(visible.map((p) => p.name)).toEqual(['Delivery run', 'Fresh milk', 'Friesian cow']);
    await expect(owner.saveProduct(farm.id, item({ name: 'Free cow', price: 0 }), cow.id)).rejects.toThrow(/could not be found/);
  });

  test('recording a sale lowers stock and reverses cleanly when deleted', async () => {
    act(o1);
    const sale = await owner.recordSale({ storeId: farm.id, productId: milk.id, qty: 2.5, price: null, customer: 'Jane', note: 'morning', soldAt: null });
    expect(sale).toMatchObject({ qty: 2.5, unit_price: 140, total: 350, customer: 'Jane', product_name: 'Fresh milk' });
    expect(sale.txn_id).toBeTruthy();
    expect(await stockOf(milk.id)).toBe(47.5);

    const cheap = await owner.recordSale({ storeId: farm.id, productId: milk.id, qty: 1, price: 100, customer: '', note: '', soldAt: new Date(Date.now() - 86400000) });
    expect(cheap.total).toBe(100);
    const list = await owner.listSales(farm.id, 50, 0);
    expect(list).toHaveLength(2);
    expect(list[0].id).toBe(sale.id); // newest first
    expect(await owner.lastSaleAt(farm.id)).toBeTruthy();

    await expect(owner.recordSale({ storeId: farm.id, productId: cow.id, qty: 4, price: null, customer: '', note: '', soldAt: null })).rejects.toThrow(/Only 3 head in stock/);
    await owner.recordSale({ storeId: farm.id, productId: svc.id, qty: 5, price: null, customer: '', note: '', soldAt: null });
    expect(await stockOf(svc.id)).toBe(0); // services have no stock to reduce

    act(c1);
    await expect(owner.recordSale({ storeId: farm.id, productId: milk.id, qty: 1, price: null, customer: '', note: '', soldAt: null })).rejects.toThrow(/do not own/);
    expect(await owner.listSales(farm.id)).toEqual([]); // customers cannot read sales

    act(o1);
    await owner.deleteSale(sale.id);
    await owner.deleteSale(cheap.id);
    expect(await stockOf(milk.id)).toBe(50);
    const rest = await owner.listSales(farm.id);
    expect(rest).toHaveLength(1);
    await owner.deleteSale(rest[0].id);
  });

  test('expenses are validated, listed newest first and private to the owner', async () => {
    act(o1);
    const base = { storeId: farm.id, payee: '', spentOn: today() };
    await owner.addExpense({ ...base, category: 'Rent', description: 'Shop rent', amount: 2000 });
    await owner.addExpense({ ...base, category: 'Stock', description: 'Goat meal 20kg', amount: 400 });
    await expect(owner.addExpense({ ...base, category: 'Bribes', description: 'x', amount: 5 })).rejects.toThrow(/not allowed/);
    await expect(owner.addExpense({ ...base, category: 'Rent', description: 'x', amount: 0 })).rejects.toThrow(/amount you paid/);
    const list = await owner.listExpenses(farm.id, 100, 0);
    expect(list.map((e) => e.description)).toEqual(['Goat meal 20kg', 'Shop rent']);

    act(c1);
    expect(await owner.listExpenses(farm.id)).toEqual([]);
    act(o2);
    expect(await owner.listExpenses(farm.id)).toEqual([]);
    await owner.deleteExpense(list[0].id); // not theirs: nothing happens
    act(o1);
    expect(await owner.listExpenses(farm.id)).toHaveLength(2);
    await owner.deleteExpense(list[0].id);
    expect(await owner.listExpenses(farm.id)).toHaveLength(1);
  });

  test('the profit report adds up, filters by period and flags low stock', async () => {
    act(o1);
    const shop = await owner.createStore(o1, { name: 'Numbers Shop', kind: 'shop', description: '', location: '', phone: '', currency: 'KES', payment_info: '' });
    const pen = await owner.saveProduct(shop.id, item({ name: 'Pen', price: 100, stock: 20, low_alert: 5 }));
    await owner.recordSale({ storeId: shop.id, productId: pen.id, qty: 3, price: null, customer: '', note: '', soldAt: null });
    await owner.recordSale({ storeId: shop.id, productId: pen.id, qty: 2, price: 90, customer: '', note: '', soldAt: null });
    await owner.addExpense({ storeId: shop.id, category: 'Rent', description: 'Rent', payee: '', amount: 200, spentOn: today() });
    await owner.addExpense({ storeId: shop.id, category: 'Stock', description: 'Pens', payee: '', amount: 50, spentOn: today() });

    useBiz.getState().bump();
    const a = await owner.getAnalytics(shop.id);
    expect(a).toMatchObject({ revenue: 480, expenses: 250, units: 5, sales_count: 2, product_count: 1, new_orders: 0 });
    expect(a.top_products[0]).toMatchObject({ name: 'Pen', units: 5, revenue: 480 });
    expect(a.expense_breakdown.map((c) => [c.category, Number(c.amount)])).toEqual([['Rent', 200], ['Stock', 50]]);
    expect(a.monthly).toHaveLength(6);
    expect(a.monthly[5]).toMatchObject({ revenue: 480, expenses: 250 });
    expect(a.low_stock).toEqual([]);

    await owner.recordSale({ storeId: shop.id, productId: pen.id, qty: 11, price: null, customer: '', note: '', soldAt: null });
    useBiz.getState().bump();
    expect((await owner.getAnalytics(shop.id)).low_stock.map((p) => p.name)).toEqual(['Pen']);

    // a period with nothing in it
    useBiz.getState().bump();
    const next = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString();
    const later = new Date(new Date().getFullYear(), new Date().getMonth() + 2, 1).toISOString();
    expect(await owner.getAnalytics(shop.id, next, later)).toMatchObject({ revenue: 0, expenses: 0, sales_count: 0 });

    act(o2);
    await expect(owner.getAnalytics(shop.id)).rejects.toThrow(/do not own/);
  });
});

describe('the customer store', () => {
  test('customers find stores and items, and see only what is for sale', async () => {
    act(c1);
    const all = await customer.searchStores('');
    const found = all.find((s) => s.id === farm.id)!;
    expect(found.products?.[0].count).toBe(3); // the hidden item is not counted
    expect((await customer.searchStores('green')).map((s) => s.id)).toContain(farm.id);
    expect((await customer.searchStores(farm.code.toLowerCase())).map((s) => s.id)).toEqual([farm.id]);
    expect(await customer.searchStores('zzzzzz')).toEqual([]);
    // characters that would break a filter are harmless
    await expect(customer.searchStores('a,b(c)%*\\')).resolves.toBeDefined();

    const items = await customer.searchProducts('milk');
    expect(items.map((p) => p.name)).toEqual(['Fresh milk']);
    expect(items[0].store).toMatchObject({ name: 'Green Farm', currency: 'KES', phone: '0722000111' });
    expect((await customer.searchProducts('')).some((p) => p.name === 'Hidden item')).toBe(false);

    const one = await customer.getProduct(milk.id);
    expect(one.store?.payment_info).toBe('M-Pesa Till 123456');
    expect((await customer.getStore(farm.id)).name).toBe('Green Farm');
    await expect(customer.getStore('00000000-0000-0000-0000-000000000000')).rejects.toThrow(/could not be found/);
  });

  test('the wishlist belongs to one customer', async () => {
    act(c1);
    await customer.setWished(c1, milk.id, true);
    await customer.setWished(c1, milk.id, true); // twice is fine
    await customer.setWished(c1, cow.id, true);
    expect((await customer.wishlistIds()).sort()).toEqual([milk.id, cow.id].sort());
    const list = await customer.listWishlist();
    expect(list).toHaveLength(2);
    expect(list[0].store?.name).toBe('Green Farm');
    await customer.setWished(c1, cow.id, false);
    expect(await customer.wishlistIds()).toEqual([milk.id]);

    act(c2);
    expect(await customer.wishlistIds()).toEqual([]);
  });

  test('an order holds stock, shows to the right people, and turns into revenue only when completed', async () => {
    act(c1);
    const order = await customer.placeOrder({
      storeId: farm.id,
      items: [{ productId: milk.id, qty: 2 }, { productId: svc.id, qty: 1 }],
      payMethod: 'mpesa',
      name: 'Chris Customer',
      phone: '0711000111',
      notes: 'Evening pickup',
    });
    expect(order).toMatchObject({ status: 'placed', total: 780, currency: 'KES', customer_name: 'Chris Customer' });
    expect(order.code).toBeTruthy();
    expect(await stockOf(milk.id)).toBe(48); // held straight away

    const mine = await customer.listMyOrders(c1);
    expect(mine).toHaveLength(1);
    expect(mine[0].items).toHaveLength(2);
    expect(mine[0].store?.name).toBe('Green Farm');
    act(c2);
    expect(await customer.listMyOrders(c1)).toEqual([]);

    act(o2);
    expect(await owner.listStoreOrders(farm.id)).toEqual([]);
    act(o1);
    const incoming = await owner.listStoreOrders(farm.id);
    expect(incoming).toHaveLength(1);
    expect(incoming[0].items?.map((i) => i.name).sort()).toEqual(['Delivery run', 'Fresh milk']);
    expect((await owner.getAnalytics(farm.id)).new_orders).toBe(1);

    await owner.setOrderStatus(order.id, 'processing');
    act(c1);
    await expect(customer.cancelMyOrder(order.id)).rejects.toThrow(/not accepted yet/);
    act(o1);
    expect(await owner.listSales(farm.id)).toEqual([]); // not revenue yet
    await owner.setOrderStatus(order.id, 'complete');
    const sales = await owner.listSales(farm.id);
    expect(sales).toHaveLength(2);
    expect(sales.every((s) => s.order_id === order.id)).toBe(true);
    await expect(owner.deleteSale(sales[0].id)).rejects.toThrow(/Cancel the order instead/);
    useBiz.getState().bump();
    expect((await owner.getAnalytics(farm.id)).revenue).toBe(780);

    await owner.setOrderStatus(order.id, 'cancelled');
    expect(await owner.listSales(farm.id)).toEqual([]);
    expect(await stockOf(milk.id)).toBe(50);
    await expect(owner.setOrderStatus(order.id, 'processing')).rejects.toThrow(/cannot be set to/);
  });

  test('orders are checked on the server', async () => {
    act(c1);
    const base = { storeId: farm.id, payMethod: 'cash' as const, name: 'Chris', phone: '0711000111', notes: '' };
    await expect(customer.placeOrder({ ...base, items: [{ productId: cow.id, qty: 4 }] })).rejects.toThrow(/has only 3 head left/);
    await expect(customer.placeOrder({ ...base, items: [] })).rejects.toThrow(/cart is empty/);
    await expect(customer.placeOrder({ ...base, name: 'C', items: [{ productId: milk.id, qty: 1 }] })).rejects.toThrow(/Enter your name/);
    expect(await stockOf(milk.id)).toBe(50);

    act(o1);
    await expect(customer.placeOrder({ ...base, items: [{ productId: milk.id, qty: 1 }] })).rejects.toThrow(/Only customer accounts/);

    // the customer may cancel before the store accepts
    act(c1);
    const o = await customer.placeOrder({ ...base, items: [{ productId: milk.id, qty: 5 }] });
    expect(await stockOf(milk.id)).toBe(45);
    await customer.cancelMyOrder(o.id);
    expect(await stockOf(milk.id)).toBe(50);
  });
});

describe('saving offline: sending twice counts once', () => {
  const ID1 = '11111111-1111-4111-8111-111111111111';
  const ID2 = '22222222-2222-4222-8222-222222222222';
  const EX1 = '33333333-3333-4333-8333-333333333333';

  test('a sale sent twice is recorded once, with the time it really happened', async () => {
    act(o1);
    const before = await stockOf(milk.id);
    const happened = new Date(Date.now() - 3 * 3600 * 1000);
    const input = { storeId: farm.id, productId: milk.id, qty: 2, price: 120, customer: '', note: '', soldAt: happened, clientId: ID1 };
    const first = await owner.recordSale(input);
    const again = await owner.recordSale(input);
    expect(again.id).toBe(first.id);
    expect(new Date(first.sold_at).getTime()).toBe(happened.getTime());
    expect(await stockOf(milk.id)).toBe(before - 2);
    const rows = await sql<{ n: string }>('select count(*) as n from axon_sales where client_id = $1', [ID1]);
    expect(Number(rows[0].n)).toBe(1);

    // a different id is a different sale
    await owner.recordSale({ ...input, clientId: ID2 });
    expect(await stockOf(milk.id)).toBe(before - 4);
    await owner.deleteSale(first.id);
    await owner.deleteSale((await owner.listSales(farm.id, 1))[0].id);
    expect(await stockOf(milk.id)).toBe(before);
  });

  test('an expense sent twice is recorded once, and bad ones are refused', async () => {
    act(o1);
    const input = { storeId: farm.id, category: 'Rent', description: 'Shop rent', payee: '', amount: 5000, spentOn: today(), clientId: EX1 };
    await owner.addExpense(input);
    await owner.addExpense(input);
    const rows = await sql<{ n: string }>('select count(*) as n from axon_expenses where client_id = $1', [EX1]);
    expect(Number(rows[0].n)).toBe(1);

    await expect(owner.addExpense({ ...input, clientId: null, amount: 0 })).rejects.toThrow(/amount you paid/);
    await expect(owner.addExpense({ ...input, clientId: null, category: 'Nonsense' })).rejects.toThrow(/not allowed/i);

    // someone else's business cannot be written to, even with a fresh id
    act(o2);
    await expect(owner.addExpense({ ...input, clientId: ID2 })).rejects.toThrow(/do not own/i);
    act(o1);
    const [e] = await owner.listExpenses(farm.id, 1);
    await owner.deleteExpense(e.id);
  });
});

describe('customers belong to accounts, not to stores', () => {
  test('one customer account orders from two stores; each owner sees only their own orders, and the same customer is recognisable', async () => {
    act(o2);
    const other = await owner.createStore(o2, { name: 'Neighbour Shop', kind: 'shop', description: '', location: '', phone: '', currency: 'KES', payment_info: '' }).catch(async () => (await owner.listMyStores(o2))[0]);
    const theirs = await owner.saveProduct(other.id, item({ name: 'Neighbour item', stock: 10 }));

    act(c2);
    const a = await customer.placeOrder({ storeId: farm.id, items: [{ productId: milk.id, qty: 1 }], payMethod: 'cash', name: 'Casey C', phone: '0700000001', notes: '' });
    const b = await customer.placeOrder({ storeId: other.id, items: [{ productId: theirs.id, qty: 1 }], payMethod: 'cash', name: 'Casey Customer', phone: '0700000002', notes: '' });
    const again = await customer.placeOrder({ storeId: farm.id, items: [{ productId: milk.id, qty: 1 }], payMethod: 'cash', name: 'Casey C', phone: '0700000001', notes: '' });

    act(o1);
    const mine = await owner.listStoreOrders(farm.id);
    expect(mine.some((o) => o.id === b.id)).toBe(false);
    const fromCasey = mine.filter((o) => o.id === a.id || o.id === again.id);
    expect(fromCasey).toHaveLength(2);
    // the same account on both orders, so the owner can tell a returning customer
    expect(fromCasey[0].customer_id).toBe(c2);
    expect(fromCasey[1].customer_id).toBe(c2);

    act(o2);
    const theirOrders = await owner.listStoreOrders(other.id);
    expect(theirOrders.map((o) => o.id)).toEqual([b.id]);
    expect(theirOrders[0].customer_id).toBe(c2);

    for (const o of [a, again]) {
      act(c2);
      await customer.cancelMyOrder(o.id);
    }
    await customer.cancelMyOrder(b.id);
  });
});

describe('payment approval by the store', () => {
  const place = async (payMethod: 'mpesa' | 'cash' | 'bank') => {
    act(c1);
    return customer.placeOrder({ storeId: farm.id, items: [{ productId: milk.id, qty: 1 }], payMethod, name: 'Chris C', phone: '0711000111', notes: '' });
  };
  const row = async (id: string) =>
    (await sql<{ status: string; payment_status: string; payment_approved_at: string | null }>(
      'select status, payment_status, payment_approved_at from axon_orders where id = $1',
      [id],
    ))[0];

  test('a new order waits for the store to approve the payment; approving moves it on', async () => {
    const o = await place('mpesa');
    expect(o.payment_status).toBe('awaiting');
    expect(o.pay_method).toBe('mpesa');

    // only the store that owns the order can approve
    await expect(owner.approvePayment(o.id)).rejects.toThrow(/permission|not allowed/i);
    act(o2);
    await expect(owner.approvePayment(o.id)).rejects.toThrow(/not allowed/i);

    act(o1);
    await owner.approvePayment(o.id);
    expect(await row(o.id)).toMatchObject({ status: 'processing', payment_status: 'approved' });
    expect((await row(o.id)).payment_approved_at).not.toBeNull();
    await owner.approvePayment(o.id); // twice is harmless

    // the customer sees the approval on their own order
    act(c1);
    const mine = (await customer.listMyOrders(c1)).find((x) => x.id === o.id)!;
    expect(mine.payment_status).toBe('approved');

    act(o1);
    await owner.setOrderStatus(o.id, 'complete');
    await owner.setOrderStatus(o.id, 'cancelled');
    await expect(owner.approvePayment(o.id)).rejects.toThrow(/cannot have its payment approved/);
  });

  test('completing an order also marks its payment approved, and a cancelled order cannot be approved', async () => {
    const a = await place('cash');
    act(o1);
    await owner.setOrderStatus(a.id, 'complete');
    expect(await row(a.id)).toMatchObject({ status: 'complete', payment_status: 'approved' });
    await owner.setOrderStatus(a.id, 'cancelled');

    const b = await place('bank');
    act(c1);
    await customer.cancelMyOrder(b.id);
    act(o1);
    await expect(owner.approvePayment(b.id)).rejects.toThrow(/cannot have its payment approved/);
    expect((await row(b.id)).payment_status).toBe('awaiting');
  });
});

describe('suggestions and the admin inbox', () => {
  test('feedback reaches the admin, who can triage it', async () => {
    act(c1);
    await account.submitFeedback({ type: 'feature', priority: 'high', message: 'Please add card payments', includeContact: true });
    act(c2);
    await account.submitFeedback({ type: 'bug', priority: 'low', message: 'The wishlist is slow', includeContact: false });
    expect(await account.myFeedback()).toHaveLength(1);
    act(c1);
    const mine = await account.myFeedback();
    expect(mine.map((f) => f.message)).toEqual(['Please add card payments']);
    await expect(account.submitFeedback({ type: 'bug', priority: 'low', message: 'no', includeContact: false })).rejects.toThrow(/a little more/);

    act(null, '10.7.7.7');
    await expect(account.adminCall('wrong-code', 'login')).rejects.toThrow('Wrong passcode.');
    await account.adminCall('ALM$@cell15', 'login');
    const stats = await account.adminCall<{ owners: number; customers: number; stores: number; feedback: Record<string, number> }>('ALM$@cell15', 'stats');
    expect(stats).toMatchObject({ owners: 2, customers: 2, feedback: { new: 2 } });
    const inbox = await account.adminCall<{ id: string; message: string; contact_email: string | null }[]>('ALM$@cell15', 'list_feedback');
    expect(inbox).toHaveLength(2);
    const withContact = inbox.find((f) => f.message === 'Please add card payments')!;
    expect(withContact.contact_email).toBe('cust1@x.test');
    expect(inbox.find((f) => f.message === 'The wishlist is slow')!.contact_email).toBeFalsy();

    await account.adminCall('ALM$@cell15', 'set_status', { id: withContact.id, status: 'planned' });
    act(c1);
    expect((await account.myFeedback())[0].status).toBe('planned');
    act(null, '10.7.7.7');
    await account.adminCall('ALM$@cell15', 'delete_feedback', { id: withContact.id });
    expect(await account.adminCall<unknown[]>('ALM$@cell15', 'list_feedback')).toHaveLength(1);
  });

  test('repeated wrong passcodes lock that address out, and the passcode can be changed', async () => {
    act(null, '10.9.9.9');
    for (let i = 0; i < 5; i++) await expect(account.adminCall('guess', 'login')).rejects.toThrow('Wrong passcode.');
    await expect(account.adminCall('ALM$@cell15', 'login')).rejects.toThrow(/Too many wrong attempts/);

    act(null, '10.1.1.1');
    await expect(account.adminCall('ALM$@cell15', 'change_code', { new_code: 'short' })).rejects.toThrow(/8 to 64 characters/);
    await account.adminCall('ALM$@cell15', 'change_code', { new_code: 'a-better-code-2026' });
    await expect(account.adminCall('ALM$@cell15', 'login')).rejects.toThrow('Wrong passcode.');
    await account.adminCall('a-better-code-2026', 'login');
  });
});

describe('deleting an account', () => {
  test('a customer leaves; their orders stay for the store but lose the link', async () => {
    act(c1);
    const o = await customer.placeOrder({ storeId: farm.id, items: [{ productId: milk.id, qty: 1 }], payMethod: 'cash', name: 'Chris', phone: '0711000111', notes: '' });
    await account.deleteMyAccount([]);
    expect(await sql('select 1 from axon_profiles where id = $1', [c1])).toEqual([]);
    const [row] = await sql<{ customer_id: string | null }>('select customer_id from axon_orders where id = $1', [o.id]);
    expect(row.customer_id).toBeNull();
  });

  test('an owner leaves and the businesses go with them', async () => {
    act(o2);
    const mine = await owner.listMyStores(o2);
    expect(mine).toHaveLength(10);
    await account.deleteMyAccount(mine.map((s) => s.id));
    expect(await sql('select 1 from axon_stores where owner_id = $1', [o2])).toEqual([]);
    expect(await sql('select 1 from axon_profiles where id = $1', [o2])).toEqual([]);
  });
});
