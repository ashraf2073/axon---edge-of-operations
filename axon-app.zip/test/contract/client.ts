import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { spawn, type ChildProcess } from 'node:child_process';
import * as http from 'node:http';
import * as path from 'node:path';

/** Who the next requests are sent as, and from which address. */
export const as = { user: null as string | null, ip: '10.0.0.1' };

let baseUrl = '';
let child: ChildProcess | null = null;
let client: SupabaseClient | null = null;

class MiniResponse {
  readonly ok: boolean;
  readonly headers = { get: (name: string) => this.headerMap[name.toLowerCase()] ?? null };
  constructor(
    readonly status: number,
    readonly statusText: string,
    private headerMap: Record<string, string>,
    private bodyText: string,
  ) {
    this.ok = status >= 200 && status < 300;
  }
  async text() {
    return this.bodyText;
  }
  async json() {
    return JSON.parse(this.bodyText);
  }
  clone() {
    return new MiniResponse(this.status, this.statusText, this.headerMap, this.bodyText);
  }
}

function request(url: string, method: string, headers: Record<string, string>, body?: string): Promise<MiniResponse> {
  return new Promise((resolve, reject) => {
    const req = http.request(url, { method, headers, agent: false }, (res) => {
      const parts: Buffer[] = [];
      res.on('data', (c) => parts.push(c));
      res.on('end', () => {
        const map: Record<string, string> = {};
        Object.entries(res.headers).forEach(([k, v]) => (map[k.toLowerCase()] = String(v)));
        resolve(new MiniResponse(res.statusCode ?? 0, res.statusMessage ?? '', map, Buffer.concat(parts).toString('utf8')));
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

function fetchLike(input: unknown, init?: { method?: string; headers?: unknown; body?: unknown }) {
  const headers: Record<string, string> = {};
  const raw = init?.headers as { forEach?: (cb: (v: string, k: string) => void) => void } | Record<string, string> | undefined;
  if (raw && typeof (raw as { forEach?: unknown }).forEach === 'function') {
    (raw as { forEach: (cb: (v: string, k: string) => void) => void }).forEach((v, k) => (headers[k.toLowerCase()] = v));
  } else if (raw) {
    Object.entries(raw).forEach(([k, v]) => (headers[k.toLowerCase()] = String(v)));
  }
  if (as.user) headers['x-test-user'] = as.user;
  headers['x-forwarded-for'] = as.ip;
  return request(String(input), init?.method ?? 'GET', headers, init?.body ? String(init.body) : undefined);
}

export async function startServer(): Promise<void> {
  child = spawn(process.execPath, [path.join(__dirname, 'server.mjs')], { stdio: ['ignore', 'pipe', 'pipe'] });
  const port = await new Promise<number>((resolve, reject) => {
    const fail = (m: string) => reject(new Error(`test server: ${m}`));
    let log = '';
    child!.stdout!.on('data', (d) => {
      log += String(d);
      const m = /READY (\d+)/.exec(log);
      if (m) resolve(Number(m[1]));
    });
    child!.stderr!.on('data', (d) => (log += String(d)));
    child!.on('exit', () => fail(`exited early. ${log.slice(0, 600)}`));
    setTimeout(() => fail(`did not start. ${log.slice(0, 600)}`), 50000);
  });
  baseUrl = `http://127.0.0.1:${port}`;
  client = createClient(baseUrl, 'test-anon-key', {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: fetchLike as unknown as typeof fetch },
  });
}

export function stopServer() {
  child?.removeAllListeners('exit');
  child?.stdout?.destroy();
  child?.stderr?.destroy();
  child?.kill();
}

/** The object the app's code imports as `supabase`. */
export const supabaseProxy = new Proxy({} as SupabaseClient, {
  get: (_t, prop) => {
    if (!client) throw new Error('test server not started');
    return (client as unknown as Record<string | symbol, unknown>)[prop];
  },
});

export async function control<T = unknown>(route: string, body: unknown): Promise<T> {
  const res = await request(`${baseUrl}/__test/${route}`, 'POST', { 'content-type': 'application/json' }, JSON.stringify(body));
  const json = JSON.parse(await res.text());
  if (!res.ok) throw new Error(`control ${route}: ${json.message}`);
  return json as T;
}

export async function signup(role: 'owner' | 'customer', email: string, name: string, password?: string): Promise<string> {
  return (await control<{ id: string }>('signup', { role, email, name, password })).id;
}

export async function sql<T = Record<string, unknown>>(query: string, params: unknown[] = []): Promise<T[]> {
  return (await control<{ rows: T[] }>('sql', { sql: query, params })).rows;
}
