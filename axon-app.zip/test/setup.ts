// Shared setup for every test file.
//
// Native pieces are replaced with light stand-ins, and the whole cloud backend
// is replaced with the in-memory one in test/mockApi.ts, so tests run offline.

jest.mock('@react-native-async-storage/async-storage', () =>
  require('@react-native-async-storage/async-storage/jest/async-storage-mock'),
);

// The real provider waits for the native side to report screen insets, which never happens in a test.
jest.mock('react-native-safe-area-context', () => require('react-native-safe-area-context/jest/mock').default);

jest.mock('expo-font', () => ({
  ...jest.requireActual('expo-font'),
  useFonts: () => [true, null],
  isLoaded: () => true,
  loadAsync: async () => undefined,
}));

jest.mock('expo-splash-screen', () => ({
  preventAutoHideAsync: async () => true,
  hideAsync: async () => true,
}));

jest.mock('@react-native-community/netinfo', () => require('./mockNet').netInfoModule);

jest.mock('../src/lib/supabase', () => ({ supabase: require('./mockApi').supabase }));
jest.mock('../src/api/account', () => require('./mockApi').accountApi);
jest.mock('../src/api/owner', () => require('./mockApi').ownerApi);
jest.mock('../src/api/customer', () => require('./mockApi').customerApi);
