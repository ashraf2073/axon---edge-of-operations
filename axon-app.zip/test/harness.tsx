import AsyncStorage from '@react-native-async-storage/async-storage';
import { act, render, screen, waitFor } from '@testing-library/react-native';
import React from 'react';
import App from '../App';
import { useBiz } from '../src/state/biz';
import { useCart } from '../src/state/cart';
import { useNet } from '../src/state/net';
import { useOutbox } from '../src/state/outbox';
import { usePrefs } from '../src/state/prefs';
import { useSession } from '../src/state/session';
import { useWishlist } from '../src/state/wishlist';
import { backend, resetBackend } from './fakeBackend';
import { resetNet } from './mockNet';

/** Waiting for the real 1.6 second splash, then data, needs more than the 1 second default. */
export const SLOW = { timeout: 8000 };

export async function resetAll() {
  resetBackend();
  resetNet();
  await AsyncStorage.clear();
  useNet.setState(useNet.getInitialState(), true);
  useOutbox.setState(useOutbox.getInitialState(), true);
  useSession.setState(useSession.getInitialState(), true);
  usePrefs.setState(usePrefs.getInitialState(), true);
  useCart.setState(useCart.getInitialState(), true);
  useWishlist.setState(useWishlist.getInitialState(), true);
  useBiz.setState(useBiz.getInitialState(), true);
}

export async function giveConsent() {
  await AsyncStorage.setItem('axon.consent.v1', JSON.stringify({ at: new Date().toISOString(), contact: false }));
}

/** Pretend this person is already logged in when the app opens. */
export function loginAs(profileId: string) {
  const acc = backend.accounts.find((a) => a.id === profileId);
  if (!acc) throw new Error(`no such account ${profileId}`);
  backend.session = { user: { id: acc.id, email: acc.email } };
}

export async function openApp() {
  await render(<App />);
}

export async function pause(ms: number) {
  await act(async () => {
    await new Promise((r) => setTimeout(r, ms));
  });
}

export { act, screen, waitFor };
