import { openApp, resetAll, screen, SLOW, waitFor } from './harness';

beforeEach(resetAll);

test('without Supabase settings the app explains the one setup step', async () => {
  await openApp();
  await waitFor(() => expect(screen.getByText(/One setup step left/i)).toBeTruthy(), SLOW);
  expect(screen.getByText(/supabase\.com/i)).toBeTruthy();
});
