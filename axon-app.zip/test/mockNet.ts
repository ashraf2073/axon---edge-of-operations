/**
 * A stand-in for the phone's connection monitor. Tests flip it with goOffline and goOnline,
 * which also make every pretend cloud request fail or work to match.
 */
import { backend } from './fakeBackend';

interface FakeNetState {
  isConnected: boolean;
  isInternetReachable: boolean;
}

let state: FakeNetState = { isConnected: true, isInternetReachable: true };
const listeners = new Set<(s: FakeNetState) => void>();

const notify = () => listeners.forEach((cb) => cb(state));

export function resetNet() {
  state = { isConnected: true, isInternetReachable: true };
  listeners.clear();
}

/** The phone loses its connection and the cloud cannot be reached. */
export function goOffline() {
  backend.offline = true;
  state = { isConnected: false, isInternetReachable: false };
  notify();
}

/** The connection comes back. */
export function goOnline() {
  backend.offline = false;
  backend.tokenExpired = false;
  state = { isConnected: true, isInternetReachable: true };
  notify();
}

export const netInfoModule = {
  __esModule: true,
  default: {
    configure: () => undefined,
    addEventListener: (cb: (s: FakeNetState) => void) => {
      listeners.add(cb);
      void Promise.resolve().then(() => cb(state));
      return () => listeners.delete(cb);
    },
    fetch: async () => state,
    refresh: async () => state,
  },
};
