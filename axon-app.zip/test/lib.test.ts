import { analysisAdvice, smartTips, totals } from '../src/lib/analytics';
import { money, num, parseNumber, periodRange } from '../src/lib/format';
import { cartTotal, useCart } from '../src/state/cart';
import { useBiz } from '../src/state/biz';
import type { Analytics, Product } from '../src/types';

const base: Analytics = {
  revenue: 0,
  expenses: 0,
  units: 0,
  sales_count: 0,
  monthly: [],
  top_products: [],
  expense_breakdown: [],
  low_stock: [],
  new_orders: 0,
  open_orders: 0,
  product_count: 3,
};

describe('profit maths', () => {
  test('profit is revenue minus expenses and margin is profit over revenue', () => {
    expect(totals({ revenue: 1000, expenses: 400 })).toEqual({ revenue: 1000, expenses: 400, profit: 600, margin: 60 });
    expect(totals({ revenue: 0, expenses: 250 })).toMatchObject({ profit: -250, margin: 0 });
  });

  test('advice follows the situation of the business', () => {
    const loss = analysisAdvice(
      { ...base, revenue: 100, expenses: 500, expense_breakdown: [{ category: 'Rent', amount: 400 }] },
      'KES',
    )!;
    expect(loss.tone).toBe('bad');
    expect(loss.body).toContain('KSh 400 loss');
    expect(loss.body).toContain('Rent');

    expect(analysisAdvice({ ...base, revenue: 1000, expenses: 950 }, 'KES')!.title).toBe('Thin profit margin');
    const decent = analysisAdvice({ ...base, revenue: 1000, expenses: 800 }, 'KES')!;
    expect(decent.title).toBe('Decent profit');
    expect(decent.body).toContain('KSh 50'); // 25% of 200
    const great = analysisAdvice({ ...base, revenue: 1000, expenses: 500 }, 'KES')!;
    expect(great.title).toBe('Excellent performance');
    expect(great.body).toContain('KSh 150'); // 30% of 500
    expect(analysisAdvice(base, 'KES')).toBeNull();
  });

  test('tips ask for missing records and flag low stock', () => {
    const tips = smartTips(
      { ...base, low_stock: [{ id: 'p', name: 'Eggs', stock: 2, low_alert: 5, unit: 'tray' }] },
      'KES',
      null,
    );
    const titles = tips.map((t) => t.title);
    expect(titles).toContain('Record your first sale');
    expect(titles).toContain('Log your expenses');
    expect(titles).toContain('Low stock alert');
  });
});

describe('formatting', () => {
  test('money and numbers read the way shop owners expect', () => {
    expect(money(1234.5, 'KES')).toBe('KSh 1,234.50');
    expect(money(130, 'KES')).toBe('KSh 130');
    expect(money(-50, 'KES')).toBe('-KSh 50');
    expect(money(12400, 'KES', true)).toBe('KSh 12.4K');
    expect(money(2500000, 'USD', true)).toBe('$2.50M');
    expect(num(2.5, 3)).toBe('2.5');
    expect(num(2.25, 3)).toBe('2.25');
    expect(num(1500, 3)).toBe('1,500');
    expect(num(60, 1)).toBe('60');
    expect(num(12.5, 1)).toBe('12.5');
    expect(num(0.001, 3)).toBe('0.001');
    expect(parseNumber('1,250.5')).toBe(1250.5);
    expect(parseNumber('abc')).toBeNaN();
  });

  test('a month period starts on the 1st and ends on the 1st of next month', () => {
    const r = periodRange('month', new Date(2026, 9, 24, 15, 0, 0));
    expect(new Date(r.from!).getTime()).toBe(new Date(2026, 9, 1).getTime());
    expect(new Date(r.to!).getTime()).toBe(new Date(2026, 10, 1).getTime());
    expect(periodRange('all')).toEqual({ from: null, to: null });
  });
});

describe('cart rules', () => {
  const store = { id: 's1', name: 'Farm', currency: 'KES' as const };
  const other = { id: 's2', name: 'Shop', currency: 'KES' as const };
  const milk = { id: 'm', name: 'Milk', price: 130, unit: 'litre', image_url: null, track_stock: true, stock: 3 } as Product;
  const soap = { id: 'x', name: 'Soap', price: 50, unit: 'piece', image_url: null, track_stock: false, stock: 0 } as Product;
  const gone = { ...milk, id: 'g', stock: 0 } as Product;

  beforeEach(() => useCart.setState(useCart.getInitialState(), true));

  test('quantity is capped by stock and the total is exact', () => {
    expect(useCart.getState().add(store, milk, 2)).toBe('added');
    expect(useCart.getState().add(store, milk, 5)).toBe('added');
    expect(useCart.getState().items[0].qty).toBe(3);
    useCart.getState().setQty('m', 10);
    expect(useCart.getState().items[0].qty).toBe(3);
    useCart.getState().add(store, soap, 2);
    expect(cartTotal(useCart.getState())).toBe(3 * 130 + 2 * 50);
  });

  test('a cart holds one store at a time and sold-out items are refused', () => {
    useCart.getState().add(store, milk, 1);
    expect(useCart.getState().add(other, soap, 1)).toBe('other-store');
    expect(useCart.getState().add(store, gone, 1)).toBe('sold-out');
    useCart.getState().startNew(other, soap, 1);
    expect(useCart.getState().store?.id).toBe('s2');
    expect(useCart.getState().items).toHaveLength(1);
    useCart.getState().remove('x');
    expect(useCart.getState().store).toBeNull();
  });
});

describe('shared analytics requests', () => {
  // The real owner API, with the backend client replaced by a counter.
  const { supabase } = require('./mockApi') as { supabase: { rpc: jest.Mock } };
  const { getAnalytics } = jest.requireActual('../src/api/owner') as typeof import('../src/api/owner');

  test('identical questions at the same moment share one request, and a change forces a new one', async () => {
    supabase.rpc = jest.fn(async () => ({ data: { ...base, revenue: 5 }, error: null }));
    const [a, b, c] = await Promise.all([getAnalytics('s1'), getAnalytics('s1'), getAnalytics('s1')]);
    expect(supabase.rpc).toHaveBeenCalledTimes(1);
    expect(a).toBe(b);
    expect(c.revenue).toBe(5);

    // a different business or period is a different question
    await Promise.all([getAnalytics('s2'), getAnalytics('s1', '2026-01-01', '2026-02-01')]);
    expect(supabase.rpc).toHaveBeenCalledTimes(3);

    // after a sale (the version goes up) nothing stale is reused, even if an old request is still running
    const releases: (() => void)[] = [];
    supabase.rpc = jest.fn(
      () =>
        new Promise((resolve) => {
          releases.push(() => resolve({ data: base, error: null }));
        }),
    );
    const before = getAnalytics('s1');
    useBiz.getState().bump();
    const after = getAnalytics('s1');
    expect(supabase.rpc).toHaveBeenCalledTimes(2);
    releases.forEach((r) => r());
    await Promise.all([before, after]);
  });

  test('a failed request is not remembered', async () => {
    supabase.rpc = jest.fn().mockResolvedValueOnce({ data: null, error: { message: 'Network request failed' } });
    await expect(getAnalytics('s9')).rejects.toThrow('No internet connection');
    supabase.rpc = jest.fn(async () => ({ data: base, error: null }));
    await expect(getAnalytics('s9')).resolves.toBeTruthy();
    expect(supabase.rpc).toHaveBeenCalledTimes(1);
  });
});

import { groupCustomers } from '../src/lib/customers';
import { friendly, isNetworkError } from '../src/lib/errors';
import { newId } from '../src/lib/ids';
import type { Order } from '../src/types';

const order = (over: Partial<Order>): Order => ({
  id: 'o', code: 'ORD', store_id: 's', customer_id: 'c1', customer_name: 'Casey', customer_phone: '0700', pay_method: 'cash',
  notes: '', total: 100, currency: 'KES', status: 'complete', payment_status: 'approved', payment_approved_at: null, created_at: '2026-10-01T10:00:00Z', updated_at: '', ...over,
});

test('customers are told apart by account, so a returning one is recognised', () => {
  const list = groupCustomers([
    order({ id: '1', created_at: '2026-10-01T10:00:00Z' }),
    order({ id: '2', created_at: '2026-10-05T10:00:00Z', customer_name: 'Casey C', customer_phone: '0711', total: 250 }),
    order({ id: '3', customer_id: 'c2', customer_name: 'Brian', total: 40, status: 'placed' }),
    order({ id: '4', customer_id: 'c3', customer_name: 'Gone', status: 'cancelled' }),
    order({ id: '5', customer_id: null, customer_name: 'Deleted account', customer_phone: '0799' }),
  ]);
  const casey = list.find((c) => c.key === 'c1')!;
  expect(casey).toMatchObject({ orders: 2, spent: 350, name: 'Casey C', phone: '0711' });
  expect(list.find((c) => c.key === 'c2')).toMatchObject({ orders: 1, open: 1, spent: 0 });
  expect(list.some((c) => c.key === 'c3')).toBe(false); // only cancelled: not a customer yet
  expect(list.some((c) => c.key === 'phone:0799')).toBe(true);
});

test('connection problems are told apart from real refusals', () => {
  expect(isNetworkError(new Error('Network request failed'))).toBe(true);
  expect(isNetworkError({ message: 'TypeError: Network request failed' })).toBe(true);
  expect(isNetworkError({ name: 'AuthRetryableFetchError', message: 'x' })).toBe(true);
  expect(isNetworkError(new Error(friendly('Failed to fetch')))).toBe(true);
  expect(isNetworkError(new Error('Only 2 tray in stock'))).toBe(false);
  expect(friendly({ message: 'Token has expired or is invalid' })).toMatch(/code is wrong or has expired/);
});

test('made-up ids look like real ones and do not repeat', () => {
  const ids = new Set(Array.from({ length: 200 }, () => newId()));
  expect(ids.size).toBe(200);
  expect([...ids][0]).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
});
