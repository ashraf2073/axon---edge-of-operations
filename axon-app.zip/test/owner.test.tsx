jest.mock('../src/config', () => ({ ...jest.requireActual('../src/config'), IS_CONFIGURED: true }));

import { fireEvent } from '@testing-library/react-native';
import { backend, seedWorld } from './fakeBackend';
import { giveConsent, loginAs, openApp, resetAll, screen, SLOW, waitFor } from './harness';

beforeEach(resetAll);

async function openAsOwner() {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.owner.id);
  await openApp();
  await screen.findByText('Profit, all time', {}, SLOW);
  return w;
}

test('a signed-in owner lands on the dashboard of their business', async () => {
  await openAsOwner();
  expect(screen.getAllByText('Mama Njeri Farm').length).toBeGreaterThan(0);
  expect(screen.getByText('Hello, Amina')).toBeTruthy();
  // eggs are at their low-stock level of 5
  expect(screen.getByText(/Eggs tray: 5 tray left/)).toBeTruthy();
  // the store code customers use to find the shop
  expect(screen.getByText('FARM2345')).toBeTruthy();
});

test('selling an item lowers its stock and raises revenue and profit', async () => {
  const w = await openAsOwner();

  await fireEvent.press(screen.getByText('Stock'));
  await fireEvent.press(await screen.findByLabelText('Sell Fresh milk', {}, SLOW));
  await screen.findByText('Record a sale', {}, SLOW);
  await fireEvent.press(screen.getByLabelText('Increase quantity'));
  await fireEvent.press(screen.getByText('Save sale'));

  await waitFor(() => expect(backend.sales).toHaveLength(1), SLOW);
  expect(backend.sales[0].qty).toBe(2);
  expect(backend.sales[0].total).toBe(260);
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(38);

  await fireEvent.press(screen.getByText('Home'));
  await waitFor(() => expect(screen.getAllByText('KSh 260').length).toBeGreaterThan(0), SLOW);
});

test('an expense bought by quantity fills the total, and a loss brings advice', async () => {
  await openAsOwner();

  await fireEvent.press(screen.getByText('Costs'));
  await fireEvent.press(await screen.findByText('Add expense', {}, SLOW));
  await fireEvent.changeText(await screen.findByPlaceholderText('e.g. Shop rent for May'), 'Shop rent for May');
  await fireEvent.changeText(screen.getByPlaceholderText('Quantity'), '1');
  await fireEvent.changeText(screen.getByPlaceholderText('Price each'), '5000');
  // the price-each box and the auto-filled total both show 5000
  await waitFor(() => expect(screen.getAllByDisplayValue('5000')).toHaveLength(2), SLOW);
  await fireEvent.press(screen.getByText('Save expense'));

  await waitFor(() => expect(backend.expenses).toHaveLength(1), SLOW);
  expect(backend.expenses[0]).toMatchObject({ category: 'Rent', amount: 5000, description: 'Shop rent for May' });

  await fireEvent.press(screen.getByText('Profit'));
  await waitFor(() => expect(screen.getAllByText('You are running at a loss').length).toBeGreaterThan(0), SLOW);
});
