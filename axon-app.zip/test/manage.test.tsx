jest.mock('../src/config', () => ({ ...jest.requireActual('../src/config'), IS_CONFIGURED: true }));

import { fireEvent } from '@testing-library/react-native';
import { Alert, Share } from 'react-native';
import { toDateKey } from '../src/lib/format';
import { backend, nextId, seedWorld } from './fakeBackend';
import { giveConsent, loginAs, openApp, resetAll, screen, SLOW, waitFor } from './harness';
import { customerApi, ownerApi } from './mockApi';

beforeEach(async () => {
  jest.restoreAllMocks();
  await resetAll();
});

const type = async (placeholder: string, text: string, index = 0) =>
  fireEvent.changeText(screen.getAllByPlaceholderText(placeholder)[index], text);

function answerAlert(label: string) {
  return jest.spyOn(Alert, 'alert').mockImplementation((_title, _message, buttons) => {
    buttons?.find((b) => b.text === label)?.onPress?.();
  });
}

async function openAsOwner() {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.owner.id);
  await openApp();
  await screen.findByText('Profit, all time', {}, SLOW);
  return w;
}

test('an owner adds a second business and switches to it', async () => {
  await openAsOwner();

  await fireEvent.press(screen.getAllByLabelText('Open business menu for Mama Njeri Farm')[0]);
  await fireEvent.press(await screen.findByText('Businesses', {}, SLOW));
  await screen.findByText('Your businesses', {}, SLOW);
  expect(screen.getByText('1 of 10')).toBeTruthy();

  await fireEvent.press(screen.getByLabelText('Add another business'));
  await type('e.g. Mama Njeri Farm', 'Njeri Supermarket');
  await fireEvent.press(screen.getByLabelText('Create business'));
  await waitFor(() => expect(backend.stores).toHaveLength(2), SLOW);

  // back on the list, the new one is open
  await screen.findByText('2 of 10', {}, SLOW);
  await fireEvent.press(screen.getByLabelText('Go to dashboard'));
  await screen.findByText('Profit, all time', {}, SLOW);
  expect(screen.getAllByText('Njeri Supermarket').length).toBeGreaterThan(0);
  // a new business starts with clean numbers, separate from the farm
  expect(screen.getAllByText('KSh 0').length).toBeGreaterThan(0);
  expect(screen.queryByText(/Eggs tray/)).toBeNull();
});

test('an owner edits an item price and then deletes the item', async () => {
  const w = await openAsOwner();

  await fireEvent.press(screen.getByText('Stock'));
  await fireEvent.press(await screen.findByLabelText('Fresh milk, KSh 130', {}, SLOW));
  await screen.findByText('Edit item', {}, SLOW);
  await fireEvent.changeText(screen.getByLabelText(/^Selling price per/), '150');
  await fireEvent.press(screen.getByLabelText('Save changes'));
  await waitFor(() => expect(backend.products.find((p) => p.id === w.milk.id)!.price).toBe(150), SLOW);

  answerAlert('Delete');
  await fireEvent.press(await screen.findByLabelText('Fresh milk, KSh 150', {}, SLOW));
  await fireEvent.press(await screen.findByLabelText('Delete item', {}, SLOW));
  await waitFor(() => expect(backend.products.some((p) => p.id === w.milk.id)).toBe(false), SLOW);
});

test('the profit report adds up sales minus costs and gives advice', async () => {
  const w = await openAsOwner();
  const now = new Date();
  backend.sales.push({
    id: nextId('sale'),
    store_id: w.store.id,
    product_id: w.milk.id,
    order_id: null,
    product_name: 'Fresh milk',
    unit: 'litre',
    txn_id: 'TXN-TEST1',
    qty: 10,
    unit_price: 100,
    total: 1000,
    customer: '',
    note: '',
    sold_at: now.toISOString(),
  });
  backend.expenses.push({
    id: nextId('exp'),
    store_id: w.store.id,
    category: 'Rent',
    description: 'Shop rent',
    payee: '',
    amount: 400,
    spent_on: toDateKey(now),
    created_at: now.toISOString(),
  });
  const share = jest.spyOn(Share, 'share').mockResolvedValue({ action: Share.sharedAction, activityType: undefined });

  await fireEvent.press(screen.getByText('Profit'));
  await screen.findByText('Profit and loss', {}, SLOW);
  await screen.findByText('Margin 60% of revenue', {}, SLOW);
  expect(screen.getAllByText('KSh 600').length).toBeGreaterThan(0);
  expect(screen.getByText('Excellent performance')).toBeTruthy();
  expect(screen.getByText('Spending by category')).toBeTruthy();

  await fireEvent.press(screen.getByLabelText('Share this report'));
  await waitFor(() => expect(share).toHaveBeenCalled(), SLOW);
  const message = (share.mock.calls[0][0] as { message: string }).message;
  expect(message).toContain('Mama Njeri Farm - profit and loss');
  expect(message).toContain('Profit: KSh 600');
});

test('deleting a manual sale puts the stock back, and an expense can be removed', async () => {
  const w = await openAsOwner();
  await ownerApi.recordSale({ storeId: w.store.id, productId: w.milk.id, qty: 4, price: 130, customer: '', note: '', soldAt: null });
  await ownerApi.addExpense({
    storeId: w.store.id,
    category: 'Utilities',
    description: 'Electricity',
    payee: '',
    amount: 800,
    spentOn: toDateKey(new Date()),
  });
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(36);
  answerAlert('Delete');

  await fireEvent.press(screen.getByText('Sales'));
  await fireEvent.press(await screen.findByLabelText('Delete sale', {}, SLOW));
  await waitFor(() => expect(backend.sales).toHaveLength(0), SLOW);
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(40);

  await fireEvent.press(screen.getByText('Costs'));
  await fireEvent.press(await screen.findByLabelText('Delete expense', {}, SLOW));
  await waitFor(() => expect(backend.expenses).toHaveLength(0), SLOW);
});

test('a customer can cancel an order the store has not accepted yet', async () => {
  const w = seedWorld();
  backend.session = { user: { id: w.customer.id, email: w.customer.email } };
  await customerApi.placeOrder({
    storeId: w.store.id,
    items: [{ productId: w.eggs.id, qty: 2 }],
    payMethod: 'cash',
    name: 'Brian Buyer',
    phone: '0712345678',
    notes: '',
  });
  expect(backend.products.find((p) => p.id === w.eggs.id)!.stock).toBe(3);
  await giveConsent();
  await openApp();
  answerAlert('Cancel order');

  await fireEvent.press(await screen.findByText('Orders', {}, SLOW));
  await fireEvent.press(await screen.findByLabelText('Cancel order', {}, SLOW));
  await waitFor(() => expect(backend.orders[0].status).toBe('cancelled'), SLOW);
  expect(backend.products.find((p) => p.id === w.eggs.id)!.stock).toBe(5);
});
