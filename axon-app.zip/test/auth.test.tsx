jest.mock('../src/config', () => ({ ...jest.requireActual('../src/config'), IS_CONFIGURED: true }));

import { fireEvent } from '@testing-library/react-native';
import { backend, seedWorld } from './fakeBackend';
import { giveConsent, openApp, resetAll, screen, SLOW } from './harness';
import { goOffline } from './mockNet';

beforeEach(resetAll);

const type = async (placeholder: string, text: string, index = 0) =>
  fireEvent.changeText(screen.getAllByPlaceholderText(placeholder)[index], text);

async function toLogin(button: 'Log in as business' | 'Log in as customer') {
  await giveConsent();
  await openApp();
  await fireEvent.press(await screen.findByLabelText(button, {}, SLOW));
}

test('first launch asks for agreement before anything else', async () => {
  await openApp();
  await screen.findByText('Before you start', {}, SLOW);

  // continuing without agreeing is refused
  await fireEvent.press(screen.getByLabelText('Agree and continue'));
  expect(screen.getByText('You need to agree to use AXON.')).toBeTruthy();

  await fireEvent.press(screen.getAllByRole('checkbox')[0]);
  await fireEvent.press(screen.getByLabelText('Agree and continue'));
  await screen.findByText('How will you use AXON?', {}, SLOW);
});

test('a wrong password is explained, not hidden', async () => {
  seedWorld();
  await toLogin('Log in as business');
  await type('you@example.com', 'owner@axon.test');
  await type('Your password', 'not-the-password');
  await fireEvent.press(screen.getByLabelText('Log in'));
  await screen.findByText('Wrong email or password.', {}, SLOW);
});

test('logging in on the wrong side tells the person which side to use', async () => {
  seedWorld();
  await toLogin('Log in as customer');
  // this email belongs to the store owner
  await type('you@example.com', 'owner@axon.test');
  await type('Your password', 'secret-pass-1');
  await fireEvent.press(screen.getByLabelText('Log in'));
  await screen.findByText(/belongs to a store owner account/, {}, SLOW);
  // still on the login screen and signed out
  expect(screen.getByLabelText('Log in')).toBeTruthy();
  expect(backend.session).toBeNull();
});

test('a business owner can sign up and create a business', async () => {
  await giveConsent();
  await openApp();
  await fireEvent.press(await screen.findByLabelText('Create a business account', {}, SLOW));

  // sign-up form
  await type('Your name', 'Wanjiru Maina');
  await type('you@example.com', 'wanjiru@axon.test');
  await type('07XX XXX XXX', '0700111222');
  await type('At least 8 characters', 'hunter2hunter2');
  await type('Type it again', 'hunter2hunter2');
  await fireEvent.press(screen.getByRole('checkbox'));
  await fireEvent.press(screen.getByLabelText('Create account'));

  // straight to the business profile: no security questions any more
  await screen.findByText('Last step before you start', {}, SLOW);
  await type('e.g. Mama Njeri Farm', 'Wanjiru General Store');
  await fireEvent.press(screen.getByLabelText('Create business'));

  // and the owner lands on the dashboard of the new business
  await screen.findByText('Profit, all time', {}, SLOW);
  expect(screen.getAllByText('Wanjiru General Store').length).toBeGreaterThan(0);
  expect(backend.stores).toHaveLength(1);
});

test('a forgotten password is reset with a code from the email, then the new one works', async () => {
  seedWorld();
  await toLogin('Log in as business');
  await fireEvent.press(screen.getByText('Forgot password?'));
  await type('you@example.com', 'owner@axon.test');
  await fireEvent.press(screen.getByLabelText('Send code'));

  await screen.findByText('Code from the email', {}, SLOW);
  expect(backend.resetCodes['owner@axon.test']).toBe('123456');

  // a wrong code is refused and nothing changes
  await type('6-digit code', '000000');
  await type('At least 8 characters', 'brand-new-pass');
  await type('Type it again', 'brand-new-pass');
  await fireEvent.press(screen.getByLabelText('Reset password'));
  await screen.findByText(/That code is wrong or has expired/, {}, SLOW);
  expect(backend.accounts[0].password).toBe('secret-pass-1');

  // the right code changes the password, and the screen stays put while the person is briefly signed in
  await type('6-digit code', '123 456');
  await fireEvent.press(screen.getByLabelText('Reset password'));
  await screen.findByText('Password changed', {}, SLOW);
  expect(backend.accounts[0].password).toBe('brand-new-pass');
  expect(backend.session).toBeNull();

  // back at the start, the new password logs in and the old one does not
  await fireEvent.press(screen.getByLabelText('Back to start'));
  await fireEvent.press(await screen.findByLabelText('Log in as business', {}, SLOW));
  await type('you@example.com', 'owner@axon.test');
  await type('Your password', 'secret-pass-1');
  await fireEvent.press(screen.getByLabelText('Log in'));
  await screen.findByText('Wrong email or password.', {}, SLOW);
  await type('Your password', 'brand-new-pass');
  await fireEvent.press(screen.getByLabelText('Log in'));
  await screen.findByText('Profit, all time', {}, SLOW);
});

test('asking for a reset code for an unknown email looks the same and sends nothing', async () => {
  seedWorld();
  await toLogin('Log in as customer');
  await fireEvent.press(screen.getByText('Forgot password?'));
  await type('you@example.com', 'nobody@axon.test');
  await fireEvent.press(screen.getByLabelText('Send code'));
  await screen.findByText('Code from the email', {}, SLOW);
  expect(backend.resetCodes).toEqual({});
});

test('asking for a reset code without a connection says so', async () => {
  seedWorld();
  await toLogin('Log in as business');
  await fireEvent.press(screen.getByText('Forgot password?'));
  await type('you@example.com', 'owner@axon.test');
  goOffline();
  await fireEvent.press(screen.getByLabelText('Send code'));
  await screen.findByText(/No internet connection/, {}, SLOW);
  expect(screen.queryByText('Code from the email')).toBeNull();
});
