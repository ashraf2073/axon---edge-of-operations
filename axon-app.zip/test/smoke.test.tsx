import { render, screen } from '@testing-library/react-native';
import React from 'react';
import { Logo } from '../src/ui/Logo';
import { Text } from '../src/ui/Text';

test('renders text and the logo', async () => {
  await render(
    <>
      <Logo size={40} />
      <Text>hello axon</Text>
    </>,
  );
  expect(screen.getByText('hello axon')).toBeTruthy();
});
