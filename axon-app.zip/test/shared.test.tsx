jest.mock('../src/config', () => ({ ...jest.requireActual('../src/config'), IS_CONFIGURED: true }));

import { fireEvent } from '@testing-library/react-native';
import { Alert, Linking } from 'react-native';
import { backend, seedWorld } from './fakeBackend';
import { giveConsent, loginAs, openApp, resetAll, screen, SLOW, waitFor } from './harness';

beforeEach(async () => {
  jest.restoreAllMocks();
  await resetAll();
});

const type = async (placeholder: string, text: string, index = 0) =>
  fireEvent.changeText(screen.getAllByPlaceholderText(placeholder)[index], text);

/** Make an Alert press the button with this label straight away. */
function answerAlert(label: string) {
  return jest.spyOn(Alert, 'alert').mockImplementation((_title, _message, buttons) => {
    buttons?.find((b) => b.text === label)?.onPress?.();
  });
}

test('every contact channel opens its app when tapped', async () => {
  const open = jest.spyOn(Linking, 'openURL').mockResolvedValue(undefined);
  await giveConsent();
  await openApp();
  await fireEvent.press(await screen.findByText('Contact', {}, SLOW));
  await screen.findByText('Contact us', {}, SLOW);

  const expected: [string, string][] = [
    ['WhatsApp: +254 759 858 428', 'https://wa.me/254759858428'],
    ['Instagram: @tribridge_studios', 'https://www.instagram.com/tribridge_studios'],
    ['Phone: +254 759 858 428', 'tel:+254759858428'],
    ['Email: servicestribridge@gmail.com', 'mailto:servicestribridge@gmail.com'],
    ['Website: ashrafabdalla.onrender.com', 'https://ashrafabdalla.onrender.com'],
  ];
  for (const [label, url] of expected) {
    await fireEvent.press(screen.getByLabelText(label));
    await waitFor(() => expect(open).toHaveBeenLastCalledWith(url), SLOW);
  }
});

test('the admin inbox needs the passcode, and the team can triage messages', async () => {
  seedWorld();
  backend.feedback.push({
    id: 'fb-seed',
    user_id: 'customer-2',
    type: 'bug',
    priority: 'high',
    message: 'The cart total looks wrong on my phone',
    status: 'new',
    role: 'customer',
    store_name: '',
    created_at: new Date().toISOString(),
  });
  await giveConsent();
  await openApp();
  await fireEvent.press(await screen.findByText('Admin', {}, SLOW));

  await type('Passcode', 'wrong-code');
  await fireEvent.press(screen.getByLabelText('Unlock'));
  await screen.findByText('Wrong passcode.', {}, SLOW);

  await type('Passcode', 'axon2026');
  await fireEvent.press(screen.getByLabelText('Unlock'));
  await screen.findByText('The cart total looks wrong on my phone', {}, SLOW);
  expect(screen.getByText('Owners')).toBeTruthy();

  await fireEvent.press(screen.getByText('Reviewing'));
  await waitFor(() => expect(backend.feedback[0].status).toBe('reviewing'), SLOW);
});

test('a customer can send a suggestion and sees it in their history', async () => {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.customer.id);
  await openApp();

  await fireEvent.press(await screen.findByText('Me', {}, SLOW));
  await fireEvent.press(await screen.findByText('Suggestions and feedback', {}, SLOW));
  await type('Describe the change you want, or the problem you found.', 'Please add a way to pay with a card');
  await fireEvent.press(screen.getByLabelText('Send to the AXON team'));

  await waitFor(() => expect(backend.feedback).toHaveLength(1), SLOW);
  expect(backend.feedback[0]).toMatchObject({ user_id: w.customer.id, message: 'Please add a way to pay with a card' });
  await screen.findByText('Please add a way to pay with a card', {}, SLOW);
});

test('an owner adds an item and customers can then see it', async () => {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.owner.id);
  await openApp();
  await screen.findByText('Profit, all time', {}, SLOW);

  await fireEvent.press(screen.getByLabelText('Add item'));
  await type('e.g. Friesian cow A, or Fresh milk', 'Goat meal');
  await fireEvent.changeText(screen.getByLabelText(/^Selling price per/), '20');
  await fireEvent.changeText(screen.getByLabelText(/^How many .* do you have now$/), '150');
  const add = screen.getAllByLabelText('Add item');
  await fireEvent.press(add[add.length - 1]);

  await waitFor(() => expect(backend.products.some((p) => p.name === 'Goat meal')).toBe(true), SLOW);
  expect(backend.products.find((p) => p.name === 'Goat meal')).toMatchObject({ price: 20, stock: 150, active: true });
});

test('a customer saves a favourite, changes the cart and removes the item', async () => {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.customer.id);
  await openApp();

  await fireEvent.press(await screen.findByText('Mama Njeri Farm', {}, SLOW));
  await screen.findByText('Fresh milk', {}, SLOW);

  // favourite
  await fireEvent.press(screen.getAllByLabelText('Add to wishlist')[0]);
  await waitFor(() => expect(backend.wishlist).toHaveLength(1), SLOW);

  // cart: one litre, then two, then the line is removed
  await fireEvent.press(screen.getByLabelText('Add Fresh milk to cart'));
  await fireEvent.press(await screen.findByText(/View cart \(1\)/, {}, SLOW));
  await screen.findByText('Your cart', {}, SLOW);
  await fireEvent.press(screen.getByLabelText('Increase quantity'));
  await waitFor(() => expect(screen.getAllByText('KSh 260').length).toBeGreaterThan(0), SLOW);
  expect(screen.getByText('None')).toBeTruthy(); // AXON fees
  await fireEvent.press(screen.getByLabelText('Remove Fresh milk'));
  await screen.findByText('Your cart is empty', {}, SLOW);
});

test('signing out returns to the start screen', async () => {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.customer.id);
  await openApp();
  const alert = answerAlert('Sign out');

  await fireEvent.press(await screen.findByText('Me', {}, SLOW));
  await fireEvent.press(await screen.findByText('Sign out', {}, SLOW));
  await screen.findByText('How will you use AXON?', {}, SLOW);
  expect(alert).toHaveBeenCalled();
  expect(backend.session).toBeNull();
});
