jest.mock('../src/config', () => ({ ...jest.requireActual('../src/config'), IS_CONFIGURED: true }));

import { fireEvent } from '@testing-library/react-native';
import { autoLogout } from '../src/lib/autoLogout';
import { useCart } from '../src/state/cart';
import { backend, seedWorld } from './fakeBackend';
import { giveConsent, loginAs, openApp, resetAll, screen, SLOW, waitFor } from './harness';
import { customerApi } from './mockApi';

beforeEach(resetAll);

test('a customer finds the store, fills a cart and places an order', async () => {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.customer.id);
  await openApp();

  // shop -> store
  await fireEvent.press(await screen.findByText('Mama Njeri Farm', {}, SLOW));
  await screen.findByText('Fresh milk', {}, SLOW);
  expect(screen.getByText('Eggs tray')).toBeTruthy();
  // hidden items are never shown to customers
  expect(screen.queryByText('Hidden item')).toBeNull();

  // add to cart, open the cart
  await fireEvent.press(screen.getByLabelText('Add Fresh milk to cart'));
  await fireEvent.press(await screen.findByText(/View cart \(1\)/, {}, SLOW));
  await fireEvent.press(await screen.findByText('Checkout', {}, SLOW));

  // checkout: totals, no fees, payment details from the store
  await screen.findByText('No extra fees', {}, SLOW);
  expect(screen.getByText('M-Pesa Till 123456')).toBeTruthy();
  await fireEvent.press(screen.getByText('Place order'));

  await screen.findByText('Submitted', {}, SLOW);
  expect(backend.orders).toHaveLength(1);
  expect(backend.orders[0]).toMatchObject({
    total: 130,
    status: 'placed',
    customer_name: 'Brian Buyer',
    pay_method: 'mpesa',
    payment_status: 'awaiting',
  });
  // the customer is told the payment waits for the store, and which way they chose to pay
  expect(screen.getByText(/M-Pesa, awaiting approval/)).toBeTruthy();
  // stock is held for the customer straight away
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(39);
});

async function placeOrderThroughTheScreens(seconds: number) {
  autoLogout.seconds = seconds;
  const w = seedWorld();
  await giveConsent();
  loginAs(w.customer.id);
  await openApp();
  await fireEvent.press(await screen.findByText('Mama Njeri Farm', {}, SLOW));
  await fireEvent.press(await screen.findByLabelText('Add Fresh milk to cart', {}, SLOW));
  await fireEvent.press(await screen.findByText(/View cart \(1\)/, {}, SLOW));
  await fireEvent.press(await screen.findByText('Checkout', {}, SLOW));
  await screen.findByText('No extra fees', {}, SLOW);
  await fireEvent.press(screen.getByText('Place order'));
  await screen.findByText('Submitted', {}, SLOW);
  return w;
}

afterEach(() => {
  autoLogout.seconds = 12;
});

test('after submitting, the customer is logged out on this phone only, and the account and order stay', async () => {
  const w = await placeOrderThroughTheScreens(2);
  expect(backend.session).not.toBeNull();
  expect(screen.getByText(/you will be logged out in/)).toBeTruthy();

  // the countdown ends and the phone goes back to the start screen
  await screen.findByText('How will you use AXON?', {}, SLOW);
  expect(backend.session).toBeNull();
  expect(backend.lastSignOutScope).toBe('local');
  // nothing is deleted: the account, the order and its held stock are all still there
  expect(backend.accounts.some((a) => a.id === w.customer.id)).toBe(true);
  expect(backend.orders).toHaveLength(1);
  expect(backend.orders[0].customer_id).toBe(w.customer.id);
  // the next person finds an empty cart
  expect(useCart.getState().items).toHaveLength(0);
});

test('the customer can log out straight away instead of waiting', async () => {
  await placeOrderThroughTheScreens(60);
  await fireEvent.press(screen.getByLabelText('Log out now'));
  await screen.findByText('How will you use AXON?', {}, SLOW);
  expect(backend.session).toBeNull();
});

test('an order reaches the owner, and completing it turns into revenue and profit', async () => {
  const w = seedWorld();

  // the customer orders 3 litres through the backend
  backend.session = { user: { id: w.customer.id, email: w.customer.email } };
  const order = await customerApi.placeOrder({
    storeId: w.store.id,
    items: [{ productId: w.milk.id, qty: 3 }],
    payMethod: 'mpesa',
    name: 'Brian Buyer',
    phone: '0712345678',
    notes: 'Pick up at 5pm',
  });
  expect(order.total).toBe(390);
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(37);
  expect(backend.sales).toHaveLength(0);

  // the owner opens the app and sees it
  await giveConsent();
  loginAs(w.owner.id);
  await openApp();
  await fireEvent.press(await screen.findByText('1 new customer order', {}, SLOW));
  await screen.findByText('Brian Buyer', {}, SLOW);
  expect(screen.getByText('Note: Pick up at 5pm')).toBeTruthy();

  // the store is told which way the customer will pay, and that it waits for approval
  expect(screen.getByText(/Payment awaiting your approval: M-Pesa/)).toBeTruthy();
  expect(screen.queryByLabelText('Complete')).toBeNull();
  await fireEvent.press(screen.getByLabelText('Approve payment'));
  await waitFor(() => expect(backend.orders[0].status).toBe('processing'), SLOW);
  expect(backend.orders[0].payment_status).toBe('approved');
  await screen.findByText('Payment approved', {}, SLOW);
  await fireEvent.press(await screen.findByLabelText('Complete', {}, SLOW));
  await waitFor(() => expect(backend.orders[0].status).toBe('complete'), SLOW);

  // revenue now exists, linked to the order
  expect(backend.sales).toHaveLength(1);
  expect(backend.sales[0]).toMatchObject({ total: 390, qty: 3, order_id: order.id });

  await fireEvent.press(screen.getByText('Home'));
  await waitFor(() => expect(screen.getAllByText('KSh 390').length).toBeGreaterThan(0), SLOW);
});

test('cancelling an order puts the stock back', async () => {
  const w = seedWorld();
  backend.session = { user: { id: w.customer.id, email: w.customer.email } };
  const order = await customerApi.placeOrder({
    storeId: w.store.id,
    items: [{ productId: w.milk.id, qty: 5 }],
    payMethod: 'cash',
    name: 'Brian Buyer',
    phone: '0712345678',
    notes: '',
  });
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(35);
  await customerApi.cancelMyOrder(order.id);
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(40);
  expect(backend.orders[0].status).toBe('cancelled');
});
