jest.mock('../src/config', () => ({ ...jest.requireActual('../src/config'), IS_CONFIGURED: true }));

import AsyncStorage from '@react-native-async-storage/async-storage';
import { fireEvent, render } from '@testing-library/react-native';
import React from 'react';
import { Alert } from 'react-native';
import App from '../App';
import { useNet } from '../src/state/net';
import { useOutbox } from '../src/state/outbox';
import { useSession } from '../src/state/session';
import { backend, seedWorld } from './fakeBackend';
import { act, giveConsent, loginAs, openApp, pause, resetAll, screen, SLOW, waitFor } from './harness';
import { goOffline, goOnline } from './mockNet';

beforeEach(resetAll);

async function openAsOwner() {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.owner.id);
  await openApp();
  await screen.findByText('Profit, all time', {}, SLOW);
  return w;
}

const TABS = { Home: 1, Stock: 2, Sales: 3, Costs: 4, Profit: 5 } as const;
const tab = (name: keyof typeof TABS) => fireEvent.press(screen.getByLabelText(`${name}, tab, ${TABS[name]} of 5`));

function answerAlert(label: string) {
  return jest.spyOn(Alert, 'alert').mockImplementation((_title, _message, buttons) => {
    buttons?.find((b) => b.text === label)?.onPress?.();
  });
}

async function sellMilkFromStock(extra = 0) {
  await tab('Stock');
  await fireEvent.press(await screen.findByLabelText('Sell Fresh milk', {}, SLOW));
  await screen.findByText('Record a sale', {}, SLOW);
  for (let i = 0; i < extra; i++) await fireEvent.press(screen.getByLabelText('Increase quantity'));
  await fireEvent.press(screen.getByText('Save sale'));
}

test('a sale made without signal is saved on the phone and sent once when the connection returns', async () => {
  const w = await openAsOwner();
  await act(async () => goOffline());
  await screen.findByLabelText('Offline', {}, SLOW);
  await sellMilkFromStock(1);

  // nothing reached the cloud, but the owner sees the work at once
  await screen.findByLabelText('Offline. 1 waiting to send', {}, SLOW);
  expect(backend.sales).toHaveLength(0);
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(40);
  expect(useOutbox.getState().items).toHaveLength(1);
  // the saved item survives the app being closed: it is on the phone's storage
  expect(await AsyncStorage.getItem('axon-outbox-v1')).toContain('Fresh milk');
  // the shelf already shows two fewer litres
  await screen.findByText(/38 litre/, {}, SLOW);

  // the revenue shows up on Home straight away too
  await tab('Home');
  await waitFor(() => expect(screen.getAllByText('KSh 260').length).toBeGreaterThan(0), SLOW);

  // the connection returns: it is sent, once, with the real numbers
  await act(async () => goOnline());
  await waitFor(() => expect(backend.sales).toHaveLength(1), SLOW);
  expect(backend.sales[0]).toMatchObject({ qty: 2, total: 260, product_name: 'Fresh milk' });
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(38);
  await waitFor(() => expect(useOutbox.getState().items).toHaveLength(0), SLOW);
  await waitFor(() => expect(screen.queryByLabelText(/waiting to send/)).toBeNull(), SLOW);
  expect(await AsyncStorage.getItem('axon-outbox-v1')).toBe('[]');
});

test('an expense saved without signal waits, shows in the list and the totals, and is sent later', async () => {
  await openAsOwner();
  await tab('Costs');
  await screen.findByText('Add expense', {}, SLOW);

  await act(async () => goOffline());
  await fireEvent.press(screen.getByText('Add expense'));
  await fireEvent.changeText(await screen.findByPlaceholderText('e.g. Shop rent for May'), 'Shop rent for May');
  await fireEvent.changeText(screen.getByPlaceholderText('Quantity'), '1');
  await fireEvent.changeText(screen.getByPlaceholderText('Price each'), '5000');
  await waitFor(() => expect(screen.getAllByDisplayValue('5000')).toHaveLength(2), SLOW);
  await fireEvent.press(screen.getByText('Save expense'));

  await screen.findByText(/Saved on this phone/, {}, SLOW);
  expect(backend.expenses).toHaveLength(0);
  await screen.findByText(/Waiting to send/, {}, SLOW);
  // total spent already includes it
  await waitFor(() => expect(screen.getAllByText('KSh 5,000').length).toBeGreaterThan(0), SLOW);

  await act(async () => goOnline());
  await waitFor(() => expect(backend.expenses).toHaveLength(1), SLOW);
  expect(backend.expenses[0]).toMatchObject({ category: 'Rent', amount: 5000, description: 'Shop rent for May' });
  await waitFor(() => expect(useOutbox.getState().items).toHaveLength(0), SLOW);
});

test('when a reply is lost on a weak signal, the same sale is not counted twice', async () => {
  const w = await openAsOwner();
  // the phone thinks it is connected, but the cloud's answer never arrives
  backend.loseNextReply = true;
  await sellMilkFromStock(0);

  // the cloud did record it, and the phone kept a copy because it never heard back
  await waitFor(() => expect(useOutbox.getState().items).toHaveLength(1), SLOW);
  expect(backend.sales).toHaveLength(1);

  // the next attempt sends the same item again; the cloud recognises it
  await act(async () => {
    await useOutbox.getState().flush();
  });
  await waitFor(() => expect(useOutbox.getState().items).toHaveLength(0), SLOW);
  expect(backend.sales).toHaveLength(1);
  expect(backend.products.find((p) => p.id === w.milk.id)!.stock).toBe(39);
  expect(useNet.getState().online).toBe(true);
});

test('a saved sale the cloud refuses is kept for the owner, who can remove it', async () => {
  const w = await openAsOwner();
  await tab('Stock');
  await screen.findByLabelText('Sell Eggs tray', {}, SLOW);

  await act(async () => goOffline());
  await fireEvent.press(screen.getByLabelText('Sell Eggs tray'));
  await screen.findByText('Record a sale', {}, SLOW);
  for (let i = 0; i < 3; i++) await fireEvent.press(screen.getByLabelText('Increase quantity'));
  await fireEvent.press(screen.getByText('Save sale'));
  await screen.findByLabelText('Offline. 1 waiting to send', {}, SLOW);

  // meanwhile the cloud stock is used up some other way (an online order)
  backend.products.find((p) => p.id === w.eggs.id)!.stock = 2;
  await act(async () => goOnline());

  await screen.findByLabelText('1 not saved', {}, SLOW);
  expect(backend.sales).toHaveLength(0);
  expect(useOutbox.getState().items[0]).toMatchObject({ status: 'failed' });

  // the list says why, and the owner decides
  await fireEvent.press(screen.getByLabelText('1 not saved'));
  await screen.findByText('Waiting to send', {}, SLOW);
  await screen.findByText(/Only 2 tray in stock/, {}, SLOW);
  answerAlert('Remove');
  await fireEvent.press(screen.getByLabelText('Remove'));
  await waitFor(() => expect(useOutbox.getState().items).toHaveLength(0), SLOW);
});

test('the app opens without signal from the saved copy, then catches up when the connection returns', async () => {
  const w = seedWorld();
  await giveConsent();
  loginAs(w.owner.id);
  const first = await render(<App />);
  await screen.findByText('Profit, all time', {}, SLOW);
  // the first visit also keeps a complete copy of the shop for later
  await waitFor(async () => expect((await AsyncStorage.getAllKeys()).filter((k) => k.startsWith('axon.cache.v1.')).length).toBeGreaterThan(8), SLOW);
  expect(await AsyncStorage.getItem('axon.account.v1')).toContain('Mama Njeri Farm');
  await first.unmount();

  // a new launch: the phone has no signal and the saved login has run out
  useSession.setState(useSession.getInitialState(), true);
  useNet.setState(useNet.getInitialState(), true);
  backend.tokenExpired = true;
  await act(async () => goOffline());
  await render(<App />);

  await screen.findByText('Profit, all time', {}, SLOW);
  expect(screen.getAllByText('Mama Njeri Farm').length).toBeGreaterThan(0);
  expect(useSession.getState().fromCache).toBe(true);
  await screen.findByLabelText('Offline', {}, SLOW);

  // a sale can be made from here
  await sellMilkFromStock(0);
  await screen.findByLabelText('Offline. 1 waiting to send', {}, SLOW);

  await act(async () => goOnline());
  await waitFor(() => expect(backend.sales).toHaveLength(1), SLOW);
  await waitFor(() => expect(useSession.getState().fromCache).toBe(false), SLOW);
});

test('signing out clears the saved copy of the account and its numbers', async () => {
  await openAsOwner();
  await pause(50);
  expect(await AsyncStorage.getItem('axon.account.v1')).not.toBeNull();
  const keys = await AsyncStorage.getAllKeys();
  expect(keys.some((k) => k.startsWith('axon.cache.v1.'))).toBe(true);

  await act(async () => {
    await useSession.getState().signOut();
  });
  await pause(50);
  expect(await AsyncStorage.getItem('axon.account.v1')).toBeNull();
  expect((await AsyncStorage.getAllKeys()).some((k) => k.startsWith('axon.cache.v1.'))).toBe(false);
});
