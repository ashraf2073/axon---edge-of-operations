-- =====================================================================
-- AXON backend for Supabase (Postgres 15 or newer)
--
-- HOW TO RUN: Supabase dashboard > SQL Editor > New query > paste this
-- whole file > Run. It is repeatable, so you can run it again after
-- updates without losing data.
--
-- Nothing needs editing: paste the whole file and run it. The admin passcode
-- is set in the admin section near the end. Anyone who can read this file
-- can read the passcode, so keep your GitHub repository private, or change
-- the passcode inside the app after the first run (Admin > Change passcode).
--
-- Every object is prefixed axon_ so it never clashes with other apps
-- that share the same Supabase project.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------------
-- Small helpers
-- ---------------------------------------------------------------------

create or replace function public.axon_touch() returns trigger
language plpgsql set search_path = public, pg_temp as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Random readable code such as TXN-7K2M9QXA (no look-alike characters).
create or replace function public.axon_code(p_prefix text, p_len int default 8) returns text
language plpgsql volatile set search_path = public, pg_temp as $$
declare
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  v text := '';
  i int;
begin
  for i in 1..p_len loop
    v := v || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
  end loop;
  return case when p_prefix = '' then v else p_prefix || '-' || v end;
end $$;

-- ---------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------

create table if not exists public.axon_profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  role text not null check (role in ('owner', 'customer')),
  full_name text not null default '',
  phone text not null default '',
  email text not null default '',
  date_format text not null default 'DD/MM/YYYY'
    check (date_format in ('DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD')),
  consent_at timestamptz,
  consent_contact boolean not null default false,
  created_at timestamptz not null default now()
);
create unique index if not exists axon_profiles_email_key on public.axon_profiles (email);

create or replace function public.axon_store_code() returns text
language plpgsql volatile set search_path = public, pg_temp as $$
declare v text;
begin
  loop
    v := public.axon_code('', 6);
    exit when not exists (select 1 from public.axon_stores where code = v);
  end loop;
  return v;
end $$;

create table if not exists public.axon_stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.axon_profiles (id) on delete cascade,
  code text not null unique default public.axon_store_code(),
  name text not null check (char_length(trim(name)) between 2 and 80),
  kind text not null default 'shop'
    check (kind in ('shop', 'farm', 'company', 'supermarket', 'service', 'other')),
  description text not null default '',
  location text not null default '',
  phone text not null default '',
  currency text not null default 'KES'
    check (currency in ('KES', 'USD', 'EUR', 'GBP', 'TZS', 'UGX', 'NGN')),
  payment_info text not null default '',
  logo_url text,
  created_at timestamptz not null default now()
);
create index if not exists axon_stores_owner_idx on public.axon_stores (owner_id);

create table if not exists public.axon_products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.axon_stores (id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 120),
  category text not null default 'General',
  kind text not null default 'good' check (kind in ('good', 'farm', 'animal', 'service')),
  description text not null default '',
  unit text not null default 'piece',
  price numeric(14, 2) not null check (price >= 0),
  cost numeric(14, 2) not null default 0 check (cost >= 0),
  stock numeric(14, 3) not null default 0 check (stock >= 0),
  track_stock boolean not null default true,
  low_alert numeric(14, 3) not null default 0 check (low_alert >= 0),
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists axon_products_store_idx on public.axon_products (store_id);

create table if not exists public.axon_orders (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  store_id uuid not null references public.axon_stores (id) on delete cascade,
  customer_id uuid references public.axon_profiles (id) on delete set null,
  customer_name text not null,
  customer_phone text not null default '',
  pay_method text not null check (pay_method in ('mpesa', 'cash', 'bank', 'card', 'airtel')),
  notes text not null default '',
  total numeric(14, 2) not null default 0,
  currency text not null default 'KES',
  status text not null default 'placed'
    check (status in ('placed', 'processing', 'complete', 'cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists axon_orders_store_idx on public.axon_orders (store_id, created_at desc);
create index if not exists axon_orders_customer_idx on public.axon_orders (customer_id, created_at desc);

-- The store approves the payment by hand. AXON never touches the money.
alter table public.axon_orders add column if not exists payment_status text not null default 'awaiting';
alter table public.axon_orders drop constraint if exists axon_orders_payment_status_check;
alter table public.axon_orders add constraint axon_orders_payment_status_check
  check (payment_status in ('awaiting', 'approved'));
alter table public.axon_orders add column if not exists payment_approved_at timestamptz;
update public.axon_orders set payment_status = 'approved', payment_approved_at = coalesce(updated_at, created_at)
 where status = 'complete' and payment_status = 'awaiting';

create table if not exists public.axon_order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.axon_orders (id) on delete cascade,
  product_id uuid references public.axon_products (id) on delete set null,
  name text not null,
  unit text not null default 'piece',
  image_url text,
  price numeric(14, 2) not null,
  qty numeric(14, 3) not null check (qty > 0)
);
create index if not exists axon_order_items_order_idx on public.axon_order_items (order_id);

create table if not exists public.axon_sales (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.axon_stores (id) on delete cascade,
  product_id uuid references public.axon_products (id) on delete set null,
  order_id uuid references public.axon_orders (id) on delete set null,
  product_name text not null,
  unit text not null default 'piece',
  txn_id text not null,
  qty numeric(14, 3) not null check (qty > 0),
  unit_price numeric(14, 2) not null check (unit_price >= 0),
  total numeric(14, 2) generated always as (round(qty * unit_price, 2)) stored,
  customer text not null default '',
  note text not null default '',
  sold_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists axon_sales_store_idx on public.axon_sales (store_id, sold_at desc);
create index if not exists axon_sales_order_idx on public.axon_sales (order_id);

create table if not exists public.axon_expenses (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.axon_stores (id) on delete cascade,
  category text not null check (category in (
    'Rent', 'Wages', 'Stock', 'Utilities', 'Transport', 'Maintenance',
    'Insurance', 'Taxes', 'Marketing', 'Equipment', 'Other')),
  description text not null default '',
  payee text not null default '',
  amount numeric(14, 2) not null check (amount > 0),
  spent_on date not null default current_date,
  created_at timestamptz not null default now()
);
create index if not exists axon_expenses_store_idx on public.axon_expenses (store_id, spent_on desc);

-- A phone that was offline makes up an id for each sale and expense it saves.
-- If the same one arrives twice (a bad signal can hide a reply), it counts once.
alter table public.axon_sales add column if not exists client_id uuid;
create unique index if not exists axon_sales_client_idx
  on public.axon_sales (store_id, client_id) where client_id is not null;
alter table public.axon_expenses add column if not exists client_id uuid;
create unique index if not exists axon_expenses_client_idx
  on public.axon_expenses (store_id, client_id) where client_id is not null;

create table if not exists public.axon_wishlists (
  user_id uuid not null references public.axon_profiles (id) on delete cascade,
  product_id uuid not null references public.axon_products (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table if not exists public.axon_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.axon_profiles (id) on delete set null,
  role text not null default '',
  store_name text not null default '',
  type text not null check (type in ('feature', 'bug', 'improvement', 'praise', 'other')),
  priority text not null default 'low' check (priority in ('low', 'medium', 'high')),
  message text not null check (char_length(message) between 5 and 2000),
  contact_name text not null default '',
  contact_email text not null default '',
  status text not null default 'new'
    check (status in ('new', 'reviewing', 'planned', 'done', 'dismissed')),
  created_at timestamptz not null default now()
);
create index if not exists axon_feedback_user_idx on public.axon_feedback (user_id, created_at desc);

-- Admin passcode (hashed) and a log of failed attempts used for lock-outs.
create table if not exists public.axon_admin (
  id boolean primary key default true check (id),
  code_hash text not null
);
create table if not exists public.axon_attempts (
  id bigint generated always as identity primary key,
  kind text not null,
  key text not null,
  ok boolean not null default false,
  at timestamptz not null default now()
);
create index if not exists axon_attempts_lookup on public.axon_attempts (kind, key, at);

-- ---------------------------------------------------------------------
-- Triggers
-- ---------------------------------------------------------------------

drop trigger if exists axon_products_touch on public.axon_products;
create trigger axon_products_touch before update on public.axon_products
  for each row execute function public.axon_touch();

drop trigger if exists axon_orders_touch on public.axon_orders;
create trigger axon_orders_touch before update on public.axon_orders
  for each row execute function public.axon_touch();

create or replace function public.axon_limit_stores() returns trigger
language plpgsql set search_path = public, pg_temp as $$
begin
  if (select count(*) from public.axon_stores where owner_id = new.owner_id) >= 10 then
    raise exception 'You can have up to 10 businesses';
  end if;
  return new;
end $$;
drop trigger if exists axon_stores_limit on public.axon_stores;
create trigger axon_stores_limit before insert on public.axon_stores
  for each row execute function public.axon_limit_stores();

-- Create the profile row whenever someone signs up (owner or customer).
create or replace function public.axon_new_user() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  insert into public.axon_profiles (id, role, full_name, phone, email)
  values (
    new.id,
    case when new.raw_user_meta_data ->> 'axon_role' = 'owner' then 'owner' else 'customer' end,
    left(coalesce(new.raw_user_meta_data ->> 'full_name', ''), 80),
    left(coalesce(new.raw_user_meta_data ->> 'phone', ''), 30),
    lower(coalesce(new.email, ''))
  )
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists axon_on_auth_user_created on auth.users;
create trigger axon_on_auth_user_created after insert on auth.users
  for each row execute function public.axon_new_user();

-- ---------------------------------------------------------------------
-- Ownership helper (used by the security policies)
-- ---------------------------------------------------------------------

create or replace function public.axon_is_owner(p_store uuid) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (
    select 1 from public.axon_stores s
    where s.id = p_store and s.owner_id = auth.uid()
  )
$$;

-- ---------------------------------------------------------------------
-- Row Level Security: who can see and change what
-- ---------------------------------------------------------------------

alter table public.axon_profiles enable row level security;
alter table public.axon_stores enable row level security;
alter table public.axon_products enable row level security;
alter table public.axon_orders enable row level security;
alter table public.axon_order_items enable row level security;
alter table public.axon_sales enable row level security;
alter table public.axon_expenses enable row level security;
alter table public.axon_wishlists enable row level security;
alter table public.axon_feedback enable row level security;
alter table public.axon_admin enable row level security;
alter table public.axon_attempts enable row level security;

-- Signed-out visitors never touch tables directly.
revoke all on public.axon_profiles, public.axon_stores, public.axon_products,
  public.axon_orders, public.axon_order_items, public.axon_sales,
  public.axon_expenses, public.axon_wishlists, public.axon_feedback,
  public.axon_admin, public.axon_attempts from anon;
-- Secret tables are not reachable by signed-in users either.
revoke all on public.axon_admin, public.axon_attempts from authenticated;

-- Profiles: read own, change only harmless fields (never role or email).
drop policy if exists axon_profiles_select on public.axon_profiles;
create policy axon_profiles_select on public.axon_profiles
  for select to authenticated using (id = (select auth.uid()));
drop policy if exists axon_profiles_update on public.axon_profiles;
create policy axon_profiles_update on public.axon_profiles
  for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));
revoke insert, update, delete on public.axon_profiles from authenticated;
grant select on public.axon_profiles to authenticated;
grant update (full_name, phone, date_format, consent_at, consent_contact)
  on public.axon_profiles to authenticated;

-- Stores: every signed-in user can browse; only the owner changes.
drop policy if exists axon_stores_select on public.axon_stores;
create policy axon_stores_select on public.axon_stores
  for select to authenticated using (true);
drop policy if exists axon_stores_insert on public.axon_stores;
create policy axon_stores_insert on public.axon_stores
  for insert to authenticated
  with check (
    owner_id = (select auth.uid())
    and exists (select 1 from public.axon_profiles p
                where p.id = (select auth.uid()) and p.role = 'owner')
  );
drop policy if exists axon_stores_update on public.axon_stores;
create policy axon_stores_update on public.axon_stores
  for update to authenticated
  using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));
drop policy if exists axon_stores_delete on public.axon_stores;
create policy axon_stores_delete on public.axon_stores
  for delete to authenticated using (owner_id = (select auth.uid()));

-- Products: customers see active items; the owner sees and edits everything.
drop policy if exists axon_products_select on public.axon_products;
create policy axon_products_select on public.axon_products
  for select to authenticated using (active or public.axon_is_owner(store_id));
drop policy if exists axon_products_write on public.axon_products;
create policy axon_products_write on public.axon_products
  for all to authenticated
  using (public.axon_is_owner(store_id)) with check (public.axon_is_owner(store_id));

-- Expenses: the owner only.
drop policy if exists axon_expenses_all on public.axon_expenses;
create policy axon_expenses_all on public.axon_expenses
  for all to authenticated
  using (public.axon_is_owner(store_id)) with check (public.axon_is_owner(store_id));

-- Sales, orders and order lines are written only by the functions below,
-- so stock and totals can never be faked from the client.
drop policy if exists axon_sales_select on public.axon_sales;
create policy axon_sales_select on public.axon_sales
  for select to authenticated using (public.axon_is_owner(store_id));
drop policy if exists axon_orders_select on public.axon_orders;
create policy axon_orders_select on public.axon_orders
  for select to authenticated
  using (customer_id = (select auth.uid()) or public.axon_is_owner(store_id));
drop policy if exists axon_order_items_select on public.axon_order_items;
create policy axon_order_items_select on public.axon_order_items
  for select to authenticated
  using (exists (
    select 1 from public.axon_orders o
    where o.id = order_id
      and (o.customer_id = (select auth.uid()) or public.axon_is_owner(o.store_id))
  ));
revoke insert, update, delete on public.axon_sales, public.axon_orders,
  public.axon_order_items from authenticated;

-- Wishlist: private to each customer.
drop policy if exists axon_wishlists_all on public.axon_wishlists;
create policy axon_wishlists_all on public.axon_wishlists
  for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Feedback: people read their own; submitting goes through a function.
drop policy if exists axon_feedback_select on public.axon_feedback;
create policy axon_feedback_select on public.axon_feedback
  for select to authenticated using (user_id = (select auth.uid()));
revoke insert, update, delete on public.axon_feedback from authenticated;

-- ---------------------------------------------------------------------
-- Functions the app calls (all check who the caller is)
-- ---------------------------------------------------------------------

-- Record a sale by hand and reduce stock. p_client makes it safe to send twice.
drop function if exists public.axon_record_sale(uuid, uuid, numeric, numeric, text, text, timestamptz);
create or replace function public.axon_record_sale(
  p_store uuid, p_product uuid, p_qty numeric,
  p_price numeric default null, p_customer text default '',
  p_note text default '', p_sold_at timestamptz default null,
  p_client uuid default null
) returns public.axon_sales
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_prod public.axon_products;
  v_price numeric;
  v_sale public.axon_sales;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if not public.axon_is_owner(p_store) then raise exception 'You do not own this business'; end if;

  if p_client is not null then
    select * into v_sale from public.axon_sales where store_id = p_store and client_id = p_client;
    if found then return v_sale; end if;
  end if;

  if p_qty is null or p_qty <= 0 then raise exception 'Quantity must be more than zero'; end if;

  select * into v_prod from public.axon_products
   where id = p_product and store_id = p_store for update;
  if not found then raise exception 'Item not found'; end if;

  -- a second copy of the same sale may have finished while this one waited for the item
  if p_client is not null then
    select * into v_sale from public.axon_sales where store_id = p_store and client_id = p_client;
    if found then return v_sale; end if;
  end if;

  v_price := coalesce(p_price, v_prod.price);
  if v_price < 0 then raise exception 'Price cannot be negative'; end if;

  if v_prod.track_stock then
    if v_prod.stock < p_qty then
      raise exception 'Only % % in stock', trim_scale(v_prod.stock)::text, v_prod.unit;
    end if;
    update public.axon_products set stock = stock - p_qty where id = v_prod.id;
  end if;

  insert into public.axon_sales
    (store_id, product_id, product_name, unit, txn_id, qty, unit_price, customer, note, sold_at, client_id)
  values
    (p_store, v_prod.id, v_prod.name, v_prod.unit, public.axon_code('TXN'), p_qty, v_price,
     left(trim(coalesce(p_customer, '')), 80), left(trim(coalesce(p_note, '')), 300),
     coalesce(p_sold_at, now()), p_client)
  returning * into v_sale;
  return v_sale;
end $$;

-- Add an expense. p_client makes it safe to send twice.
create or replace function public.axon_add_expense(
  p_store uuid, p_client uuid, p_category text, p_description text default '',
  p_payee text default '', p_amount numeric default null, p_spent_on date default null
) returns public.axon_expenses
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_row public.axon_expenses;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if not public.axon_is_owner(p_store) then raise exception 'You do not own this business'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Enter the amount you paid'; end if;

  insert into public.axon_expenses (store_id, category, description, payee, amount, spent_on, client_id)
  values (p_store, p_category, left(trim(coalesce(p_description, '')), 200),
          left(trim(coalesce(p_payee, '')), 120), p_amount, coalesce(p_spent_on, current_date), p_client)
  on conflict (store_id, client_id) where client_id is not null do nothing
  returning * into v_row;

  if not found then
    select * into v_row from public.axon_expenses where store_id = p_store and client_id = p_client;
  end if;
  return v_row;
end $$;

-- Delete a manual sale and put the stock back.
create or replace function public.axon_delete_sale(p_sale uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_sale public.axon_sales;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into v_sale from public.axon_sales where id = p_sale for update;
  if not found then raise exception 'Sale not found'; end if;
  if not public.axon_is_owner(v_sale.store_id) then raise exception 'You do not own this business'; end if;
  if v_sale.order_id is not null then
    raise exception 'This sale came from a customer order. Cancel the order instead.';
  end if;
  update public.axon_products set stock = stock + v_sale.qty
   where id = v_sale.product_id and track_stock;
  delete from public.axon_sales where id = v_sale.id;
end $$;

-- Customer checkout. Prices and totals come from the database, never the phone.
create or replace function public.axon_place_order(
  p_store uuid, p_items jsonb, p_pay_method text,
  p_name text, p_phone text, p_notes text default ''
) returns public.axon_orders
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_store public.axon_stores;
  v_order public.axon_orders;
  v_item jsonb;
  v_prod public.axon_products;
  v_qty numeric;
  v_total numeric := 0;
  v_name text := trim(coalesce(p_name, ''));
  v_phone text := trim(coalesce(p_phone, ''));
begin
  if auth.uid() is null then raise exception 'Sign in to place an order'; end if;
  if not exists (select 1 from public.axon_profiles where id = auth.uid() and role = 'customer') then
    raise exception 'Only customer accounts can place orders';
  end if;
  select * into v_store from public.axon_stores where id = p_store;
  if not found then raise exception 'Store not found'; end if;
  if p_pay_method is null or p_pay_method not in ('mpesa', 'cash', 'bank', 'card', 'airtel') then
    raise exception 'Choose a payment method';
  end if;
  if char_length(v_name) < 2 then raise exception 'Enter your name'; end if;
  if char_length(v_phone) < 7 then raise exception 'Enter a valid phone number'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Your cart is empty';
  end if;
  if jsonb_array_length(p_items) > 50 then raise exception 'Too many items in one order'; end if;

  insert into public.axon_orders
    (code, store_id, customer_id, customer_name, customer_phone, pay_method, notes, currency)
  values
    (public.axon_code('ORD'), p_store, auth.uid(), left(v_name, 80), left(v_phone, 30),
     p_pay_method, left(trim(coalesce(p_notes, '')), 500), v_store.currency)
  returning * into v_order;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item ->> 'qty')::numeric;
    if v_qty is null or v_qty <= 0 then raise exception 'Invalid quantity'; end if;

    select * into v_prod from public.axon_products
     where id = (v_item ->> 'product_id')::uuid and store_id = p_store and active
     for update;
    if not found then raise exception 'An item in your cart is no longer available'; end if;

    if v_prod.track_stock then
      if v_prod.stock < v_qty then
        raise exception '% has only % % left', v_prod.name, trim_scale(v_prod.stock)::text, v_prod.unit;
      end if;
      update public.axon_products set stock = stock - v_qty where id = v_prod.id;
    end if;

    insert into public.axon_order_items (order_id, product_id, name, unit, image_url, price, qty)
    values (v_order.id, v_prod.id, v_prod.name, v_prod.unit, v_prod.image_url, v_prod.price, v_qty);
    v_total := v_total + round(v_prod.price * v_qty, 2);
  end loop;

  update public.axon_orders set total = v_total where id = v_order.id returning * into v_order;
  return v_order;
end $$;

-- Move an order along. The store owner can do any valid step; the customer
-- can only cancel an order that has not been accepted yet.
-- Stock is held from the moment of ordering and returned on cancel.
-- Revenue (sales rows) is created only when the order is marked complete.
create or replace function public.axon_set_order_status(p_order uuid, p_status text)
returns public.axon_orders
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_order public.axon_orders;
  v_is_owner boolean;
  v_is_customer boolean;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if p_status is null or p_status not in ('processing', 'complete', 'cancelled') then
    raise exception 'Unknown status';
  end if;
  select * into v_order from public.axon_orders where id = p_order for update;
  if not found then raise exception 'Order not found'; end if;

  v_is_owner := public.axon_is_owner(v_order.store_id);
  v_is_customer := v_order.customer_id = auth.uid();
  if not (v_is_owner or v_is_customer) then raise exception 'Not allowed'; end if;
  if not v_is_owner and not (v_order.status = 'placed' and p_status = 'cancelled') then
    raise exception 'You can only cancel an order the store has not accepted yet';
  end if;

  if not (
    (v_order.status = 'placed' and p_status in ('processing', 'complete', 'cancelled')) or
    (v_order.status = 'processing' and p_status in ('complete', 'cancelled')) or
    (v_order.status = 'complete' and p_status = 'cancelled')
  ) then
    raise exception 'An order that is % cannot be set to %', v_order.status, p_status;
  end if;

  if p_status = 'complete' then
    insert into public.axon_sales
      (store_id, product_id, order_id, product_name, unit, txn_id, qty, unit_price, customer, note, sold_at)
    select v_order.store_id, oi.product_id, v_order.id, oi.name, oi.unit, v_order.code,
           oi.qty, oi.price, v_order.customer_name, 'Store order - ' || v_order.pay_method, now()
      from public.axon_order_items oi where oi.order_id = v_order.id;
  elsif p_status = 'cancelled' then
    if v_order.status = 'complete' then
      delete from public.axon_sales where order_id = v_order.id;
    end if;
    update public.axon_products p set stock = p.stock + x.qty
      from (select product_id, sum(qty) as qty from public.axon_order_items
             where order_id = v_order.id and product_id is not null group by product_id) x
     where p.id = x.product_id and p.track_stock;
  end if;

  update public.axon_orders
     set status = p_status,
         payment_approved_at = case when p_status = 'complete' and payment_status <> 'approved' then now() else payment_approved_at end,
         payment_status = case when p_status = 'complete' then 'approved' else payment_status end
   where id = v_order.id returning * into v_order;
  return v_order;
end $$;

-- The store confirms it has the payment (cash, M-Pesa, card, bank, mobile money). The order moves on.
create or replace function public.axon_approve_payment(p_order uuid)
returns public.axon_orders
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_order public.axon_orders;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into v_order from public.axon_orders where id = p_order for update;
  if not found then raise exception 'Order not found'; end if;
  if not public.axon_is_owner(v_order.store_id) then raise exception 'Not allowed'; end if;
  if v_order.status not in ('placed', 'processing') then
    raise exception 'An order that is % cannot have its payment approved', v_order.status;
  end if;
  if v_order.payment_status = 'approved' then return v_order; end if;
  update public.axon_orders
     set payment_status = 'approved', payment_approved_at = now(),
         status = case when status = 'placed' then 'processing' else status end
   where id = v_order.id returning * into v_order;
  return v_order;
end $$;

-- All dashboard and profit/loss numbers in one call, computed in the database
-- so they stay correct no matter how many sales a business has.
create or replace function public.axon_analytics(
  p_store uuid, p_from timestamptz default null,
  p_to timestamptz default null, p_tz text default 'UTC'
) returns jsonb
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare
  v_tz text := 'UTC';
  v_from timestamptz := coalesce(p_from, '-infinity'::timestamptz);
  v_to timestamptz := coalesce(p_to, 'infinity'::timestamptz);
  v_from_d date;
  v_to_d date;
  v_rev numeric; v_units numeric; v_cnt int; v_exp numeric;
  v_monthly jsonb; v_top jsonb; v_cats jsonb; v_low jsonb;
  v_new int; v_open int; v_pc int;
begin
  if not public.axon_is_owner(p_store) then raise exception 'You do not own this business'; end if;
  begin
    perform now() at time zone p_tz;
    v_tz := p_tz;
  exception when others then
    v_tz := 'UTC';
  end;
  v_from_d := case when p_from is null then '-infinity'::date else (p_from at time zone v_tz)::date end;
  v_to_d := case when p_to is null then 'infinity'::date else (p_to at time zone v_tz)::date end;

  select coalesce(sum(total), 0), coalesce(sum(qty), 0), count(*)
    into v_rev, v_units, v_cnt
    from public.axon_sales
   where store_id = p_store and sold_at >= v_from and sold_at < v_to;

  select coalesce(sum(amount), 0) into v_exp
    from public.axon_expenses
   where store_id = p_store and spent_on >= v_from_d and spent_on < v_to_d;

  select coalesce(jsonb_agg(jsonb_build_object(
           'month', to_char(m.m, 'YYYY-MM'),
           'revenue', coalesce(r.rev, 0),
           'expenses', coalesce(e.exp, 0)) order by m.m), '[]'::jsonb)
    into v_monthly
    from (select (date_trunc('month', now() at time zone v_tz) - make_interval(months => g))::date as m
            from generate_series(5, 0, -1) g) m
    left join (select date_trunc('month', sold_at at time zone v_tz)::date as m, sum(total) as rev
                 from public.axon_sales where store_id = p_store group by 1) r on r.m = m.m
    left join (select date_trunc('month', spent_on)::date as m, sum(amount) as exp
                 from public.axon_expenses where store_id = p_store group by 1) e on e.m = m.m;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.revenue desc), '[]'::jsonb) into v_top
    from (select max(product_name) as name, sum(qty) as units, sum(total) as revenue
            from public.axon_sales
           where store_id = p_store and sold_at >= v_from and sold_at < v_to
           group by coalesce(product_id::text, lower(product_name))
           order by sum(total) desc limit 5) t;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.amount desc), '[]'::jsonb) into v_cats
    from (select category, sum(amount) as amount
            from public.axon_expenses
           where store_id = p_store and spent_on >= v_from_d and spent_on < v_to_d
           group by category) t;

  select coalesce(jsonb_agg(to_jsonb(t) order by t.name), '[]'::jsonb) into v_low
    from (select id, name, stock, low_alert, unit
            from public.axon_products
           where store_id = p_store and track_stock and low_alert > 0 and stock <= low_alert
           order by name limit 20) t;

  select count(*) filter (where status = 'placed'),
         count(*) filter (where status in ('placed', 'processing'))
    into v_new, v_open
    from public.axon_orders where store_id = p_store;

  select count(*) into v_pc from public.axon_products where store_id = p_store;

  return jsonb_build_object(
    'revenue', v_rev, 'expenses', v_exp, 'units', v_units, 'sales_count', v_cnt,
    'monthly', v_monthly, 'top_products', v_top, 'expense_breakdown', v_cats,
    'low_stock', v_low, 'new_orders', v_new, 'open_orders', v_open, 'product_count', v_pc);
end $$;

-- Feedback and suggestions to the AXON team.
create or replace function public.axon_submit_feedback(
  p_type text, p_priority text, p_message text,
  p_include_contact boolean default false, p_store uuid default null
) returns public.axon_feedback
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_prof public.axon_profiles;
  v_store_name text := '';
  v_row public.axon_feedback;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into v_prof from public.axon_profiles where id = auth.uid();
  if not found then raise exception 'Profile not found'; end if;
  if p_type is null or p_type not in ('feature', 'bug', 'improvement', 'praise', 'other') then
    raise exception 'Choose a type';
  end if;
  if p_priority is null or p_priority not in ('low', 'medium', 'high') then
    raise exception 'Choose a priority';
  end if;
  if char_length(trim(coalesce(p_message, ''))) < 5 then raise exception 'Please write a little more'; end if;
  if p_store is not null and public.axon_is_owner(p_store) then
    select name into v_store_name from public.axon_stores where id = p_store;
  end if;
  insert into public.axon_feedback
    (user_id, role, store_name, type, priority, message, contact_name, contact_email)
  values
    (auth.uid(), v_prof.role, coalesce(v_store_name, ''), p_type, p_priority,
     left(trim(p_message), 2000),
     case when p_include_contact then v_prof.full_name else '' end,
     case when p_include_contact then v_prof.email else '' end)
  returning * into v_row;
  return v_row;
end $$;

-- Permanently delete the caller's account and everything that belongs to it.
create or replace function public.axon_delete_account() returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  delete from auth.users where id = auth.uid();
end $$;

-- ---------------------------------------------------------------------
-- Admin area. One entry point: every call re-checks the passcode on the
-- server, and repeated wrong guesses are locked out.
-- ---------------------------------------------------------------------

create or replace function public.axon_admin(p_code text, p_action text, p_args jsonb default '{}'::jsonb)
returns jsonb
language plpgsql security definer set search_path = public, extensions, pg_temp as $$
declare
  v_headers jsonb;
  v_key text;
  v_hash text;
  v_fail_key int;
  v_fail_all int;
  v_id uuid;
  v_status text;
  v_new text;
  v_data jsonb;
begin
  begin
    v_headers := coalesce(nullif(current_setting('request.headers', true), ''), '{}')::jsonb;
  exception when others then
    v_headers := '{}'::jsonb;
  end;
  v_key := coalesce(nullif(v_headers ->> 'cf-connecting-ip', ''),
                    nullif(trim(split_part(coalesce(v_headers ->> 'x-forwarded-for', ''), ',', 1)), ''),
                    'unknown');

  delete from public.axon_attempts where at < now() - interval '1 day';
  select count(*) filter (where key = v_key), count(*) into v_fail_key, v_fail_all
    from public.axon_attempts
   where kind = 'admin' and not ok and at > now() - interval '15 minutes';
  if v_fail_key >= 5 or v_fail_all >= 40 then
    return jsonb_build_object('ok', false, 'error', 'locked');
  end if;

  select code_hash into v_hash from public.axon_admin where id;
  if v_hash is null or extensions.crypt(coalesce(p_code, ''), v_hash) <> v_hash then
    insert into public.axon_attempts (kind, key, ok) values ('admin', v_key, false);
    return jsonb_build_object('ok', false, 'error', 'bad_code');
  end if;
  delete from public.axon_attempts where kind = 'admin' and key = v_key;

  if p_action = 'login' then
    return jsonb_build_object('ok', true);

  elsif p_action = 'stats' then
    select jsonb_build_object(
      'owners', (select count(*) from public.axon_profiles where role = 'owner'),
      'customers', (select count(*) from public.axon_profiles where role = 'customer'),
      'stores', (select count(*) from public.axon_stores),
      'products', (select count(*) from public.axon_products),
      'orders', (select count(*) from public.axon_orders),
      'feedback', (select coalesce(jsonb_object_agg(status, c), '{}'::jsonb)
                     from (select status, count(*) as c from public.axon_feedback group by status) s))
      into v_data;
    return jsonb_build_object('ok', true, 'data', v_data);

  elsif p_action = 'list_feedback' then
    select coalesce(jsonb_agg(to_jsonb(f) order by f.created_at desc), '[]'::jsonb) into v_data
      from (select id, type, priority, message, status, role, store_name,
                   contact_name, contact_email, created_at
              from public.axon_feedback order by created_at desc limit 500) f;
    return jsonb_build_object('ok', true, 'data', v_data);

  elsif p_action = 'set_status' then
    begin
      v_id := (p_args ->> 'id')::uuid;
    exception when others then
      return jsonb_build_object('ok', false, 'error', 'bad_request');
    end;
    v_status := p_args ->> 'status';
    if v_status is null or v_status not in ('new', 'reviewing', 'planned', 'done', 'dismissed') then
      return jsonb_build_object('ok', false, 'error', 'bad_request');
    end if;
    update public.axon_feedback set status = v_status where id = v_id;
    return jsonb_build_object('ok', found, 'error', case when found then null else 'not_found' end);

  elsif p_action = 'delete_feedback' then
    begin
      v_id := (p_args ->> 'id')::uuid;
    exception when others then
      return jsonb_build_object('ok', false, 'error', 'bad_request');
    end;
    delete from public.axon_feedback where id = v_id;
    return jsonb_build_object('ok', found, 'error', case when found then null else 'not_found' end);

  elsif p_action = 'change_code' then
    v_new := coalesce(p_args ->> 'new_code', '');
    if char_length(v_new) < 8 or char_length(v_new) > 64 then
      return jsonb_build_object('ok', false, 'error', 'weak_code');
    end if;
    update public.axon_admin set code_hash = extensions.crypt(v_new, extensions.gen_salt('bf', 10)) where id;
    return jsonb_build_object('ok', true);
  end if;

  return jsonb_build_object('ok', false, 'error', 'unknown_action');
end $$;

-- ---------------------------------------------------------------------
-- Tidy-up for projects that ran an older version of this file: password
-- reset now uses a code sent by email, so the security-question parts go.
-- ---------------------------------------------------------------------

drop function if exists public.axon_has_security();
drop function if exists public.axon_set_security(text, text, text, text, text, text);
drop function if exists public.axon_get_questions(text);
drop function if exists public.axon_reset_password(text, text[], text);
drop function if exists public.axon_norm(text);
drop table if exists public.axon_security;

-- ---------------------------------------------------------------------
-- Who may call which function
-- ---------------------------------------------------------------------

revoke all on function
  public.axon_record_sale(uuid, uuid, numeric, numeric, text, text, timestamptz, uuid),
  public.axon_add_expense(uuid, uuid, text, text, text, numeric, date),
  public.axon_delete_sale(uuid),
  public.axon_place_order(uuid, jsonb, text, text, text, text),
  public.axon_set_order_status(uuid, text),
  public.axon_approve_payment(uuid),
  public.axon_analytics(uuid, timestamptz, timestamptz, text),
  public.axon_submit_feedback(text, text, text, boolean, uuid),
  public.axon_delete_account(),
  public.axon_admin(text, text, jsonb),
  public.axon_is_owner(uuid)
from public, anon, authenticated;

grant execute on function
  public.axon_record_sale(uuid, uuid, numeric, numeric, text, text, timestamptz, uuid),
  public.axon_add_expense(uuid, uuid, text, text, text, numeric, date),
  public.axon_delete_sale(uuid),
  public.axon_place_order(uuid, jsonb, text, text, text, text),
  public.axon_set_order_status(uuid, text),
  public.axon_approve_payment(uuid),
  public.axon_analytics(uuid, timestamptz, timestamptz, text),
  public.axon_submit_feedback(text, text, text, boolean, uuid),
  public.axon_delete_account(),
  public.axon_is_owner(uuid)
to authenticated;

-- Signed-out screens: the admin door (it checks the passcode itself).
grant execute on function
  public.axon_admin(text, text, jsonb)
to anon, authenticated;

-- ---------------------------------------------------------------------
-- Live updates: stores see new orders at once, customers see status changes
-- ---------------------------------------------------------------------

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables
                      where pubname = 'supabase_realtime' and schemaname = 'public'
                        and tablename = 'axon_orders') then
    alter publication supabase_realtime add table public.axon_orders;
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Picture storage. Pictures live in folders named after the store id, so
-- only the store owner can add, replace or remove them. Anyone can view.
-- ---------------------------------------------------------------------

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('axon-images', 'axon-images', true, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists axon_images_select on storage.objects;
create policy axon_images_select on storage.objects
  for select to authenticated
  using (bucket_id = 'axon-images'
         and (storage.foldername(name))[1] in
             (select id::text from public.axon_stores where owner_id = (select auth.uid())));
drop policy if exists axon_images_insert on storage.objects;
create policy axon_images_insert on storage.objects
  for insert to authenticated
  with check (bucket_id = 'axon-images'
              and (storage.foldername(name))[1] in
                  (select id::text from public.axon_stores where owner_id = (select auth.uid())));
drop policy if exists axon_images_update on storage.objects;
create policy axon_images_update on storage.objects
  for update to authenticated
  using (bucket_id = 'axon-images'
         and (storage.foldername(name))[1] in
             (select id::text from public.axon_stores where owner_id = (select auth.uid())));
drop policy if exists axon_images_delete on storage.objects;
create policy axon_images_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'axon-images'
         and (storage.foldername(name))[1] in
             (select id::text from public.axon_stores where owner_id = (select auth.uid())));

-- ---------------------------------------------------------------------
-- Admin passcode. It is stored only as a bcrypt hash and is never sent to
-- phones. Running this file again keeps a passcode you changed inside the app.
-- ---------------------------------------------------------------------

insert into public.axon_admin (id, code_hash)
values (true, extensions.crypt('ALM$@cell15', extensions.gen_salt('bf', 10)))
on conflict (id) do nothing;

-- A project that still has the original sample passcode is moved to the one above, so nothing has
-- to be edited by hand. A passcode that was changed inside the app is left alone.
update public.axon_admin
   set code_hash = extensions.crypt('ALM$@cell15', extensions.gen_salt('bf', 10))
 where id and code_hash = extensions.crypt('axon2026', code_hash);
