# AXON, edge of operations

A business manager for shops, farms, companies and supermarkets, with a linked customer store.
Built by Tribridge Studios (founder: Ashraf Abdalla).

* Business owners add goods, farm produce, animals and services with pictures and prices, record every sale
  (stock goes down, revenue goes up), log costs (rent, wages, stock, maintenance, insurance, taxes), and see
  profit, loss and plain-language advice.
* Customers browse stores, save favourites, fill a cart and place orders that reach the store at once.
* Owners and customers have separate logins. All data is stored in the cloud (Supabase), not on the phone.
  The phone only keeps the login session and the cart.
* No hidden fees. The app never handles money: the customer pays the store directly.

Stack: Expo SDK 58 (React Native 0.88, TypeScript) and Supabase (Postgres, Auth, Storage, Realtime).

## 1. Set up the backend (about 10 minutes, free tier is enough)

1. Create a project at https://supabase.com. A fresh project is best, because the schema adds its own `axon_` tables.
2. Nothing in `supabase/schema.sql` needs editing. The admin passcode is already set inside it and is stored in the
   database only as a hash. Because the file contains it, keep your GitHub repository private, or change the passcode
   inside the app after the first run (Admin, then Change passcode). A project that still has the old sample passcode
   is moved to the new one when you run the file again; a passcode you changed in the app is never replaced.
3. In Supabase, open SQL Editor, New query, paste the whole file, press Run. It is safe to run again after updates.
4. Authentication, Providers, Email: the simplest setup is to turn off "Confirm email". The app also works with it
   on, and then asks new people to confirm their email before logging in.
5. **Forgot-password emails (needed once).** The app resets a forgotten password with a 6-digit code sent by email.
   In Supabase open Authentication, Emails, Reset Password, and replace the message with the contents of
   `supabase/reset-password-email.html`. It must contain `{{ .Token }}`. Without it the email has a link instead of
   the code, and the code box cannot work.
6. Supabase's built-in email sender is limited to a few emails an hour and is meant for testing. Before real customers
   use the app, set your own sender: Authentication, Emails, SMTP Settings. A Gmail address with an App Password works
   and costs nothing.
7. Project Settings, API: copy the Project URL and the `anon` (or "publishable") key.

Never put the `service_role` or "secret" key in the app.

## 2. Put your Supabase details in the app

Pick one way. Until this is done, the app shows a setup screen.

* **GitHub secrets (recommended, nothing is typed into the code).** In your GitHub repository (axon): Settings,
  Secrets and variables, Actions, New repository secret. Add two secrets with exactly these names:

  | Secret name | Value |
  | --- | --- |
  | `SUPABASE_URL` | Supabase Project URL, for example `https://abcd1234.supabase.co` |
  | `SUPABASE_ANON_KEY` | the `anon` or "publishable" key |

  The workflow passes them to the build as `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY`. The build
  stops if it finds a `service_role` or secret key.
* **Or** open `src/config.ts` and replace the two placeholder values.

The anon key ends up inside the APK, as it does in every app that talks to Supabase. That is safe, because the rules in
`supabase/schema.sql` decide who can see what.

## 3. Try it on your phone (no APK needed)

```
npm install --legacy-peer-deps
npx expo start
```

Open the QR code with the Expo Go app (it must match Expo SDK 58).

## 4. Build the APK

**A. On a computer with an Expo account (easiest):**

```
npm install --legacy-peer-deps
npx eas-cli login
npx eas-cli build -p android --profile preview
```

EAS builds in the cloud and gives you a download link for the `.apk`.

**B. On GitHub, with no Expo account:** upload the contents of this folder (not the folder itself, so that
`.github/workflows/android-apk.yml` sits at the top of the repository) to your `axon` repository, add the secrets above,
then open the Actions tab, "Build Android APK", Run workflow. Download `axon-apk` from the finished run. The file `.github/workflows/android-apk.yml` does the work. The APK is
built for ARM phones (arm64-v8a and armeabi-v7a), which covers nearly every Android phone.

**C. On your own computer with Android Studio and JDK 17:**

```
npx expo prebuild --platform android
cd android && ./gradlew assembleRelease
```

The APK appears in `android/app/build/outputs/apk/release/`.

APKs from routes B and C are signed with a debug key, which is fine for installing directly. For the Play Store,
use route A with `--profile production` (an app bundle) and let EAS manage the signing key.

## 5. Using the app

* Pick "I run a business" or "I am a customer". Sign up, and owners then create their business profile. A forgotten
  password is reset with a 6-digit code emailed to the account.
* **Customers and stores.** Every customer has one AXON account, like on Jumia, and can order from any store. Each
  order records which store it went to and which account placed it. A store owner sees only the orders placed with
  their own store, so another owner's customers never appear. Sales tab, Customers lists everyone who ordered, marks
  them New or Returning (the same account ordering again), and shows orders and spend. Orders also carry a Returning
  customer badge. A customer cannot be told apart by name or phone alone: those are typed by hand and can differ
  between orders, which is why the account is what counts. An owner account cannot place orders; a business owner who
  wants to shop uses a separate customer account with another email. Sales you record by hand in the shop have only
  a typed customer name, because that person has no account.
* **Offline.** Store owners can open the app, record sales and add expenses without signal. These wait on the phone
  (Sales, Costs and the bar above the tabs show "Waiting to send"), then go to Supabase by themselves when the
  connection returns, oldest first. Each one carries its own id, so a sale is never counted twice even if the signal
  drops while sending. Stock and totals on screen already include what is waiting. If Supabase refuses one (for
  example the stock was used up online in the meantime), it stays in More, Waiting to send, with the reason, and the
  owner can remove it. The app also keeps a copy of the last numbers it loaded, so the shop still shows offline.
  Things that change other people's view (editing items, order status, deleting, settings, sign-up and login) still
  need internet and say so. The first login on a phone needs internet.
* Owner tabs: Home, Stock, Sales, Costs, Profit. Tap the pill at the top for live totals and to switch business.
  Tap Sell on an item to record a sale. New customer orders appear under Sales, Orders: Accept, then Complete.
  An order only becomes revenue when it is completed. Cancelling puts the stock back.
* Customers find stores by name, place or store code, add items to a cart, and check out. They see their order
  status update live.
* Admin: on the first screen (the one with "I run a business" and "I am a customer"), tap Admin in the small row at the
  bottom, next to About, Contact and Privacy. It is also at the very bottom of Settings. Enter the passcode to read
  suggestions people send, mark them reviewing, planned or done, and export them.
* **Paying.** AXON never handles money. At checkout the customer picks how they will pay (cash, M-Pesa, Airtel Money,
  card or bank). The order screen then says Submitted, shows the order number and "awaiting approval", and after a
  short countdown logs the customer out on that phone only (the account, the order and other devices are untouched),
  so the next person cannot open it. Log in again any time to follow the order. The store gets an alert naming the
  payment method, and the order card says "Payment awaiting your approval". When the store has the money it presses
  Approve payment; the order moves to Processing, and Complete turns it into revenue.

## 6. Checks

```
npm run check
```

runs the type-check, 46 app tests (every screen flow against an in-memory backend, including offline) and 20 contract tests. The
contract tests run the app's real API code against the real `supabase/schema.sql` inside a local Postgres
(PGlite), as signed-in people with row-level security on, so a mismatch between the app and the database is caught
before you build.

## Known limits

* Payments are not processed. Checkout records the customer's chosen method (M-Pesa, cash and so on) and shows the
  store's payment instructions. Adding M-Pesa (Daraja) would need a server function and your own Safaricom account.
* The tests run against a local copy of the database rules, not a live Supabase project, and the APK build could
  not be run in the environment where this was written. Do one full pass on your own project after building:
  sign up as an owner, add an item, sign up as a customer, order it, complete it.
* The Privacy Policy text in the app is a plain-language draft. Please have it reviewed before you publish.
* The admin passcode is visible to anyone who can read `schema.sql`, so keep the repository private or change it in the app.
* Password reset depends on Supabase sending the email. It was tested against a pretend email service, not a live
  Supabase project, so send yourself one reset after setup. Anyone who can read an account's inbox can reset its password.
* Offline sales use the stock the phone last saw. If two phones sell the same last item offline, the second sale is
  refused when it is sent and waits for the owner to decide.
* A phone with no signal cannot start the app for the first time (no login yet), and a login unused for a very long time
  may need internet once to renew.
* One cart holds items from one store at a time.

## Contact

Tribridge Studios: Instagram @tribridge_studios, WhatsApp +254 759 858 428, servicestribridge@gmail.com,
https://ashrafabdalla.onrender.com
