import React from 'react';
import { Pressable, StyleSheet, Switch, View } from 'react-native';
import { colors, radius, tint } from '../theme';
import { Icon, type IconName } from './Icon';
import { Text } from './Text';

export function Checkbox({
  checked,
  onChange,
  children,
  error,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  children: React.ReactNode;
  error?: boolean;
}) {
  return (
    <Pressable
      onPress={() => onChange(!checked)}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      style={styles.checkRow}
    >
      <View
        style={[
          styles.box,
          checked ? { backgroundColor: colors.pink, borderColor: colors.pink } : null,
          error && !checked ? { borderColor: colors.red } : null,
        ]}
      >
        {checked ? <Icon name="check" size={14} color={colors.white} /> : null}
      </View>
      <View style={{ flex: 1 }}>{children}</View>
    </Pressable>
  );
}

export function SwitchRow({
  label,
  hint,
  value,
  onChange,
}: {
  label: string;
  hint?: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <View style={styles.switchRow}>
      <View style={{ flex: 1 }}>
        <Text v="bodyMed">{label}</Text>
        {hint ? <Text v="small">{hint}</Text> : null}
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ false: colors.border2, true: tint(colors.pink, 0.55) }}
        thumbColor={value ? colors.pink : colors.off}
        accessibilityLabel={label}
      />
    </View>
  );
}

export function Notice({
  tone = 'info',
  children,
  icon,
}: {
  tone?: 'info' | 'warn' | 'bad' | 'good';
  children: React.ReactNode;
  icon?: IconName;
}) {
  const c = tone === 'bad' ? colors.red : tone === 'warn' ? colors.amber : tone === 'good' ? colors.green : colors.blueLight;
  const ic: IconName = icon ?? (tone === 'bad' ? 'alert-triangle' : tone === 'good' ? 'check-circle' : tone === 'warn' ? 'alert-circle' : 'info');
  return (
    <View style={[styles.notice, { backgroundColor: tint(c, 0.09), borderColor: tint(c, 0.3) }]}>
      <Icon name={ic} size={17} color={c} />
      <View style={{ flex: 1 }}>{children}</View>
    </View>
  );
}

/** A row that looks like a menu item and opens something when pressed. */
export function MenuRow({
  icon,
  label,
  sub,
  onPress,
  color = colors.blueLight,
  right,
  danger,
}: {
  icon: IconName;
  label: string;
  sub?: string;
  onPress: () => void;
  color?: string;
  right?: React.ReactNode;
  danger?: boolean;
}) {
  const c = danger ? colors.red : color;
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [styles.menuRow, pressed ? { opacity: 0.8 } : null]}
    >
      <View style={[styles.menuIcon, { backgroundColor: tint(c, 0.12) }]}>
        <Icon name={icon} size={18} color={c} />
      </View>
      <View style={{ flex: 1 }}>
        <Text v="bodyMed" color={danger ? colors.red : colors.text}>
          {label}
        </Text>
        {sub ? <Text v="small">{sub}</Text> : null}
      </View>
      {right ?? <Icon name="chevron-right" size={18} color={colors.muted} />}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  checkRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 14 },
  box: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1.5,
    borderColor: colors.border2,
    backgroundColor: colors.dk,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 8,
    marginBottom: 6,
  },
  notice: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
    borderWidth: 1,
    borderRadius: radius.md,
    padding: 12,
    marginBottom: 14,
  },
  menuRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 8,
  },
  menuIcon: { width: 38, height: 38, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
});
