import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getAnalytics } from '../lib/ownerData';
import { totals } from '../lib/analytics';
import { money } from '../lib/format';
import { useData } from '../lib/useData';
import { useBiz } from '../state/biz';
import { useActiveStore, useSession } from '../state/session';
import { colors, fonts, radius, tint } from '../theme';
import { Chip } from './Chips';
import { Icon, type IconName } from './Icon';
import { Text } from './Text';

type Dest = { name: string; params?: object };

const NAV: { label: string; icon: IconName; to: Dest }[] = [
  { label: 'Dash', icon: 'grid', to: { name: 'Dash' } },
  { label: 'Stock', icon: 'package', to: { name: 'Stock' } },
  { label: 'Sales', icon: 'shopping-bag', to: { name: 'Sales' } },
  { label: 'Costs', icon: 'credit-card', to: { name: 'Costs' } },
  { label: 'P/L', icon: 'bar-chart-2', to: { name: 'Analysis' } },
];

/**
 * The pill at the top of every business screen. Tap it to open live totals,
 * jump to another section, or switch business.
 */
export function Island() {
  const nav = useNavigation<{ navigate: (name: string, params?: object) => void }>();
  const insets = useSafeAreaInsets();
  const store = useActiveStore();
  const stores = useSession((s) => s.stores);
  const setActiveStore = useSession((s) => s.setActiveStore);
  const version = useBiz((s) => s.version);
  const { data } = useData(() => getAnalytics(store!.id), [store?.id, version], !!store);
  const [open, setOpen] = useState(false);
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!open) return;
    anim.setValue(0);
    Animated.spring(anim, { toValue: 1, useNativeDriver: true, friction: 8, tension: 90 }).start();
  }, [open, anim]);

  if (!store) return null;
  const t = data ? totals(data) : null;
  const cur = store.currency;
  const go = (d: Dest) => {
    setOpen(false);
    nav.navigate(d.name, d.params);
  };

  return (
    <>
      {open ? (
        <Pressable
          style={styles.backdrop}
          onPress={() => setOpen(false)}
          accessibilityLabel="Close menu"
        />
      ) : null}
      <View pointerEvents="box-none" style={[styles.anchor, { top: insets.top + 6 }]}>
        {!open ? (
          <Pressable
            onPress={() => setOpen(true)}
            accessibilityRole="button"
            accessibilityLabel={`Open business menu for ${store.name}`}
            style={styles.pill}
          >
            <View style={styles.dot} />
            <Text style={styles.pillName} numberOfLines={1}>
              {store.name}
            </Text>
            {t ? (
              <Text
                style={[styles.pillProfit, { color: t.profit >= 0 ? colors.green : colors.red }]}
                numberOfLines={1}
              >
                {money(t.profit, cur, true)}
              </Text>
            ) : null}
            {data && data.new_orders > 0 ? (
              <View style={styles.badge}>
                <Text style={{ fontFamily: fonts.bodyBold, fontSize: 10, color: colors.white }}>{data.new_orders}</Text>
              </View>
            ) : null}
            <Icon name="chevron-down" size={14} color={colors.muted} />
          </Pressable>
        ) : (
          <Animated.View
            style={[
              styles.panel,
              {
                opacity: anim,
                transform: [
                  { scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1] }) },
                  { translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [-12, 0] }) },
                ],
              },
            ]}
          >
            <View style={styles.panelHead}>
              <View style={styles.dot} />
              <View style={{ flex: 1 }}>
                <Text v="h3" numberOfLines={1}>
                  {store.name}
                </Text>
                <Text v="tiny">Store code {store.code}</Text>
              </View>
              <Pressable onPress={() => setOpen(false)} hitSlop={10} accessibilityRole="button" accessibilityLabel="Close">
                <Icon name="chevron-up" size={20} color={colors.off} />
              </Pressable>
            </View>

            <View style={styles.stats}>
              <Stat label="Revenue" value={t ? money(t.revenue, cur, true) : '-'} color={colors.green} />
              <Stat label="Expenses" value={t ? money(t.expenses, cur, true) : '-'} color={colors.red} />
              <Stat
                label={t && t.profit < 0 ? 'Loss' : 'Profit'}
                value={t ? money(t.profit, cur, true) : '-'}
                color={t && t.profit < 0 ? colors.red : colors.green}
              />
            </View>

            <View style={styles.navRow}>
              {NAV.map((n) => (
                <Pressable
                  key={n.label}
                  onPress={() => go(n.to)}
                  accessibilityRole="button"
                  accessibilityLabel={n.label}
                  style={styles.navBtn}
                >
                  <Icon name={n.icon} size={19} color={colors.text} />
                  <Text v="tiny" color={colors.off} style={{ marginTop: 4 }}>
                    {n.label}
                  </Text>
                </Pressable>
              ))}
            </View>

            <View style={styles.actions}>
              <Action
                icon="inbox"
                label={data && data.new_orders > 0 ? `Orders (${data.new_orders})` : 'Orders'}
                onPress={() => go({ name: 'Sales', params: { segment: 'orders' } })}
              />
              <Action icon="briefcase" label="Businesses" onPress={() => go({ name: 'Businesses' })} />
              <Action icon="menu" label="More" onPress={() => go({ name: 'More' })} />
            </View>

            {stores.length > 1 ? (
              <View style={styles.switcher}>
                <Text v="label" style={{ marginBottom: 8 }}>
                  Switch business
                </Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {stores.map((s) => (
                    <Chip
                      key={s.id}
                      label={s.name}
                      selected={s.id === store.id}
                      onPress={() => {
                        setActiveStore(s.id);
                        setOpen(false);
                      }}
                    />
                  ))}
                </View>
              </View>
            ) : null}
          </Animated.View>
        )}
      </View>
    </>
  );
}

function Stat({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <View style={[styles.stat, { backgroundColor: tint(color, 0.08), borderColor: tint(color, 0.22) }]}>
      <Text v="tiny">{label}</Text>
      <Text v="numSm" color={color} numberOfLines={1} style={{ marginTop: 2 }}>
        {value}
      </Text>
    </View>
  );
}

function Action({ icon, label, onPress }: { icon: IconName; label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={styles.action}>
      <Icon name={icon} size={15} color={colors.blueLight} />
      <Text style={{ fontFamily: fonts.ui, fontSize: 12, color: colors.text }} numberOfLines={1}>
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  backdrop: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(0,0,0,0.55)', zIndex: 90, elevation: 18 },
  anchor: { position: 'absolute', left: 12, right: 12, alignItems: 'center', zIndex: 100, elevation: 20 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    maxWidth: '92%',
    height: 40,
    paddingHorizontal: 14,
    borderRadius: radius.pill,
    backgroundColor: '#000000',
    borderWidth: 1,
    borderColor: colors.border2,
  },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.pink },
  pillName: { fontFamily: fonts.headBold, fontSize: 13, color: colors.text, flexShrink: 1 },
  pillProfit: { fontFamily: fonts.headBold, fontSize: 12 },
  badge: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    backgroundColor: colors.pink,
    alignItems: 'center',
    justifyContent: 'center',
  },
  panel: {
    width: '100%',
    backgroundColor: '#05050c',
    borderRadius: 28,
    borderWidth: 1,
    borderColor: colors.border2,
    padding: 16,
  },
  panelHead: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 },
  stats: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  stat: { flex: 1, borderRadius: radius.md, borderWidth: 1, paddingVertical: 8, paddingHorizontal: 10 },
  navRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  navBtn: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    marginHorizontal: 2,
    borderRadius: radius.md,
    backgroundColor: colors.card,
  },
  actions: { flexDirection: 'row', gap: 8 },
  action: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: 38,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border2,
  },
  switcher: { marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: colors.border },
});
