import React from 'react';
import { Pressable, ScrollView, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { colors, fonts, radius, tint } from '../theme';
import { Text } from './Text';

export function Chip({
  label,
  selected,
  onPress,
  color = colors.blueLight,
}: {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  color?: string;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected }}
      style={[
        styles.chip,
        selected
          ? { backgroundColor: tint(color, 0.16), borderColor: color }
          : { backgroundColor: colors.dk, borderColor: colors.border2 },
      ]}
    >
      <Text
        style={{ fontFamily: fonts.ui, fontSize: 12, color: selected ? color : colors.off }}
        numberOfLines={1}
      >
        {label}
      </Text>
    </Pressable>
  );
}

/** Horizontally scrolling row of chips, for filters. */
export function ChipRow({ children }: { children: React.ReactNode }) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={{ gap: 8, paddingRight: 8 }}
      style={{ flexGrow: 0, marginVertical: 4 }}
    >
      {children}
    </ScrollView>
  );
}

/** Chips that wrap onto several lines, for forms. */
export function ChipWrap({ children }: { children: React.ReactNode }) {
  return <View style={styles.wrap}>{children}</View>;
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  style,
}: {
  options: { key: T; label: string; badge?: number }[];
  value: T;
  onChange: (k: T) => void;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <View style={[styles.seg, style]}>
      {options.map((o) => {
        const on = o.key === value;
        return (
          <Pressable
            key={o.key}
            onPress={() => onChange(o.key)}
            accessibilityRole="button"
            accessibilityState={{ selected: on }}
            style={[styles.segItem, on ? { backgroundColor: colors.card2, borderColor: colors.border2 } : null]}
          >
            <Text style={{ fontFamily: fonts.headBold, fontSize: 12, color: on ? colors.text : colors.muted }}>
              {o.label}
            </Text>
            {o.badge ? (
              <View style={styles.dot}>
                <Text style={{ fontFamily: fonts.bodyBold, fontSize: 10, color: colors.white }}>{o.badge}</Text>
              </View>
            ) : null}
          </Pressable>
        );
      })}
    </View>
  );
}

export function Badge({ label, color = colors.blueLight }: { label: string; color?: string }) {
  return (
    <View style={[styles.badge, { backgroundColor: tint(color, 0.14), borderColor: tint(color, 0.35) }]}>
      <Text style={{ fontFamily: fonts.ui, fontSize: 10, letterSpacing: 0.5, color, textTransform: 'uppercase' }}>
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  chip: {
    paddingHorizontal: 14,
    height: 34,
    borderRadius: radius.pill,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  seg: {
    flexDirection: 'row',
    backgroundColor: colors.dk,
    borderRadius: radius.md,
    padding: 3,
    borderWidth: 1,
    borderColor: colors.border,
  },
  segItem: {
    flex: 1,
    height: 38,
    borderRadius: radius.md - 3,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 6,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  dot: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    backgroundColor: colors.pink,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radius.pill,
    borderWidth: 1,
  },
});
