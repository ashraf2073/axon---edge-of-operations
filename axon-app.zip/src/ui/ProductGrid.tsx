import React from 'react';
import { View, useWindowDimensions } from 'react-native';
import { cardWidth } from '../lib/layout';
import { addToCart } from '../state/cartActions';
import type { CartStore } from '../state/cart';
import { useWishlist } from '../state/wishlist';
import type { Product } from '../types';
import { ShopProductCard } from './Product';
import { Text } from './Text';

export interface GridItem {
  product: Product;
  store: CartStore;
  /** show "from <store>" under the card (used when items come from many stores) */
  showStore?: boolean;
}

/** Marketplace-style grid: picture, price right under it, heart and add-to-cart on every card. */
export function ProductGrid({ items, onOpen }: { items: GridItem[]; onOpen: (p: Product) => void }) {
  const { width } = useWindowDimensions();
  const wished = useWishlist((s) => s.ids);
  const toggle = useWishlist((s) => s.toggle);
  const w = cardWidth(width);

  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
      {items.map(({ product, store, showStore }) => (
        <View key={product.id} style={{ width: w }}>
          <ShopProductCard
            p={product}
            currency={store.currency}
            width={w}
            wished={!!wished[product.id]}
            onPress={() => onOpen(product)}
            onToggleWish={() => void toggle(product.id)}
            onAdd={() => addToCart(store, product)}
          />
          {showStore ? (
            <Text v="tiny" numberOfLines={1} style={{ marginTop: 4, paddingHorizontal: 4 }}>
              from {store.name}
            </Text>
          ) : null}
        </View>
      ))}
    </View>
  );
}
