import Feather from '@expo/vector-icons/Feather';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import React from 'react';
import { colors } from '../theme';

export type IconName = React.ComponentProps<typeof Feather>['name'];

/** Plain line icons. No emojis anywhere in AXON. */
export function Icon({ name, size = 20, color = colors.off }: { name: IconName; size?: number; color?: string }) {
  return <Feather name={name} size={size} color={color} />;
}

export type BrandName = 'whatsapp' | 'instagram' | 'gmail';

/** Real brand logos for the Contact page. */
export function BrandIcon({ name, size = 24, color = colors.white }: { name: BrandName; size?: number; color?: string }) {
  return <MaterialCommunityIcons name={name} size={size} color={color} />;
}
