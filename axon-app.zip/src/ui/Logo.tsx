import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, View } from 'react-native';
import Svg, { Circle, Defs, Line, LinearGradient, Stop } from 'react-native-svg';
import { colors, fonts } from '../theme';
import { SLOGAN } from '../lib/content';
import { Text } from './Text';

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

/**
 * The AXON mark: two white legs, a pink crossbar split in two, and the
 * glowing gap between them (the synapse).
 */
export function Logo({ size = 92, pulse = false }: { size?: number; pulse?: boolean }) {
  const t = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!pulse) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(t, { toValue: 1, duration: 950, easing: Easing.inOut(Easing.ease), useNativeDriver: false }),
        Animated.timing(t, { toValue: 0, duration: 950, easing: Easing.inOut(Easing.ease), useNativeDriver: false }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [pulse, t]);

  const r = t.interpolate({ inputRange: [0, 1], outputRange: [2.6, 5.6] });
  const opacity = t.interpolate({ inputRange: [0, 1], outputRange: [0.35, 1] });

  return (
    <Svg width={size} height={size} viewBox="0 0 92 92" accessibilityLabel="AXON logo">
      <Defs>
        <LinearGradient id="axonBar" x1="0%" y1="0%" x2="100%" y2="0%">
          <Stop offset="0%" stopColor={colors.pinkDark} />
          <Stop offset="100%" stopColor={colors.pink} />
        </LinearGradient>
      </Defs>
      <Line x1="11" y1="84" x2="40" y2="14" stroke="#ffffff" strokeWidth={7.5} strokeLinecap="round" />
      <Line x1="81" y1="84" x2="52" y2="14" stroke="#ffffff" strokeWidth={7.5} strokeLinecap="round" />
      <Line x1="26" y1="55" x2="38" y2="55" stroke="url(#axonBar)" strokeWidth={7} strokeLinecap="round" />
      <Line x1="54" y1="55" x2="66" y2="55" stroke="url(#axonBar)" strokeWidth={7} strokeLinecap="round" />
      {pulse ? (
        <AnimatedCircle cx="46" cy="55" r={r as unknown as number} fill="url(#axonBar)" opacity={opacity as unknown as number} />
      ) : (
        <Circle cx="46" cy="55" r="4" fill="url(#axonBar)" />
      )}
    </Svg>
  );
}

/** Logo on the left, the word AXON on the right. */
export function Wordmark({ size = 28, slogan = false }: { size?: number; slogan?: boolean }) {
  return (
    <View style={styles.row}>
      <Logo size={size} />
      <View>
        <Text
          style={{
            fontFamily: fonts.head,
            fontSize: size * 0.8,
            letterSpacing: size * 0.22,
            color: colors.white,
            lineHeight: size * 0.95,
          }}
        >
          AXON
        </Text>
        {slogan ? (
          <Text style={{ fontFamily: fonts.ui, fontSize: 9, letterSpacing: 2.4, color: colors.muted, textTransform: 'uppercase' }}>
            {SLOGAN}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
});
