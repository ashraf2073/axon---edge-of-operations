import React from 'react';
import { Text as RNText, type StyleProp, type TextProps, type TextStyle } from 'react-native';
import { colors, fonts } from '../theme';

export type Variant =
  | 'display'
  | 'h1'
  | 'h2'
  | 'h3'
  | 'label'
  | 'body'
  | 'bodyMed'
  | 'bold'
  | 'small'
  | 'tiny'
  | 'num'
  | 'numSm';

const base: Record<Variant, TextStyle> = {
  display: { fontFamily: fonts.head, fontSize: 30, letterSpacing: 1.2, color: colors.text },
  h1: { fontFamily: fonts.head, fontSize: 24, letterSpacing: 0.4, color: colors.text },
  h2: { fontFamily: fonts.headBold, fontSize: 18, color: colors.text },
  h3: { fontFamily: fonts.headBold, fontSize: 15, color: colors.text },
  label: {
    fontFamily: fonts.ui,
    fontSize: 11,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    color: colors.muted,
  },
  body: { fontFamily: fonts.body, fontSize: 14, lineHeight: 21, color: colors.off },
  bodyMed: { fontFamily: fonts.bodyMed, fontSize: 14, lineHeight: 21, color: colors.text },
  bold: { fontFamily: fonts.bodyBold, fontSize: 14, color: colors.text },
  small: { fontFamily: fonts.body, fontSize: 12, lineHeight: 17, color: colors.off },
  tiny: { fontFamily: fonts.ui, fontSize: 10, letterSpacing: 0.6, color: colors.muted },
  num: { fontFamily: fonts.head, fontSize: 22, color: colors.text },
  numSm: { fontFamily: fonts.headBold, fontSize: 16, color: colors.text },
};

interface Props extends TextProps {
  v?: Variant;
  color?: string;
  center?: boolean;
  style?: StyleProp<TextStyle>;
}

export function Text({ v = 'body', color, center, style, ...rest }: Props) {
  return (
    <RNText
      maxFontSizeMultiplier={1.25}
      {...rest}
      style={[base[v], color ? { color } : null, center ? { textAlign: 'center' } : null, style]}
    />
  );
}
