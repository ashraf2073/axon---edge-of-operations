import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, View } from 'react-native';
import { SLOGAN } from '../lib/content';
import { colors, fonts } from '../theme';
import { Logo } from './Logo';
import { Text } from './Text';

/** Shown every time the app opens, and while the account loads. */
export function Splash({ message }: { message?: string }) {
  const fade = useRef(new Animated.Value(0)).current;
  const bar = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fade, { toValue: 1, duration: 600, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    const loop = Animated.loop(
      Animated.timing(bar, { toValue: 1, duration: 1400, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
    );
    loop.start();
    return () => loop.stop();
  }, [fade, bar]);

  return (
    <View style={styles.root}>
      <Animated.View
        style={{
          alignItems: 'center',
          opacity: fade,
          transform: [{ scale: fade.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1] }) }],
        }}
      >
        <Logo size={112} pulse />
        <Text
          style={{
            fontFamily: fonts.head,
            fontSize: 38,
            letterSpacing: 12,
            color: colors.white,
            marginTop: 18,
            marginLeft: 12,
          }}
        >
          AXON
        </Text>
        <Text
          style={{
            fontFamily: fonts.ui,
            fontSize: 11,
            letterSpacing: 4,
            color: colors.off,
            marginTop: 8,
            textTransform: 'uppercase',
          }}
        >
          {SLOGAN}
        </Text>
      </Animated.View>
      <View style={styles.track}>
        <Animated.View
          style={[
            styles.fill,
            {
              transform: [
                { translateX: bar.interpolate({ inputRange: [0, 1], outputRange: [-90, 190] }) },
              ],
            },
          ]}
        />
      </View>
      {message ? (
        <Text v="small" color={colors.muted} style={{ marginTop: 14 }}>
          {message}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' },
  track: {
    width: 100,
    height: 3,
    borderRadius: 2,
    backgroundColor: colors.border,
    overflow: 'hidden',
    marginTop: 36,
  },
  fill: { width: 50, height: 3, borderRadius: 2, backgroundColor: colors.pink },
});
