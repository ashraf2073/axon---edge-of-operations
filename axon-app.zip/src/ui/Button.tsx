import { LinearGradient } from 'expo-linear-gradient';
import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { colors, fonts, radius, tint } from '../theme';
import { Icon, type IconName } from './Icon';
import { Text } from './Text';

export type ButtonVariant = 'primary' | 'blue' | 'outline' | 'ghost' | 'danger' | 'success';

interface Props {
  title: string;
  onPress?: () => void;
  variant?: ButtonVariant;
  size?: 'md' | 'sm';
  icon?: IconName;
  loading?: boolean;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  full?: boolean;
}

const TEXT_COLOR: Record<ButtonVariant, string> = {
  primary: colors.white,
  blue: colors.white,
  outline: colors.text,
  ghost: colors.blueLight,
  danger: colors.red,
  success: colors.green,
};

export function Button({
  title,
  onPress,
  variant = 'primary',
  size = 'md',
  icon,
  loading,
  disabled,
  style,
  full = true,
}: Props) {
  const inactive = disabled || loading;
  const height = size === 'sm' ? 38 : 50;
  const tc = TEXT_COLOR[variant];

  const content = (
    <View style={styles.inner}>
      {loading ? (
        <ActivityIndicator color={tc} size="small" />
      ) : (
        <>
          {icon ? <Icon name={icon} size={size === 'sm' ? 15 : 18} color={tc} /> : null}
          <Text
            style={{
              fontFamily: fonts.headBold,
              fontSize: size === 'sm' ? 12 : 14,
              letterSpacing: 0.4,
              color: tc,
            }}
            numberOfLines={1}
          >
            {title}
          </Text>
        </>
      )}
    </View>
  );

  const shell: ViewStyle = {
    height,
    borderRadius: radius.md,
    overflow: 'hidden',
    alignSelf: full ? 'stretch' : 'flex-start',
    opacity: inactive && !loading ? 0.45 : 1,
  };

  let body: React.ReactNode;
  if (variant === 'primary') {
    body = (
      <LinearGradient
        colors={[colors.pinkDark, colors.pink]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={styles.fill}
      >
        {content}
      </LinearGradient>
    );
  } else {
    const bg: ViewStyle =
      variant === 'blue'
        ? { backgroundColor: colors.blue }
        : variant === 'outline'
          ? { backgroundColor: 'transparent', borderWidth: 1, borderColor: colors.border2 }
          : variant === 'danger'
            ? { backgroundColor: tint(colors.red, 0.12), borderWidth: 1, borderColor: tint(colors.red, 0.3) }
            : variant === 'success'
              ? { backgroundColor: tint(colors.green, 0.12), borderWidth: 1, borderColor: tint(colors.green, 0.3) }
              : { backgroundColor: 'transparent' };
    body = <View style={[styles.fill, bg]}>{content}</View>;
  }

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      accessibilityState={{ disabled: !!inactive, busy: !!loading }}
      disabled={inactive}
      onPress={onPress}
      style={({ pressed }) => [shell, pressed && !inactive ? { opacity: 0.8 } : null, style]}
    >
      {body}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16 },
  inner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
});
