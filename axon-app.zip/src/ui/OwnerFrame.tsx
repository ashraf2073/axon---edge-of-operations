import React from 'react';
import { View } from 'react-native';
import { colors } from '../theme';
import { Island } from './Island';
import { OfflineBar } from './OfflineBar';
import { Screen } from './Screen';

/** Every business tab screen sits inside this: the Island on top, content below. */
export function OwnerFrame({
  children,
  onRefresh,
  refreshing,
  scroll = true,
}: {
  children: React.ReactNode;
  onRefresh?: () => void;
  refreshing?: boolean;
  scroll?: boolean;
}) {
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Screen scroll={scroll} bottom={false} topExtra={56} onRefresh={onRefresh} refreshing={refreshing}>
        {children}
      </Screen>
      <OfflineBar />
      <Island />
    </View>
  );
}
