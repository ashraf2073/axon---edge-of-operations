import { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import React, { useEffect, useState } from 'react';
import { Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { formatDate, toDateKey } from '../lib/format';
import { colors, fonts, radius } from '../theme';
import type { DateFormat } from '../types';
import { Icon } from './Icon';
import { Text } from './Text';

/** Tap to choose a date. Falls back to typing YYYY-MM-DD where the system picker is unavailable. */
export function DateField({
  label,
  value,
  onChange,
  format = 'DD/MM/YYYY',
  maxToday = true,
}: {
  label: string;
  value: Date;
  onChange: (d: Date) => void;
  format?: DateFormat;
  maxToday?: boolean;
}) {
  const [text, setText] = useState(toDateKey(value));
  useEffect(() => setText(toDateKey(value)), [value]);

  const open = () => {
    DateTimePickerAndroid.open({
      value,
      mode: 'date',
      maximumDate: maxToday ? new Date() : undefined,
      onValueChange: (_e, d) => onChange(d),
    });
  };

  return (
    <View style={{ marginBottom: 14 }}>
      <Text v="label" style={{ marginBottom: 6 }}>
        {label}
      </Text>
      {Platform.OS === 'android' ? (
        <Pressable onPress={open} accessibilityRole="button" accessibilityLabel={`${label}: ${formatDate(value, format)}`} style={styles.box}>
          <Icon name="calendar" size={17} color={colors.muted} />
          <Text v="bodyMed" style={{ flex: 1 }}>
            {formatDate(value, format)}
          </Text>
          <Icon name="chevron-down" size={16} color={colors.muted} />
        </Pressable>
      ) : (
        <View style={styles.box}>
          <Icon name="calendar" size={17} color={colors.muted} />
          <TextInput
            value={text}
            onChangeText={(t) => {
              setText(t);
              if (/^\d{4}-\d{2}-\d{2}$/.test(t)) {
                const [y, m, d] = t.split('-').map(Number);
                const dt = new Date(y, m - 1, d);
                if (!Number.isNaN(dt.getTime())) onChange(dt);
              }
            }}
            placeholder="YYYY-MM-DD"
            placeholderTextColor={colors.muted}
            style={{ flex: 1, color: colors.text, fontFamily: fonts.body, fontSize: 15, paddingVertical: 0 }}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    height: 50,
    paddingHorizontal: 12,
    backgroundColor: colors.dk,
    borderWidth: 1,
    borderColor: colors.border2,
    borderRadius: radius.md,
  },
});
