import React, { useEffect, useRef } from 'react';
import { Animated, Pressable, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useToast } from '../lib/toast';
import { colors, radius } from '../theme';
import { Icon, type IconName } from './Icon';
import { Text } from './Text';

const KIND: Record<'success' | 'error' | 'info', { color: string; icon: IconName }> = {
  success: { color: colors.green, icon: 'check-circle' },
  error: { color: colors.red, icon: 'alert-circle' },
  info: { color: colors.blueLight, icon: 'info' },
};

/** Mount once at the root. Shows short messages at the top of the screen. */
export function ToastHost() {
  const { id, msg, kind, hide } = useToast();
  const insets = useSafeAreaInsets();
  const slide = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!msg) return;
    slide.setValue(0);
    Animated.timing(slide, { toValue: 1, duration: 200, useNativeDriver: true }).start();
    const t = setTimeout(() => {
      Animated.timing(slide, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => hide());
    }, kind === 'error' ? 4200 : 2600);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!msg) return null;
  const k = KIND[kind];
  return (
    <Animated.View
      pointerEvents="box-none"
      style={[
        styles.wrap,
        {
          top: insets.top + 8,
          opacity: slide,
          transform: [{ translateY: slide.interpolate({ inputRange: [0, 1], outputRange: [-20, 0] }) }],
        },
      ]}
    >
      <Pressable onPress={hide} accessibilityRole="alert" style={[styles.toast, { borderColor: k.color }]}>
        <Icon name={k.icon} size={18} color={k.color} />
        <Text v="bodyMed" style={{ flex: 1 }}>
          {msg}
        </Text>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', left: 14, right: 14, zIndex: 999, elevation: 30 },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: colors.card2,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
});
