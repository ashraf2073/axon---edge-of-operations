import React from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { colors, radius, tint } from '../theme';
import { Button } from './Button';
import { Icon, type IconName } from './Icon';
import { Text } from './Text';

export function Loading({ label }: { label?: string }) {
  return (
    <View style={styles.center}>
      <ActivityIndicator color={colors.pink} size="large" />
      {label ? (
        <Text v="small" style={{ marginTop: 12 }}>
          {label}
        </Text>
      ) : null}
    </View>
  );
}

export function EmptyState({
  icon = 'inbox',
  title,
  body,
  actionLabel,
  onAction,
}: {
  icon?: IconName;
  title: string;
  body?: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <View style={styles.empty}>
      <View style={styles.iconWrap}>
        <Icon name={icon} size={26} color={colors.blueLight} />
      </View>
      <Text v="h3" center style={{ marginTop: 14 }}>
        {title}
      </Text>
      {body ? (
        <Text v="body" center style={{ marginTop: 6, maxWidth: 280 }}>
          {body}
        </Text>
      ) : null}
      {actionLabel && onAction ? (
        <Button title={actionLabel} onPress={onAction} full={false} size="sm" style={{ marginTop: 16, paddingHorizontal: 8 }} />
      ) : null}
    </View>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <View style={styles.empty}>
      <View style={[styles.iconWrap, { backgroundColor: tint(colors.red, 0.12) }]}>
        <Icon name="alert-triangle" size={26} color={colors.red} />
      </View>
      <Text v="h3" center style={{ marginTop: 14 }}>
        Something is not right
      </Text>
      <Text v="body" center style={{ marginTop: 6, maxWidth: 300 }}>
        {message}
      </Text>
      {onRetry ? (
        <Button title="Try again" onPress={onRetry} full={false} size="sm" variant="outline" style={{ marginTop: 16, paddingHorizontal: 8 }} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, minHeight: 200 },
  empty: { alignItems: 'center', justifyContent: 'center', padding: 28, minHeight: 220 },
  iconWrap: {
    width: 60,
    height: 60,
    borderRadius: radius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: tint(colors.blueLight, 0.12),
  },
});
