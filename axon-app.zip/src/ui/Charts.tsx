import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { money, monthShort } from '../lib/format';
import { colors, radius } from '../theme';
import type { Currency, MonthPoint } from '../types';
import { Row } from './Layout';
import { Text } from './Text';

const CHART_H = 120;

/** Six months of revenue (green) next to expenses (red). Tap a month for its numbers. */
export function MonthlyBars({ data, currency }: { data: MonthPoint[]; currency: Currency }) {
  const [sel, setSel] = useState(Math.max(0, data.length - 1));
  useEffect(() => {
    setSel(Math.max(0, data.length - 1));
  }, [data.length]);

  const max = Math.max(1, ...data.flatMap((d) => [Number(d.revenue) || 0, Number(d.expenses) || 0]));
  const empty = data.every((d) => !Number(d.revenue) && !Number(d.expenses));
  const cur = data[sel];

  return (
    <View>
      <View style={styles.bars}>
        {data.map((d, i) => {
          const on = i === sel;
          const rev = Number(d.revenue) || 0;
          const exp = Number(d.expenses) || 0;
          return (
            <Pressable
              key={d.month}
              onPress={() => setSel(i)}
              accessibilityRole="button"
              accessibilityLabel={`${monthShort(d.month)} revenue ${rev} expenses ${exp}`}
              style={styles.col}
            >
              <View style={styles.pair}>
                <View
                  style={[
                    styles.bar,
                    { height: Math.max(3, (rev / max) * CHART_H), backgroundColor: colors.green, opacity: on ? 1 : 0.5 },
                  ]}
                />
                <View
                  style={[
                    styles.bar,
                    { height: Math.max(3, (exp / max) * CHART_H), backgroundColor: colors.red, opacity: on ? 1 : 0.5 },
                  ]}
                />
              </View>
              <Text v="tiny" color={on ? colors.text : colors.muted} style={{ marginTop: 6 }}>
                {monthShort(d.month)}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {empty ? (
        <Text v="small" center style={{ marginTop: 10 }}>
          Record sales and costs to see your six-month trend.
        </Text>
      ) : cur ? (
        <View style={styles.detail}>
          <Row justify="space-between">
            <Legend color={colors.green} label="Revenue" value={money(cur.revenue, currency, true)} />
            <Legend color={colors.red} label="Expenses" value={money(cur.expenses, currency, true)} />
            <Legend
              color={cur.revenue - cur.expenses >= 0 ? colors.green : colors.red}
              label="Profit"
              value={money(cur.revenue - cur.expenses, currency, true)}
            />
          </Row>
        </View>
      ) : null}
    </View>
  );
}

function Legend({ color, label, value }: { color: string; label: string; value: string }) {
  return (
    <View style={{ alignItems: 'flex-start' }}>
      <Row gap={6}>
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }} />
        <Text v="tiny">{label}</Text>
      </Row>
      <Text v="numSm" color={color} style={{ marginTop: 2 }}>
        {value}
      </Text>
    </View>
  );
}

/** One horizontal bar with a label, an amount and a percentage. */
export function BarRow({
  label,
  amount,
  pct,
  color,
  currency,
  sub,
}: {
  label: string;
  amount: number;
  pct: number;
  color: string;
  currency: Currency;
  sub?: string;
}) {
  const w = `${Math.min(100, Math.max(2, pct))}%` as `${number}%`;
  return (
    <View style={{ marginBottom: 14 }}>
      <Row justify="space-between" style={{ marginBottom: 6 }}>
        <View style={{ flex: 1 }}>
          <Text v="bodyMed" numberOfLines={1}>
            {label}
          </Text>
          {sub ? <Text v="tiny">{sub}</Text> : null}
        </View>
        <Text v="bold" color={color}>
          {money(amount, currency)}
        </Text>
        <Text v="small" style={{ width: 46, textAlign: 'right' }}>
          {pct.toFixed(1)}%
        </Text>
      </Row>
      <View style={styles.track}>
        <View style={{ width: w, height: 6, borderRadius: 3, backgroundColor: color }} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bars: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', gap: 4 },
  col: { flex: 1, alignItems: 'center', minHeight: CHART_H + 24 },
  pair: { height: CHART_H, flexDirection: 'row', alignItems: 'flex-end', gap: 3 },
  bar: { width: 11, borderRadius: 3 },
  detail: {
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  track: { height: 6, borderRadius: 3, backgroundColor: colors.border, overflow: 'hidden' },
});

export const chartRadius = radius.md;
