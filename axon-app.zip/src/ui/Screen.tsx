import { useNavigation } from '@react-navigation/native';
import React from 'react';
import {
  KeyboardAvoidingView,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, radius } from '../theme';
import { Icon } from './Icon';
import { Text } from './Text';

export function Screen({
  children,
  scroll = true,
  onRefresh,
  refreshing = false,
  top = true,
  bottom = true,
  topExtra = 0,
  padded = true,
  footer,
  style,
  contentStyle,
}: {
  children: React.ReactNode;
  scroll?: boolean;
  onRefresh?: () => void;
  refreshing?: boolean;
  /** add the status-bar height at the top */
  top?: boolean;
  /** add the gesture-bar height at the bottom (turn off inside tab screens) */
  bottom?: boolean;
  topExtra?: number;
  padded?: boolean;
  footer?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
}) {
  const insets = useSafeAreaInsets();
  const padTop = (top ? insets.top : 0) + topExtra;
  const padBottom = bottom ? insets.bottom : 0;

  const body = scroll ? (
    <ScrollView
      style={{ flex: 1 }}
      contentContainerStyle={[
        padded ? { paddingHorizontal: 16, paddingBottom: 28 } : null,
        { flexGrow: 1 },
        contentStyle,
      ]}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      refreshControl={
        onRefresh ? (
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.pink}
            colors={[colors.pink]}
            progressBackgroundColor={colors.card2}
          />
        ) : undefined
      }
    >
      {children}
    </ScrollView>
  ) : (
    <View style={[{ flex: 1 }, padded ? { paddingHorizontal: 16 } : null, contentStyle]}>{children}</View>
  );

  return (
    <KeyboardAvoidingView behavior="padding" style={[styles.root, { paddingTop: padTop, paddingBottom: padBottom }, style]}>
      {body}
      {footer ? <View style={styles.footer}>{footer}</View> : null}
    </KeyboardAvoidingView>
  );
}

/** Title bar with a back button, used on screens that are not tabs. */
export function Header({
  title,
  subtitle,
  right,
  onBack,
  back = true,
}: {
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  onBack?: () => void;
  back?: boolean;
}) {
  const nav = useNavigation();
  const canBack = back && (onBack || nav.canGoBack());
  return (
    <View style={styles.header}>
      {canBack ? (
        <Pressable
          onPress={onBack ?? (() => nav.goBack())}
          hitSlop={10}
          accessibilityRole="button"
          accessibilityLabel="Go back"
          style={styles.back}
        >
          <Icon name="chevron-left" size={22} color={colors.text} />
        </Pressable>
      ) : null}
      <View style={{ flex: 1 }}>
        <Text v="h2" numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? (
          <Text v="small" numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {right}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  footer: {
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 10,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 14,
  },
  back: {
    width: 38,
    height: 38,
    borderRadius: radius.md,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
