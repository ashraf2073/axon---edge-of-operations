import React from 'react';
import { View } from 'react-native';
import type { Advice, Tone } from '../lib/analytics';
import { colors, radius, tint } from '../theme';
import type { FeedbackStatus } from '../types';
import { Icon, type IconName } from './Icon';
import { Row } from './Layout';
import { Text } from './Text';

export function toneColor(t: Tone): string {
  return t === 'bad' ? colors.red : t === 'warn' ? colors.amber : t === 'good' ? colors.green : colors.blueLight;
}

const TONE_ICON: Record<Tone, IconName> = {
  bad: 'alert-triangle',
  warn: 'alert-circle',
  good: 'trending-up',
  info: 'info',
};

export function feedbackStatusColor(s: FeedbackStatus): string {
  switch (s) {
    case 'new':
      return colors.blueLight;
    case 'reviewing':
      return colors.amber;
    case 'planned':
      return colors.purple;
    case 'done':
      return colors.green;
    default:
      return colors.muted;
  }
}

/** A tinted box with a title and a few sentences of advice. */
export function AdviceCard({ advice }: { advice: Advice }) {
  const c = toneColor(advice.tone);
  return (
    <View
      style={{
        backgroundColor: tint(c, 0.08),
        borderColor: tint(c, 0.3),
        borderWidth: 1,
        borderRadius: radius.lg,
        padding: 14,
        marginBottom: 10,
      }}
    >
      <Row gap={10} align="flex-start">
        <View style={{ marginTop: 2 }}>
          <Icon name={TONE_ICON[advice.tone]} size={18} color={c} />
        </View>
        <View style={{ flex: 1 }}>
          <Text v="h3" color={c}>
            {advice.title}
          </Text>
          <Text v="body" style={{ marginTop: 4 }}>
            {advice.body}
          </Text>
        </View>
      </Row>
    </View>
  );
}
