import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React from 'react';
import { Pressable, View } from 'react-native';
import type { RootParams } from '../nav/types';
import { useNet } from '../state/net';
import { useOutbox } from '../state/outbox';
import { useSession } from '../state/session';
import { colors, radius, tint } from '../theme';
import { Icon } from './Icon';
import { Text } from './Text';

/**
 * A thin bar above the tabs. It appears when the phone cannot reach the cloud, or when
 * something saved on the phone is still waiting to be sent, and opens the "Waiting to send" list.
 */
export function OfflineBar() {
  const nav = useNavigation<NativeStackNavigationProp<RootParams>>();
  const online = useNet((s) => s.online);
  const uid = useSession((s) => s.profile?.id);
  const waiting = useOutbox((s) => s.items.filter((i) => i.ownerId === uid && i.status === 'waiting').length);
  const failed = useOutbox((s) => s.items.filter((i) => i.ownerId === uid && i.status === 'failed').length);

  if (online && waiting === 0 && failed === 0) return null;

  const color = failed > 0 ? colors.red : colors.amber;
  const parts: string[] = [];
  if (!online) parts.push('Offline');
  if (waiting > 0) parts.push(`${waiting} waiting to send`);
  if (failed > 0) parts.push(`${failed} not saved`);
  const label = parts.join('. ');
  const hint = !online
    ? 'Sales and expenses you add are saved on this phone and sent when you are back online.'
    : failed > 0
      ? 'Tap to see what went wrong.'
      : 'Sending now. Tap to see the list.';

  return (
    <Pressable
      onPress={() => nav.navigate('Outbox')}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={{
        marginHorizontal: 12,
        marginBottom: 8,
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: radius.md,
        borderWidth: 1,
        borderColor: tint(color, 0.4),
        backgroundColor: tint(color, 0.12),
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
      }}
    >
      <Icon name={online ? 'upload-cloud' : 'wifi-off'} size={17} color={color} />
      <View style={{ flex: 1 }}>
        <Text v="bodyMed" color={colors.text}>
          {label}
        </Text>
        <Text v="tiny" color={colors.off}>
          {hint}
        </Text>
      </View>
      <Icon name="chevron-right" size={16} color={colors.off} />
    </Pressable>
  );
}
