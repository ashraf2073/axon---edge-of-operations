import React, { forwardRef, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View, type StyleProp, type TextInputProps, type ViewStyle } from 'react-native';
import { colors, fonts, radius } from '../theme';
import { Icon, type IconName } from './Icon';
import { Text } from './Text';

interface Props extends TextInputProps {
  label?: string;
  error?: string | null;
  hint?: string;
  secure?: boolean;
  icon?: IconName;
  containerStyle?: StyleProp<ViewStyle>;
  prefix?: string;
}

export const Input = forwardRef<React.ComponentRef<typeof TextInput>, Props>(function Input(
  { label, error, hint, secure, icon, containerStyle, prefix, style, multiline, onFocus, onBlur, ...rest },
  ref,
) {
  const [focused, setFocused] = useState(false);
  const [hidden, setHidden] = useState(!!secure);
  const border = error ? colors.red : focused ? colors.blueLight : colors.border2;

  return (
    <View style={[styles.wrap, containerStyle]}>
      {label ? (
        <Text v="label" style={styles.label}>
          {label}
        </Text>
      ) : null}
      <View
        style={[
          styles.box,
          { borderColor: border },
          multiline ? { alignItems: 'flex-start', minHeight: 96 } : { height: 50 },
        ]}
      >
        {icon ? (
          <View style={[styles.icon, multiline ? { marginTop: 14 } : null]}>
            <Icon name={icon} size={17} color={focused ? colors.blueLight : colors.muted} />
          </View>
        ) : null}
        {prefix ? (
          <Text v="bodyMed" color={colors.off} style={multiline ? { marginTop: 13 } : null}>
            {prefix}{' '}
          </Text>
        ) : null}
        <TextInput
          ref={ref}
          placeholderTextColor={colors.muted}
          selectionColor={colors.pink}
          cursorColor={colors.pink}
          accessibilityLabel={label}
          secureTextEntry={hidden}
          multiline={multiline}
          textAlignVertical={multiline ? 'top' : 'center'}
          onFocus={(e) => {
            setFocused(true);
            onFocus?.(e);
          }}
          onBlur={(e) => {
            setFocused(false);
            onBlur?.(e);
          }}
          {...rest}
          style={[styles.input, multiline ? { paddingTop: 13, paddingBottom: 13 } : null, style]}
        />
        {secure ? (
          <Pressable
            hitSlop={10}
            onPress={() => setHidden((h) => !h)}
            accessibilityRole="button"
            accessibilityLabel={hidden ? 'Show password' : 'Hide password'}
            style={styles.eye}
          >
            <Icon name={hidden ? 'eye' : 'eye-off'} size={18} color={colors.muted} />
          </Pressable>
        ) : null}
      </View>
      {error ? (
        <Text v="small" color={colors.red} style={styles.msg}>
          {error}
        </Text>
      ) : hint ? (
        <Text v="small" color={colors.muted} style={styles.msg}>
          {hint}
        </Text>
      ) : null}
    </View>
  );
});

const styles = StyleSheet.create({
  wrap: { marginBottom: 14 },
  label: { marginBottom: 6 },
  box: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dk,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: 12,
  },
  icon: { marginRight: 8 },
  input: {
    flex: 1,
    color: colors.text,
    fontFamily: fonts.body,
    fontSize: 15,
    paddingVertical: 0,
  },
  eye: { paddingLeft: 8 },
  msg: { marginTop: 5 },
});
