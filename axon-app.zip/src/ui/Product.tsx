import { Image } from 'expo-image';
import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View, type ImageStyle, type StyleProp } from 'react-native';
import { money, qty as fmtQty } from '../lib/format';
import { colors, fonts, radius, tint } from '../theme';
import type { Currency, Product } from '../types';
import { Badge } from './Chips';
import { Icon } from './Icon';
import { Text } from './Text';

export function ProductImage({ uri, style }: { uri: string | null | undefined; style?: StyleProp<ImageStyle> }) {
  if (uri) {
    return <Image source={{ uri }} style={style} contentFit="cover" transition={150} cachePolicy="disk" />;
  }
  return (
    <View style={[style as object, styles.placeholder]}>
      <Icon name="image" size={26} color={colors.muted} />
    </View>
  );
}

export function stockInfo(p: Pick<Product, 'track_stock' | 'stock' | 'low_alert' | 'unit'>): {
  label: string;
  color: string;
  out: boolean;
} {
  if (!p.track_stock) return { label: 'Available', color: colors.blueLight, out: false };
  if (p.stock <= 0) return { label: 'Sold out', color: colors.red, out: true };
  if (p.low_alert > 0 && p.stock <= p.low_alert) {
    return { label: `Low: ${fmtQty(p.stock)} ${p.unit}`, color: colors.amber, out: false };
  }
  return { label: `${fmtQty(p.stock)} ${p.unit} in stock`, color: colors.green, out: false };
}

/** Item card on the store owner's Stock screen. */
export function OwnerProductCard({
  p,
  currency,
  width,
  onPress,
  onSell,
}: {
  p: Product;
  currency: Currency;
  width: number;
  onPress: () => void;
  onSell: () => void;
}) {
  const s = stockInfo(p);
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${p.name}, ${money(p.price, currency)}`}
      style={({ pressed }) => [styles.card, { width }, pressed ? { opacity: 0.85 } : null]}
    >
      <View>
        <ProductImage uri={p.image_url} style={{ width: '100%', aspectRatio: 1 }} />
        {!p.active ? (
          <View style={styles.hiddenTag}>
            <Badge label="Hidden" color={colors.amber} />
          </View>
        ) : null}
      </View>
      <View style={{ padding: 10 }}>
        <Text v="bodyMed" numberOfLines={1}>
          {p.name}
        </Text>
        <Text v="tiny" numberOfLines={1}>
          {p.category} / {p.unit}
        </Text>
        <Text v="numSm" color={colors.pinkLight} style={{ marginTop: 6 }}>
          {money(p.price, currency)}
        </Text>
        <Text v="small" color={s.color} style={{ marginTop: 2 }} numberOfLines={1}>
          {s.label}
        </Text>
        <Pressable
          onPress={onSell}
          disabled={s.out}
          accessibilityRole="button"
          accessibilityLabel={`Sell ${p.name}`}
          style={[styles.sell, s.out ? { opacity: 0.4 } : null]}
        >
          <Icon name="shopping-bag" size={14} color={colors.white} />
          <Text style={{ fontFamily: fonts.headBold, fontSize: 12, color: colors.white }}>Sell</Text>
        </Pressable>
      </View>
    </Pressable>
  );
}

/** Item card in the customer's store, like a marketplace listing: price sits right under the picture. */
export function ShopProductCard({
  p,
  currency,
  width,
  wished,
  onPress,
  onToggleWish,
  onAdd,
}: {
  p: Product;
  currency: Currency;
  width: number;
  wished: boolean;
  onPress: () => void;
  onToggleWish: () => void;
  onAdd: () => void;
}) {
  const s = stockInfo(p);
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${p.name}, ${money(p.price, currency)}`}
      style={({ pressed }) => [styles.card, { width }, pressed ? { opacity: 0.85 } : null]}
    >
      <View>
        <ProductImage uri={p.image_url} style={{ width: '100%', aspectRatio: 1 }} />
        <Pressable
          onPress={onToggleWish}
          hitSlop={8}
          accessibilityRole="button"
          accessibilityLabel={wished ? 'Remove from wishlist' : 'Add to wishlist'}
          style={styles.heart}
        >
          <Icon name="heart" size={17} color={wished ? colors.pink : colors.white} />
        </Pressable>
        {s.out ? (
          <View style={styles.soldOut}>
            <Text style={{ fontFamily: fonts.headBold, fontSize: 12, color: colors.white, letterSpacing: 1 }}>SOLD OUT</Text>
          </View>
        ) : null}
      </View>
      <View style={{ padding: 10 }}>
        <Text v="numSm" color={colors.pinkLight}>
          {money(p.price, currency)}
          <Text v="tiny"> / {p.unit}</Text>
        </Text>
        <Text v="bodyMed" numberOfLines={2} style={{ marginTop: 3, minHeight: 40 }}>
          {p.name}
        </Text>
        <View style={styles.footerRow}>
          <Text v="tiny" color={s.color} numberOfLines={1} style={{ flex: 1 }}>
            {s.label}
          </Text>
          <Pressable
            onPress={onAdd}
            disabled={s.out}
            hitSlop={6}
            accessibilityRole="button"
            accessibilityLabel={`Add ${p.name} to cart`}
            style={[styles.add, s.out ? { opacity: 0.35 } : null]}
          >
            <Icon name="plus" size={18} color={colors.white} />
          </Pressable>
        </View>
      </View>
    </Pressable>
  );
}

/** Minus, an editable number, plus. */
export function QtyStepper({
  value,
  onChange,
  min = 1,
  max,
  step = 1,
}: {
  value: number;
  onChange: (n: number) => void;
  min?: number;
  max?: number | null;
  step?: number;
}) {
  const [text, setText] = useState(String(value));
  useEffect(() => setText(String(value)), [value]);
  const clamp = (n: number) => {
    let v = Number.isFinite(n) ? n : min;
    v = Math.max(min, v);
    if (max != null) v = Math.min(max, v);
    return Math.round(v * 1000) / 1000;
  };
  const commit = (raw: string) => {
    const n = clamp(parseFloat(raw.replace(',', '.')));
    setText(String(n));
    onChange(n);
  };
  return (
    <View style={styles.stepper}>
      <Pressable
        onPress={() => onChange(value - step >= min ? clamp(value - step) : value)}
        hitSlop={6}
        accessibilityRole="button"
        accessibilityLabel="Decrease quantity"
        style={styles.stepBtn}
      >
        <Icon name="minus" size={16} color={colors.text} />
      </Pressable>
      <TextInput
        value={text}
        onChangeText={setText}
        onEndEditing={(e) => commit(e.nativeEvent.text)}
        onBlur={() => commit(text)}
        keyboardType="decimal-pad"
        selectTextOnFocus
        accessibilityLabel="Quantity"
        style={styles.stepInput}
      />
      <Pressable
        onPress={() => onChange(clamp(value + step))}
        hitSlop={6}
        accessibilityRole="button"
        accessibilityLabel="Increase quantity"
        style={styles.stepBtn}
      >
        <Icon name="plus" size={16} color={colors.text} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  placeholder: { backgroundColor: colors.card2, alignItems: 'center', justifyContent: 'center' },
  hiddenTag: { position: 'absolute', top: 8, left: 8 },
  heart: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(6,6,15,0.62)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  soldOut: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(6,6,15,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sell: {
    marginTop: 10,
    height: 34,
    borderRadius: radius.sm,
    backgroundColor: colors.blue,
    flexDirection: 'row',
    gap: 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6, gap: 8 },
  add: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.pink,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dk,
    borderWidth: 1,
    borderColor: colors.border2,
    borderRadius: radius.md,
    height: 44,
    alignSelf: 'flex-start',
  },
  stepBtn: { width: 42, height: 42, alignItems: 'center', justifyContent: 'center' },
  stepInput: {
    minWidth: 52,
    textAlign: 'center',
    color: colors.text,
    fontFamily: fonts.headBold,
    fontSize: 16,
    paddingVertical: 0,
  },
});

export const productTint = tint;
