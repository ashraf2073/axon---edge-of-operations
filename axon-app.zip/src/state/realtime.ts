import { useEffect } from 'react';
import { ORDER_STATUS_LABEL, payLabel } from '../lib/content';
import { supabase } from '../lib/supabase';
import { toast } from '../lib/toast';
import type { OrderStatus, PayMethod } from '../types';
import { useBiz } from './biz';

type OrderRow = { code?: string; status?: OrderStatus; customer_name?: string; pay_method?: PayMethod; payment_status?: string };

/** A store owner hears about new and changed orders the moment they happen. */
export function useOwnerOrdersRealtime(storeId: string | undefined) {
  useEffect(() => {
    if (!storeId) return;
    const channel = supabase
      .channel(`axon-owner-orders-${storeId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'axon_orders', filter: `store_id=eq.${storeId}` },
        (payload) => {
          useBiz.getState().bump();
          if (payload.eventType === 'INSERT') {
            const row = payload.new as OrderRow;
            const how = row.pay_method ? ` Payment by ${payLabel(row.pay_method)} is awaiting your approval.` : '';
            toast.info(`New order ${row.code ?? ''} from ${row.customer_name ?? 'a customer'}.${how}`.replace('  ', ' '));
          }
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [storeId]);
}

/** A customer sees their order change (accepted, completed, cancelled) as it happens. */
export function useCustomerOrdersRealtime(userId: string | undefined) {
  useEffect(() => {
    if (!userId) return;
    const channel = supabase
      .channel(`axon-customer-orders-${userId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'axon_orders', filter: `customer_id=eq.${userId}` },
        (payload) => {
          useBiz.getState().bump();
          const row = payload.new as OrderRow;
          if (row.status && row.code) {
            toast.info(`Order ${row.code} is now ${ORDER_STATUS_LABEL[row.status].toLowerCase()}.`);
          }
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [userId]);
}
