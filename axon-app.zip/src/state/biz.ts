import { create } from 'zustand';

/**
 * A counter that goes up whenever the business numbers change (a sale, an
 * expense, an order, a stock edit). Screens include it in their data
 * dependencies so everything refreshes together: shop to profit.
 */
interface BizState {
  version: number;
  bump: () => void;
}

export const useBiz = create<BizState>((set, get) => ({
  version: 0,
  bump: () => set({ version: get().version + 1 }),
}));
