import NetInfo, { type NetInfoState } from '@react-native-community/netinfo';
import { create } from 'zustand';
import { SUPABASE_URL } from '../config';

/**
 * Whether the phone can reach the internet.
 * - `connected` is what the phone itself reports (airplane mode, no signal).
 * - `failing` is set when a request fails even though the phone says it is connected
 *   (a weak or captive connection), and cleared by the next request that works.
 * - `online` is both together, and is what the screens read.
 */
interface NetState {
  connected: boolean;
  failing: boolean;
  online: boolean;
  setConnected: (c: boolean) => void;
  reportFailure: () => void;
  reportSuccess: () => void;
}

export const useNet = create<NetState>((set, get) => ({
  connected: true,
  failing: false,
  online: true,
  setConnected: (c) => {
    // a connection that just came back starts clean; one that is still up keeps its failing flag
    const failing = c && get().connected ? get().failing : false;
    set({ connected: c, failing, online: c && !failing });
  },
  reportFailure: () => {
    if (!get().failing) set({ failing: true, online: false });
  },
  // a request that worked is the best proof the phone is online, whatever the radio says
  reportSuccess: () => {
    if (!get().online) set({ connected: true, failing: false, online: true });
  },
}));

const reachable = (state: NetInfoState) => state.isConnected !== false && state.isInternetReachable !== false;

/**
 * Starts listening to the phone's connection. Calls `onBack` each time the connection returns.
 * "Reachable" is tested against the AXON backend itself, so it means what the app needs: that
 * Supabase can be reached, not just that some network is attached.
 */
export function startNetWatch(onBack: () => void): () => void {
  try {
    NetInfo.configure({
      reachabilityUrl: `${SUPABASE_URL}/auth/v1/health`,
      // any answer at all (even "no key") proves the server can be reached
      reachabilityTest: async (response) => response.status > 0 && response.status < 500,
      reachabilityShortTimeout: 5000,
      reachabilityLongTimeout: 30000,
      reachabilityRequestTimeout: 15000,
    });
  } catch {
    // the default test still works
  }
  return NetInfo.addEventListener((state) => {
    const connected = reachable(state);
    const was = useNet.getState().connected;
    useNet.getState().setConnected(connected);
    if (connected && !was) onBack();
  });
}

/** Asks the phone to test the connection right now. Returns true when the backend can be reached. */
export async function checkConnection(): Promise<boolean> {
  try {
    const ok = reachable(await NetInfo.refresh());
    useNet.getState().setConnected(ok);
    if (ok) useNet.getState().reportSuccess();
    return ok;
  } catch {
    return useNet.getState().online;
  }
}
