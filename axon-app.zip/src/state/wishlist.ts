import { create } from 'zustand';
import { setWished, wishlistIds } from '../api/customer';
import { toast } from '../lib/toast';
import { friendly } from '../lib/errors';
import { supabase } from '../lib/supabase';

interface WishlistState {
  ids: Record<string, true>;
  version: number;
  load: () => Promise<void>;
  toggle: (productId: string) => Promise<void>;
  clear: () => void;
}

export const useWishlist = create<WishlistState>((set, get) => ({
  ids: {},
  version: 0,

  load: async () => {
    try {
      const list = await wishlistIds();
      const ids: Record<string, true> = {};
      list.forEach((id) => (ids[id] = true));
      set({ ids });
    } catch {
      // the wishlist is not critical; try again next time
    }
  },

  toggle: async (productId) => {
    const uid = (await supabase.auth.getSession()).data.session?.user.id;
    if (!uid) return;
    const was = !!get().ids[productId];
    const next = { ...get().ids };
    if (was) delete next[productId];
    else next[productId] = true;
    set({ ids: next });
    try {
      await setWished(uid, productId, !was);
      set({ version: get().version + 1 });
    } catch (e) {
      const back = { ...get().ids };
      if (was) back[productId] = true;
      else delete back[productId];
      set({ ids: back });
      toast.error(friendly(e));
    }
  },

  clear: () => set({ ids: {}, version: 0 }),
}));
