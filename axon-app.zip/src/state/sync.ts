import { useEffect } from 'react';
import { AppState } from 'react-native';
import { checkConnection, startNetWatch, useNet } from './net';
import { useOutbox } from './outbox';
import { useSession } from './session';

const TICK_MS = 20000;

/** One round of catching up: restore the real account if a saved copy is on screen, then send what is waiting. */
export async function syncNow(): Promise<void> {
  if (!useNet.getState().connected) return;
  const session = useSession.getState();
  if (session.fromCache) {
    try {
      await session.loadAccount({ force: true });
    } catch {
      // still no connection to the account; try again on the next round
    }
  }
  await useOutbox.getState().flush();
}

/**
 * Keeps the app honest about the connection and sends saved work when it can:
 * when the phone reports a connection, when the app comes back to the front, and every
 * 20 seconds while something is waiting or the last request failed.
 */
export function useOfflineSync(enabled: boolean): void {
  useEffect(() => {
    if (!enabled) return;
    void useOutbox.getState().load();
    const stopNet = startNetWatch(() => void syncNow());
    const stopApp = AppState.addEventListener('change', (state) => {
      if (state === 'active') void checkConnection().then((ok) => (ok ? syncNow() : undefined));
    });
    const timer = setInterval(() => {
      const net = useNet.getState();
      const waiting = useOutbox.getState().items.some((i) => i.status === 'waiting');
      if (net.failing || !net.online || useSession.getState().fromCache || waiting) {
        void checkConnection().then((ok) => (ok ? syncNow() : undefined));
      }
    }, TICK_MS);
    return () => {
      stopNet();
      stopApp.remove();
      clearInterval(timer);
    };
  }, [enabled]);
}
