import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { supabase } from '../lib/supabase';

const KEY = 'axon.consent.v1';

export interface Consent {
  at: string;
  /** may the team see my name and email on the feedback I send */
  contact: boolean;
}

interface PrefsState {
  loaded: boolean;
  consent: Consent | null;
  load: () => Promise<void>;
  accept: (contact: boolean) => Promise<void>;
  /** copy the consent given on this phone to the signed-in account */
  syncToAccount: () => Promise<void>;
}

export const usePrefs = create<PrefsState>((set, get) => ({
  loaded: false,
  consent: null,

  load: async () => {
    try {
      const raw = await AsyncStorage.getItem(KEY);
      set({ consent: raw ? (JSON.parse(raw) as Consent) : null, loaded: true });
    } catch {
      set({ consent: null, loaded: true });
    }
  },

  accept: async (contact) => {
    const consent: Consent = { at: new Date().toISOString(), contact };
    set({ consent });
    try {
      await AsyncStorage.setItem(KEY, JSON.stringify(consent));
    } catch {
      // the choice still applies for this session
    }
  },

  syncToAccount: async () => {
    const c = get().consent;
    const uid = (await supabase.auth.getSession()).data.session?.user.id;
    if (!c || !uid) return;
    try {
      await supabase.from('axon_profiles').update({ consent_at: c.at, consent_contact: c.contact }).eq('id', uid);
    } catch {
      // not critical
    }
  },
}));
