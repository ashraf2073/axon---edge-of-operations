import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { addExpense, recordSale } from '../api/owner';
import { friendly, isNetworkError, isSessionError } from '../lib/errors';
import { supabase } from '../lib/supabase';
import { toast } from '../lib/toast';
import { useBiz } from './biz';
import { useNet } from './net';
import { useSession } from './session';

/**
 * Sales and expenses an owner saved while offline. They wait here, on the phone, until the
 * connection is back, then go to the cloud one at a time, oldest first.
 *
 * Every item carries an id that the database remembers, so an item that is sent twice (for
 * example when the signal drops just after the cloud received it) is still counted once.
 */

const KEY = 'axon-outbox-v1';

export interface QueuedSale {
  productId: string;
  productName: string;
  unit: string;
  qty: number;
  price: number;
  customer: string;
  note: string;
  /** the real moment of the sale, not the moment it was sent */
  soldAt: string;
}

export interface QueuedExpense {
  category: string;
  description: string;
  payee: string;
  amount: number;
  spentOn: string;
}

export type OutboxItem = {
  id: string;
  ownerId: string;
  storeId: string;
  createdAt: string;
  /** waiting: will be sent. failed: the cloud refused it, so a person has to decide. */
  status: 'waiting' | 'failed';
  error?: string;
} & ({ kind: 'sale'; sale: QueuedSale } | { kind: 'expense'; expense: QueuedExpense });

interface OutboxState {
  items: OutboxItem[];
  loaded: boolean;
  syncing: boolean;
  load: () => Promise<void>;
  add: (item: OutboxItem) => Promise<void>;
  remove: (id: string) => Promise<void>;
  retry: (id: string) => Promise<void>;
  purge: (ownerId: string) => Promise<void>;
  flush: () => Promise<{ sent: number; failed: number }>;
}

let loading: Promise<void> | null = null;
let running: Promise<{ sent: number; failed: number }> | null = null;

async function save(items: OutboxItem[]): Promise<void> {
  await AsyncStorage.setItem(KEY, JSON.stringify(items));
}

async function send(item: OutboxItem): Promise<void> {
  if (item.kind === 'sale') {
    await recordSale({
      storeId: item.storeId,
      productId: item.sale.productId,
      qty: item.sale.qty,
      price: item.sale.price,
      customer: item.sale.customer,
      note: item.sale.note,
      soldAt: new Date(item.sale.soldAt),
      clientId: item.id,
    });
  } else {
    await addExpense({ storeId: item.storeId, ...item.expense, clientId: item.id });
  }
}

export const useOutbox = create<OutboxState>((set, get) => ({
  items: [],
  loaded: false,
  syncing: false,

  load: () => {
    if (get().loaded) return Promise.resolve();
    if (loading) return loading;
    loading = (async () => {
      let items: OutboxItem[] = [];
      try {
        const raw = await AsyncStorage.getItem(KEY);
        const parsed = raw ? (JSON.parse(raw) as unknown) : [];
        if (Array.isArray(parsed)) items = parsed as OutboxItem[];
      } catch {
        items = [];
      }
      // anything added while the file was being read stays
      set({ items: [...items, ...get().items.filter((x) => !items.some((y) => y.id === x.id))], loaded: true });
    })().finally(() => {
      loading = null;
    });
    return loading;
  },

  add: async (item) => {
    await get().load();
    const next = [...get().items, item];
    await save(next);
    set({ items: next });
  },

  remove: async (id) => {
    const next = get().items.filter((x) => x.id !== id);
    set({ items: next });
    await save(next).catch(() => undefined);
  },

  retry: async (id) => {
    const next = get().items.map((x) => (x.id === id ? { ...x, status: 'waiting' as const, error: undefined } : x));
    set({ items: next });
    await save(next).catch(() => undefined);
    void get().flush();
  },

  purge: async (ownerId) => {
    const next = get().items.filter((x) => x.ownerId !== ownerId);
    set({ items: next });
    await save(next).catch(() => undefined);
  },

  flush: () => {
    if (running) return running;
    running = (async () => {
      await get().load();
      const uid = useSession.getState().profile?.id;
      if (!uid) return { sent: 0, failed: 0 };
      const waiting = () =>
        get()
          .items.filter((x) => x.ownerId === uid && x.status === 'waiting')
          .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      if (waiting().length === 0) return { sent: 0, failed: 0 };

      // asking for the session also gives the login a chance to renew itself after a long time offline
      const { data } = await supabase.auth.getSession();
      if (!data.session) return { sent: 0, failed: 0 };

      set({ syncing: true });
      let sent = 0;
      let failed = 0;
      try {
        for (const item of waiting()) {
          try {
            await send(item);
            useNet.getState().reportSuccess();
            await get().remove(item.id);
            sent += 1;
          } catch (e) {
            if (isNetworkError(e)) {
              useNet.getState().reportFailure();
              break;
            }
            if (isSessionError(e)) break;
            const next = get().items.map((x) =>
              x.id === item.id ? { ...x, status: 'failed' as const, error: friendly(e) } : x,
            );
            set({ items: next });
            await save(next).catch(() => undefined);
            failed += 1;
          }
        }
      } finally {
        set({ syncing: false });
      }
      if (sent > 0) {
        useBiz.getState().bump();
        toast.success(sent === 1 ? 'Sent 1 saved item to the cloud.' : `Sent ${sent} saved items to the cloud.`);
      }
      if (failed > 0) {
        toast.error(
          failed === 1
            ? '1 saved item could not be saved. Open Waiting to send to see why.'
            : `${failed} saved items could not be saved. Open Waiting to send to see why.`,
        );
      }
      return { sent, failed };
    })().finally(() => {
      running = null;
    });
    return running;
  },
}));

/** What is waiting to be sent for one business of the person who is logged in. */
export function pendingFor(items: OutboxItem[], ownerId: string | undefined, storeId?: string): OutboxItem[] {
  if (!ownerId) return [];
  return items.filter((x) => x.ownerId === ownerId && x.status === 'waiting' && (!storeId || x.storeId === storeId));
}
