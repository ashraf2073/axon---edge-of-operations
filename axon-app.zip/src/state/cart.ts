import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { Currency, Product } from '../types';

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  unit: string;
  imageUrl: string | null;
  qty: number;
  /** stock on hand when added, or null when stock is not tracked */
  maxQty: number | null;
}

export interface CartStore {
  id: string;
  name: string;
  currency: Currency;
}

interface CartState {
  store: CartStore | null;
  items: CartItem[];
  /** 'other-store' means the cart already holds items from a different store */
  add: (store: CartStore, p: Product, qty?: number) => 'added' | 'other-store' | 'sold-out';
  startNew: (store: CartStore, p: Product, qty?: number) => void;
  setQty: (productId: string, qty: number) => void;
  remove: (productId: string) => void;
  clear: () => void;
}

function toItem(p: Product, qty: number): CartItem {
  return {
    productId: p.id,
    name: p.name,
    price: p.price,
    unit: p.unit,
    imageUrl: p.image_url,
    qty,
    maxQty: p.track_stock ? p.stock : null,
  };
}

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      store: null,
      items: [],

      add: (store, p, qty = 1) => {
        if (p.track_stock && p.stock <= 0) return 'sold-out';
        const cur = get();
        if (cur.store && cur.store.id !== store.id && cur.items.length > 0) return 'other-store';
        const found = cur.items.find((i) => i.productId === p.id);
        const cap = p.track_stock ? p.stock : Infinity;
        if (found) {
          set({
            store,
            items: cur.items.map((i) =>
              i.productId === p.id ? { ...i, qty: Math.min(cap, i.qty + qty), maxQty: p.track_stock ? p.stock : null } : i,
            ),
          });
        } else {
          set({ store, items: [...cur.items, toItem(p, Math.min(cap, qty))] });
        }
        return 'added';
      },

      startNew: (store, p, qty = 1) => {
        set({ store, items: [toItem(p, qty)] });
      },

      setQty: (productId, qty) => {
        set({
          items: get().items.map((i) => {
            if (i.productId !== productId) return i;
            const capped = i.maxQty != null ? Math.min(i.maxQty, qty) : qty;
            return { ...i, qty: Math.max(0.001, capped) };
          }),
        });
      },

      remove: (productId) => {
        const items = get().items.filter((i) => i.productId !== productId);
        set({ items, store: items.length ? get().store : null });
      },

      clear: () => set({ items: [], store: null }),
    }),
    {
      name: 'axon-cart-v1',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({ store: s.store, items: s.items }),
    },
  ),
);

export const cartLines = (s: { items: CartItem[] }) => s.items.length;
export const cartTotal = (s: { items: CartItem[] }) =>
  Math.round(s.items.reduce((t, i) => t + i.price * i.qty, 0) * 100) / 100;
