import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Session } from '@supabase/supabase-js';
import { create } from 'zustand';
import { passwordLogin } from '../api/account';
import { listMyStores } from '../api/owner';
import { clearCache } from '../lib/cache';
import { AppError, friendly, isNetworkError } from '../lib/errors';
import { supabase } from '../lib/supabase';
import type { Profile, Role, Store } from '../types';
import { useCart } from './cart';
import { useNet } from './net';
import { useWishlist } from './wishlist';

const activeKey = (uid: string) => `axon.activeStore.${uid}`;
const SNAPSHOT_KEY = 'axon.account.v1';

/** A copy of who is logged in and their businesses, so the app can open without a connection. */
interface Snapshot {
  uid: string;
  profile: Profile;
  stores: Store[];
  activeStoreId: string | null;
}

async function readSnapshot(): Promise<Snapshot | null> {
  try {
    const raw = await AsyncStorage.getItem(SNAPSHOT_KEY);
    if (!raw) return null;
    const snap = JSON.parse(raw) as Snapshot;
    return snap && snap.uid && snap.profile && Array.isArray(snap.stores) ? snap : null;
  } catch {
    return null;
  }
}

function writeSnapshot(s: Snapshot): void {
  void AsyncStorage.setItem(SNAPSHOT_KEY, JSON.stringify(s)).catch(() => undefined);
}

interface SessionState {
  /** the saved login has been looked up */
  ready: boolean;
  session: Session | null;
  accountLoaded: boolean;
  accountError: string | null;
  profile: Profile | null;
  stores: Store[];
  activeStoreId: string | null;
  pendingRole: Role | null;
  /** true while a forgotten password is being reset, so the app does not open the account halfway */
  recovering: boolean;
  /** true when the account on screen is the saved copy because there is no connection */
  fromCache: boolean;

  init: () => () => void;
  loadAccount: (opts?: { force?: boolean }) => Promise<void>;
  signIn: (role: Role, email: string, password: string) => Promise<void>;
  /** 'local' ends the login on this phone only; 'global' (the default) ends it on every device. */
  signOut: (scope?: 'global' | 'local') => Promise<void>;
  reset: () => void;
  setActiveStore: (id: string) => void;
  upsertStore: (s: Store) => void;
  removeStore: (id: string) => void;
  patchProfile: (p: Partial<Profile>) => void;
  setRecovering: (on: boolean) => void;
}

/** Thrown after a person logs in on the wrong side (an owner email on the customer door, or the reverse). */
class RoleMismatch extends AppError {}

let inflight: Promise<void> | null = null;

export const useSession = create<SessionState>((set, get) => {
  const keepSnapshot = () => {
    const { profile, stores, activeStoreId } = get();
    if (profile && !get().fromCache) writeSnapshot({ uid: profile.id, profile, stores, activeStoreId });
  };

  return {
    ready: false,
    session: null,
    accountLoaded: false,
    accountError: null,
    profile: null,
    stores: [],
    activeStoreId: null,
    pendingRole: null,
    recovering: false,
    fromCache: false,

    init: () => {
      supabase.auth
        .getSession()
        .then(async ({ data, error }) => {
          if (data.session) {
            set({ session: data.session, ready: true });
            void get().loadAccount().catch(() => undefined);
            return;
          }
          // No login could be confirmed. Without a connection the saved login is still on the phone,
          // so open the saved copy of the account instead of sending the person to the login screen.
          if (error && isNetworkError(error)) {
            const snap = await readSnapshot();
            if (snap) {
              useNet.getState().reportFailure();
              set({
                session: null,
                ready: true,
                profile: snap.profile,
                stores: snap.stores,
                activeStoreId: snap.activeStoreId,
                accountLoaded: true,
                accountError: null,
                fromCache: true,
              });
              return;
            }
          }
          set({ session: null, ready: true });
        })
        .catch(() => set({ ready: true }));

      const { data } = supabase.auth.onAuthStateChange((event, session) => {
        set({ session });
        if (event === 'SIGNED_OUT') {
          get().reset();
          return;
        }
        if (get().recovering) return;
        const cached = get().fromCache;
        if (event === 'SIGNED_IN' || event === 'INITIAL_SESSION' || (event === 'TOKEN_REFRESHED' && cached)) {
          // do not call Supabase from inside this callback; let it finish first
          setTimeout(() => {
            if (get().session) void get().loadAccount({ force: cached }).catch(() => undefined);
          }, 0);
        }
      });
      return () => data.subscription.unsubscribe();
    },

    loadAccount: (opts = {}) => {
      if (inflight) return inflight;
      const run = async () => {
        const sess = (await supabase.auth.getSession()).data.session;
        if (!sess) return;
        const uid = sess.user.id;
        const cur = get();
        if (!opts.force && cur.accountLoaded && cur.profile?.id === uid && !cur.fromCache) return;

        set({ accountError: null });
        try {
          const res = await supabase.from('axon_profiles').select('*').eq('id', uid).maybeSingle();
          if (res.error) throw res.error;
          const profile = res.data as Profile | null;
          if (!profile) {
            set({ profile: null, accountLoaded: true, fromCache: false });
            return;
          }
          const expect = get().pendingRole;
          if (expect && profile.role !== expect) {
            await supabase.auth.signOut();
            throw new RoleMismatch(
              profile.role === 'owner'
                ? 'This email belongs to a store owner account. Go back and choose "I run a business".'
                : 'This email belongs to a customer account. Go back and choose "I am a customer".',
            );
          }
          const [stores, saved] = await Promise.all([
            profile.role === 'owner' ? listMyStores(uid) : Promise.resolve([] as Store[]),
            AsyncStorage.getItem(activeKey(uid)).catch(() => null),
          ]);
          const active = stores.find((s) => s.id === saved)?.id ?? stores[0]?.id ?? null;
          useNet.getState().reportSuccess();
          set({
            profile,
            stores,
            activeStoreId: active,
            accountLoaded: true,
            accountError: null,
            fromCache: false,
          });
          keepSnapshot();
          if (profile.role === 'customer') void useWishlist.getState().load();
        } catch (e) {
          if (e instanceof RoleMismatch) throw e;
          if (isNetworkError(e)) {
            useNet.getState().reportFailure();
            const snap = await readSnapshot();
            if (snap && snap.uid === uid) {
              set({
                profile: snap.profile,
                stores: snap.stores,
                activeStoreId: snap.activeStoreId,
                accountLoaded: true,
                accountError: null,
                fromCache: true,
              });
              return;
            }
          }
          set({ accountError: friendly(e) });
          throw e;
        }
      };
      inflight = run().finally(() => {
        inflight = null;
      });
      return inflight;
    },

    signIn: async (role, email, password) => {
      set({ pendingRole: role });
      try {
        await passwordLogin(email, password);
        await get().loadAccount({ force: true });
      } finally {
        set({ pendingRole: null });
      }
    },

    signOut: async (scope = 'global') => {
      try {
        await supabase.auth.signOut({ scope });
      } finally {
        get().reset();
      }
    },

    reset: () => {
      const uid = get().profile?.id;
      useCart.getState().clear();
      useWishlist.getState().clear();
      void AsyncStorage.removeItem(SNAPSHOT_KEY).catch(() => undefined);
      if (uid) void clearCache(uid);
      set({
        session: null,
        accountLoaded: false,
        accountError: null,
        profile: null,
        stores: [],
        activeStoreId: null,
        fromCache: false,
      });
    },

    setActiveStore: (id) => {
      set({ activeStoreId: id });
      const uid = get().profile?.id;
      if (uid) void AsyncStorage.setItem(activeKey(uid), id).catch(() => undefined);
      keepSnapshot();
    },

    upsertStore: (s) => {
      const list = get().stores;
      const exists = list.some((x) => x.id === s.id);
      set({ stores: exists ? list.map((x) => (x.id === s.id ? s : x)) : [...list, s] });
      keepSnapshot();
    },

    removeStore: (id) => {
      const rest = get().stores.filter((x) => x.id !== id);
      const active = get().activeStoreId === id ? (rest[0]?.id ?? null) : get().activeStoreId;
      set({ stores: rest, activeStoreId: active });
      keepSnapshot();
    },

    patchProfile: (p) => {
      const cur = get().profile;
      if (cur) set({ profile: { ...cur, ...p } });
      keepSnapshot();
    },

    setRecovering: (on) => set({ recovering: on }),
  };
});

/** The business the owner is currently working in. */
export function useActiveStore(): Store | null {
  return useSession((s) => s.stores.find((x) => x.id === s.activeStoreId) ?? null);
}
