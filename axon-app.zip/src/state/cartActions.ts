import { Alert } from 'react-native';
import { toast } from '../lib/toast';
import type { Product } from '../types';
import { useCart, type CartStore } from './cart';

/**
 * Put an item in the cart. A cart holds items from one store, so when the
 * shopper picks from a different store they are asked whether to start over.
 * `onAdded` runs once the item is really in the cart.
 */
export function addToCart(store: CartStore, p: Product, qty = 1, onAdded?: () => void): void {
  const cart = useCart.getState();
  const res = cart.add(store, p, qty);
  if (res === 'added') {
    toast.success(`${p.name} added to your cart.`);
    onAdded?.();
    return;
  }
  if (res === 'sold-out') {
    toast.error(`${p.name} is sold out.`);
    return;
  }
  const current = cart.store?.name ?? 'another store';
  Alert.alert('Start a new cart?', `Your cart already has items from ${current}. One cart holds items from one store at a time.`, [
    { text: 'Keep my cart', style: 'cancel' },
    {
      text: 'Start new cart',
      onPress: () => {
        useCart.getState().startNew(store, p, qty);
        toast.success(`${p.name} added to your new cart.`);
        onAdded?.();
      },
    },
  ]);
}
