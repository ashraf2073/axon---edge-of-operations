import { IMAGE_BUCKET } from '../config';
import { AppError, check, friendly } from '../lib/errors';
import { supabase } from '../lib/supabase';
import type { Feedback, FeedbackPriority, FeedbackType, Profile, Role } from '../types';

export async function signUp(input: {
  email: string;
  password: string;
  fullName: string;
  phone: string;
  role: Role;
}): Promise<{ needsConfirmation: boolean }> {
  const { data, error } = await supabase.auth.signUp({
    email: input.email.trim().toLowerCase(),
    password: input.password,
    options: {
      data: { axon_role: input.role, full_name: input.fullName.trim(), phone: input.phone.trim() },
    },
  });
  if (error) throw new AppError(friendly(error));
  // When email confirmation is on, an existing email comes back with no identities.
  if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
    throw new AppError('An account with this email already exists. Try logging in instead.');
  }
  return { needsConfirmation: !data.session };
}

export async function passwordLogin(email: string, password: string): Promise<void> {
  const { error } = await supabase.auth.signInWithPassword({
    email: email.trim().toLowerCase(),
    password,
  });
  if (error) throw new AppError(friendly(error));
}

/** Only name, phone and date format can be changed; role and email are locked by the database. */
export async function updateProfile(
  userId: string,
  patch: Partial<Pick<Profile, 'full_name' | 'phone' | 'date_format'>>,
): Promise<void> {
  const res = await supabase.from('axon_profiles').update(patch).eq('id', userId);
  check({ data: true, error: res.error });
}

export async function changePassword(newPassword: string): Promise<void> {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw new AppError(friendly(error));
}

// ---- forgotten password (code sent by email) --------------------------

/**
 * Sends a short code to the email. The answer is the same whether or not the email has an
 * account, so the screen never reveals who is registered.
 */
export async function requestResetCode(email: string): Promise<void> {
  const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase());
  if (error) throw new AppError(friendly(error));
}

/**
 * Checks the code from the email, sets the new password, then signs the person out on every
 * device so they log in again with the new one.
 */
export async function resetWithCode(email: string, code: string, newPassword: string): Promise<void> {
  const verified = await supabase.auth.verifyOtp({
    email: email.trim().toLowerCase(),
    token: code.replace(/\s+/g, ''),
    type: 'recovery',
  });
  if (verified.error) throw new AppError(friendly(verified.error));
  const updated = await supabase.auth.updateUser({ password: newPassword });
  if (updated.error) {
    await supabase.auth.signOut({ scope: 'local' }).catch(() => undefined);
    throw new AppError(friendly(updated.error));
  }
  // Sign out on every device. If that cannot be reached, at least end it on this phone.
  const out = await supabase.auth.signOut().catch((e) => ({ error: e }));
  if (out.error) await supabase.auth.signOut({ scope: 'local' }).catch(() => undefined);
}

// ---- feedback ---------------------------------------------------------

export async function submitFeedback(input: {
  type: FeedbackType;
  priority: FeedbackPriority;
  message: string;
  includeContact: boolean;
  storeId?: string | null;
}): Promise<void> {
  const res = await supabase.rpc('axon_submit_feedback', {
    p_type: input.type,
    p_priority: input.priority,
    p_message: input.message.trim(),
    p_include_contact: input.includeContact,
    p_store: input.storeId ?? null,
  });
  check(res);
}

export async function myFeedback(): Promise<Feedback[]> {
  const res = await supabase
    .from('axon_feedback')
    .select('id,type,priority,message,status,role,store_name,created_at')
    .order('created_at', { ascending: false })
    .limit(50);
  return (check(res) ?? []) as Feedback[];
}

// ---- admin ------------------------------------------------------------

export type AdminAction =
  | 'login'
  | 'stats'
  | 'list_feedback'
  | 'set_status'
  | 'delete_feedback'
  | 'change_code';

const ADMIN_ERRORS: Record<string, string> = {
  bad_code: 'Wrong passcode.',
  locked: 'Too many wrong attempts. Try again in 15 minutes.',
  weak_code: 'The new passcode must be 8 to 64 characters.',
  not_found: 'That item no longer exists.',
  bad_request: 'The request was not valid.',
  unknown_action: 'The app and the database are out of sync. Run supabase/schema.sql again.',
};

/** Every admin call is checked again on the server using the passcode. */
export async function adminCall<T = unknown>(
  code: string,
  action: AdminAction,
  args: Record<string, unknown> = {},
): Promise<T> {
  const res = await supabase.rpc('axon_admin', { p_code: code, p_action: action, p_args: args });
  const out = check(res) as { ok: boolean; error?: string; data?: T } | null;
  if (!out || !out.ok) {
    throw new AppError(ADMIN_ERRORS[out?.error ?? ''] ?? 'The admin request failed.');
  }
  return out.data as T;
}

// ---- delete account ---------------------------------------------------

/** Removes the pictures of every store the owner has, then the account itself. */
export async function deleteMyAccount(storeIds: string[]): Promise<void> {
  for (const id of storeIds) {
    try {
      const listed = await supabase.storage.from(IMAGE_BUCKET).list(id, { limit: 1000 });
      const files = (listed.data ?? []).map((f) => `${id}/${f.name}`);
      if (files.length) await supabase.storage.from(IMAGE_BUCKET).remove(files);
    } catch {
      // continue: an orphaned picture is harmless
    }
  }
  const res = await supabase.rpc('axon_delete_account');
  check(res);
}
