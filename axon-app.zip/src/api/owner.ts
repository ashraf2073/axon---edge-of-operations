import { AppError, check } from '../lib/errors';
import { localTimeZone } from '../lib/format';
import { deleteImageByUrl } from '../lib/images';
import { supabase } from '../lib/supabase';
import { IMAGE_BUCKET } from '../config';
import { useBiz } from '../state/biz';
import type {
  Analytics,
  Currency,
  Expense,
  Order,
  OrderStatus,
  Product,
  ProductKind,
  Sale,
  Store,
  StoreKind,
} from '../types';

// ---- businesses -------------------------------------------------------

export interface StoreInput {
  name: string;
  kind: StoreKind;
  description: string;
  location: string;
  phone: string;
  currency: Currency;
  payment_info: string;
  logo_url?: string | null;
}

export async function listMyStores(ownerId: string): Promise<Store[]> {
  const res = await supabase
    .from('axon_stores')
    .select('*')
    .eq('owner_id', ownerId)
    .order('created_at', { ascending: true });
  return (check(res) ?? []) as Store[];
}

export async function createStore(ownerId: string, input: StoreInput): Promise<Store> {
  const res = await supabase
    .from('axon_stores')
    .insert({ owner_id: ownerId, ...input })
    .select()
    .single();
  return check(res) as Store;
}

export async function updateStore(id: string, patch: Partial<StoreInput>): Promise<Store> {
  const res = await supabase.from('axon_stores').update(patch).eq('id', id).select().single();
  return check(res) as Store;
}

export async function deleteStore(store: Store): Promise<void> {
  try {
    const listed = await supabase.storage.from(IMAGE_BUCKET).list(store.id, { limit: 1000 });
    const files = (listed.data ?? []).map((f) => `${store.id}/${f.name}`);
    if (files.length) await supabase.storage.from(IMAGE_BUCKET).remove(files);
  } catch {
    // an orphaned picture is harmless
  }
  const res = await supabase.from('axon_stores').delete().eq('id', store.id);
  check({ data: true, error: res.error });
}

// ---- items ------------------------------------------------------------

export interface ProductInput {
  name: string;
  category: string;
  kind: ProductKind;
  description: string;
  unit: string;
  price: number;
  cost: number;
  stock: number;
  track_stock: boolean;
  low_alert: number;
  image_url: string | null;
  active: boolean;
}

export async function listProducts(storeId: string): Promise<Product[]> {
  const res = await supabase
    .from('axon_products')
    .select('*')
    .eq('store_id', storeId)
    .order('created_at', { ascending: false })
    .limit(1000);
  return (check(res) ?? []) as Product[];
}

export async function saveProduct(storeId: string, input: ProductInput, id?: string): Promise<Product> {
  if (id) {
    const res = await supabase.from('axon_products').update(input).eq('id', id).select().single();
    return check(res) as Product;
  }
  const res = await supabase
    .from('axon_products')
    .insert({ store_id: storeId, ...input })
    .select()
    .single();
  return check(res) as Product;
}

export async function deleteProduct(p: Product): Promise<void> {
  const res = await supabase.from('axon_products').delete().eq('id', p.id);
  check({ data: true, error: res.error });
  await deleteImageByUrl(p.image_url);
}

// ---- sales ------------------------------------------------------------

export async function listSales(storeId: string, limit = 50, offset = 0): Promise<Sale[]> {
  const res = await supabase
    .from('axon_sales')
    .select('*')
    .eq('store_id', storeId)
    .order('sold_at', { ascending: false })
    .range(offset, offset + limit - 1);
  return (check(res) ?? []) as Sale[];
}

export async function lastSaleAt(storeId: string): Promise<string | null> {
  const res = await supabase
    .from('axon_sales')
    .select('sold_at')
    .eq('store_id', storeId)
    .order('sold_at', { ascending: false })
    .limit(1);
  const rows = (check(res) ?? []) as { sold_at: string }[];
  return rows[0]?.sold_at ?? null;
}

export async function recordSale(input: {
  storeId: string;
  productId: string;
  qty: number;
  price: number | null;
  customer: string;
  note: string;
  soldAt: Date | null;
  /** Makes the sale safe to send twice: the database counts one id only once. */
  clientId?: string | null;
}): Promise<Sale> {
  const res = await supabase.rpc('axon_record_sale', {
    p_store: input.storeId,
    p_product: input.productId,
    p_qty: input.qty,
    p_price: input.price,
    p_customer: input.customer,
    p_note: input.note,
    p_sold_at: input.soldAt ? input.soldAt.toISOString() : null,
    p_client: input.clientId ?? null,
  });
  return check(res) as Sale;
}

export async function deleteSale(id: string): Promise<void> {
  const res = await supabase.rpc('axon_delete_sale', { p_sale: id });
  check(res);
}

// ---- expenses ---------------------------------------------------------

export async function listExpenses(storeId: string, limit = 100, offset = 0): Promise<Expense[]> {
  const res = await supabase
    .from('axon_expenses')
    .select('*')
    .eq('store_id', storeId)
    .order('spent_on', { ascending: false })
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);
  return (check(res) ?? []) as Expense[];
}

export async function addExpense(input: {
  storeId: string;
  category: string;
  description: string;
  payee: string;
  amount: number;
  spentOn: string;
  /** Makes the expense safe to send twice: the database counts one id only once. */
  clientId?: string | null;
}): Promise<void> {
  const res = await supabase.rpc('axon_add_expense', {
    p_store: input.storeId,
    p_client: input.clientId ?? null,
    p_category: input.category,
    p_description: input.description,
    p_payee: input.payee,
    p_amount: input.amount,
    p_spent_on: input.spentOn,
  });
  check(res);
}

export async function deleteExpense(id: string): Promise<void> {
  const res = await supabase.from('axon_expenses').delete().eq('id', id);
  check({ data: true, error: res.error });
}

// ---- customer orders --------------------------------------------------

export async function listStoreOrders(storeId: string): Promise<Order[]> {
  const res = await supabase
    .from('axon_orders')
    .select('*, items:axon_order_items(*)')
    .eq('store_id', storeId)
    .order('created_at', { ascending: false })
    .limit(200);
  return (check(res) ?? []) as Order[];
}

export async function setOrderStatus(id: string, status: Exclude<OrderStatus, 'placed'>): Promise<void> {
  const res = await supabase.rpc('axon_set_order_status', { p_order: id, p_status: status });
  check(res);
}

/** The store confirms the payment arrived. The order moves from new to being prepared. */
export async function approvePayment(id: string): Promise<void> {
  const res = await supabase.rpc('axon_approve_payment', { p_order: id });
  check(res);
}

// ---- analytics --------------------------------------------------------

/**
 * Several parts of one screen ask for the same numbers at the same moment (the top pill,
 * the page itself, the costs card). Asking identical questions at the same time shares one
 * request. The shared answer is only used while the business numbers are unchanged, so a
 * sale or an expense always triggers a fresh request.
 */
const analyticsInflight = new Map<string, Promise<Analytics>>();

async function fetchAnalytics(storeId: string, from: string | null, to: string | null): Promise<Analytics> {
  const res = await supabase.rpc('axon_analytics', {
    p_store: storeId,
    p_from: from,
    p_to: to,
    p_tz: localTimeZone(),
  });
  const data = check(res) as Analytics | null;
  if (!data) throw new AppError('Could not load your numbers. Pull down to try again.');
  return data;
}

export function getAnalytics(
  storeId: string,
  from: string | null = null,
  to: string | null = null,
): Promise<Analytics> {
  const key = `${useBiz.getState().version}|${storeId}|${from ?? ''}|${to ?? ''}`;
  const running = analyticsInflight.get(key);
  if (running) return running;
  const request = fetchAnalytics(storeId, from, to).finally(() => {
    analyticsInflight.delete(key);
  });
  analyticsInflight.set(key, request);
  return request;
}
