import { check } from '../lib/errors';
import { supabase } from '../lib/supabase';
import type { Order, PayMethod, Product, Store, StoreWithCount } from '../types';

export type ProductWithStore = Product & {
  store: Pick<Store, 'id' | 'name' | 'currency' | 'phone' | 'payment_info' | 'logo_url'> | null;
};

const STORE_FIELDS = 'id,name,currency,phone,payment_info,logo_url';

/** Characters that would break a PostgREST filter are removed from what the shopper types. */
function cleanQuery(q: string): string {
  return q.replace(/[,()%*\\]/g, ' ').trim();
}

export async function searchStores(q: string): Promise<StoreWithCount[]> {
  let query = supabase
    .from('axon_stores')
    .select('*, products:axon_products(count)')
    .order('name', { ascending: true })
    .limit(100);
  const c = cleanQuery(q);
  if (c) {
    query = query.or(`name.ilike.%${c}%,location.ilike.%${c}%,description.ilike.%${c}%,code.ilike.${c}`);
  }
  return (check(await query) ?? []) as StoreWithCount[];
}

/** Items from every store, newest first, optionally filtered by what the shopper typed. */
export async function searchProducts(q: string): Promise<ProductWithStore[]> {
  let query = supabase
    .from('axon_products')
    .select(`*, store:axon_stores(${STORE_FIELDS})`)
    .eq('active', true)
    .order('created_at', { ascending: false })
    .limit(60);
  const c = cleanQuery(q);
  if (c) query = query.or(`name.ilike.%${c}%,category.ilike.%${c}%,description.ilike.%${c}%`);
  return (check(await query) ?? []) as ProductWithStore[];
}

export async function getStore(id: string): Promise<Store> {
  const res = await supabase.from('axon_stores').select('*').eq('id', id).single();
  return check(res) as Store;
}

export async function listStoreProducts(storeId: string): Promise<Product[]> {
  const res = await supabase
    .from('axon_products')
    .select('*')
    .eq('store_id', storeId)
    .eq('active', true)
    .order('name', { ascending: true })
    .limit(1000);
  return (check(res) ?? []) as Product[];
}

export async function getProduct(id: string): Promise<ProductWithStore> {
  const res = await supabase
    .from('axon_products')
    .select(`*, store:axon_stores(${STORE_FIELDS})`)
    .eq('id', id)
    .single();
  return check(res) as ProductWithStore;
}

// ---- wishlist ---------------------------------------------------------

export async function wishlistIds(): Promise<string[]> {
  const res = await supabase.from('axon_wishlists').select('product_id');
  return ((check(res) ?? []) as { product_id: string }[]).map((r) => r.product_id);
}

export async function listWishlist(): Promise<ProductWithStore[]> {
  const res = await supabase
    .from('axon_wishlists')
    .select(`created_at, product:axon_products(*, store:axon_stores(${STORE_FIELDS}))`)
    .order('created_at', { ascending: false });
  const rows = (check(res) ?? []) as unknown as { product: ProductWithStore | null }[];
  return rows.map((r) => r.product).filter((p): p is ProductWithStore => !!p && p.active);
}

export async function setWished(userId: string, productId: string, wished: boolean): Promise<void> {
  if (wished) {
    const res = await supabase
      .from('axon_wishlists')
      .upsert({ user_id: userId, product_id: productId }, { onConflict: 'user_id,product_id' });
    check({ data: true, error: res.error });
  } else {
    const res = await supabase
      .from('axon_wishlists')
      .delete()
      .eq('user_id', userId)
      .eq('product_id', productId);
    check({ data: true, error: res.error });
  }
}

// ---- orders -----------------------------------------------------------

export async function placeOrder(input: {
  storeId: string;
  items: { productId: string; qty: number }[];
  payMethod: PayMethod;
  name: string;
  phone: string;
  notes: string;
}): Promise<Order> {
  const res = await supabase.rpc('axon_place_order', {
    p_store: input.storeId,
    p_items: input.items.map((i) => ({ product_id: i.productId, qty: i.qty })),
    p_pay_method: input.payMethod,
    p_name: input.name,
    p_phone: input.phone,
    p_notes: input.notes,
  });
  return check(res) as Order;
}

export async function listMyOrders(userId: string): Promise<Order[]> {
  const res = await supabase
    .from('axon_orders')
    .select(`*, items:axon_order_items(*), store:axon_stores(${STORE_FIELDS})`)
    .eq('customer_id', userId)
    .order('created_at', { ascending: false })
    .limit(100);
  return (check(res) ?? []) as Order[];
}

export async function cancelMyOrder(id: string): Promise<void> {
  const res = await supabase.rpc('axon_set_order_status', { p_order: id, p_status: 'cancelled' });
  check(res);
}
