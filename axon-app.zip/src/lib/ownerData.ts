/**
 * Everything the owner screens read or save goes through here.
 *
 * - Reads ask the cloud. If the connection is down they fall back to the last copy kept on the
 *   phone, so the shop is still visible without signal.
 * - Sales and expenses saved without signal wait in the outbox. This file lays them over what
 *   the screens show (stock goes down, totals go up, rows appear marked "Waiting to send"), so
 *   the owner sees their work at once. The cloud numbers replace them after they are sent.
 * - Saving never loses work: if the cloud cannot be reached, the item goes to the outbox.
 */
import * as remote from '../api/owner';
import { AppError, NO_INTERNET, isNetworkError } from './errors';
import { PERIODS, periodRange, toDateKey } from './format';
import { newId } from './ids';
import { readCache, writeCache } from './cache';
import { useBiz } from '../state/biz';
import { useNet } from '../state/net';
import { pendingFor, useOutbox, type OutboxItem } from '../state/outbox';
import { useSession } from '../state/session';
import type { Analytics, Expense, Order, Product, Sale } from '../types';

const round2 = (n: number) => Math.round(n * 100) / 100;
const round3 = (n: number) => Math.round(n * 1000) / 1000;

const uid = () => useSession.getState().profile?.id ?? null;

async function pending(storeId: string): Promise<OutboxItem[]> {
  await useOutbox.getState().load();
  return pendingFor(useOutbox.getState().items, uid() ?? undefined, storeId);
}

/** Ask the cloud; on a connection problem use the saved copy. */
async function read<T>(key: string, fetcher: () => Promise<T>): Promise<T> {
  const me = uid();
  const fallback = async (e: unknown): Promise<T> => {
    const saved = me ? await readCache<T>(me, key) : null;
    if (saved) return saved.data;
    throw e;
  };
  if (!useNet.getState().connected) return fallback(new AppError(NO_INTERNET));
  try {
    const data = await fetcher();
    useNet.getState().reportSuccess();
    if (me) void writeCache(me, key, data);
    return data;
  } catch (e) {
    if (isNetworkError(e)) {
      useNet.getState().reportFailure();
      return fallback(e);
    }
    throw e;
  }
}

// ---- reads, with waiting items laid over them ----------------------------

export async function listProducts(storeId: string): Promise<Product[]> {
  const rows = await read(`products.${storeId}`, () => remote.listProducts(storeId));
  const used = new Map<string, number>();
  (await pending(storeId)).forEach((i) => {
    if (i.kind === 'sale') used.set(i.sale.productId, (used.get(i.sale.productId) ?? 0) + i.sale.qty);
  });
  if (used.size === 0) return rows;
  return rows.map((p) =>
    p.track_stock && used.has(p.id) ? { ...p, stock: Math.max(0, round3(Number(p.stock) - used.get(p.id)!)) } : p,
  );
}

export async function listSales(storeId: string, limit = 50): Promise<Sale[]> {
  const rows = await read(`sales.${storeId}`, () => remote.listSales(storeId, limit, 0));
  const waiting: Sale[] = (await pending(storeId)).flatMap((i) =>
    i.kind === 'sale'
      ? [
          {
            id: `queued-${i.id}`,
            store_id: i.storeId,
            product_id: i.sale.productId,
            order_id: null,
            product_name: i.sale.productName,
            unit: i.sale.unit,
            txn_id: 'Waiting to send',
            qty: i.sale.qty,
            unit_price: i.sale.price,
            total: round2(i.sale.qty * i.sale.price),
            customer: i.sale.customer,
            note: i.sale.note,
            sold_at: i.sale.soldAt,
            pending: true,
          },
        ]
      : [],
  );
  const all = [...waiting, ...rows].sort((a, b) => Date.parse(b.sold_at) - Date.parse(a.sold_at));
  return all.slice(0, limit + waiting.length);
}

export async function lastSaleAt(storeId: string): Promise<string | null> {
  const server = await read(`lastsale.${storeId}`, () => remote.lastSaleAt(storeId));
  const times = (await pending(storeId)).flatMap((i) => (i.kind === 'sale' ? [i.sale.soldAt] : []));
  return [server, ...times].filter((x): x is string => !!x).sort().pop() ?? null;
}

export async function listExpenses(storeId: string, limit = 100): Promise<Expense[]> {
  const rows = await read(`expenses.${storeId}`, () => remote.listExpenses(storeId, limit, 0));
  const waiting: Expense[] = (await pending(storeId)).flatMap((i) =>
    i.kind === 'expense'
      ? [
          {
            id: `queued-${i.id}`,
            store_id: i.storeId,
            category: i.expense.category,
            description: i.expense.description,
            payee: i.expense.payee,
            amount: i.expense.amount,
            spent_on: i.expense.spentOn,
            created_at: i.createdAt,
            pending: true,
          },
        ]
      : [],
  );
  const all = [...waiting, ...rows].sort(
    (a, b) => b.spent_on.localeCompare(a.spent_on) || b.created_at.localeCompare(a.created_at),
  );
  return all.slice(0, limit + waiting.length);
}

export function listStoreOrders(storeId: string): Promise<Order[]> {
  return read(`orders.${storeId}`, () => remote.listStoreOrders(storeId));
}

function inSalesRange(iso: string, from: string | null, to: string | null): boolean {
  const t = Date.parse(iso);
  return (!from || t >= Date.parse(from)) && (!to || t < Date.parse(to));
}

function inExpenseRange(day: string, from: string | null, to: string | null): boolean {
  return (!from || day >= toDateKey(new Date(from))) && (!to || day < toDateKey(new Date(to)));
}

/** Adds what is waiting to be sent to the numbers the cloud gave, so the owner sees it at once. */
export function applyWaiting(a: Analytics, items: OutboxItem[], from: string | null, to: string | null): Analytics {
  const sales = items.flatMap((i) => (i.kind === 'sale' && inSalesRange(i.sale.soldAt, from, to) ? [i.sale] : []));
  const exps = items.flatMap((i) => (i.kind === 'expense' && inExpenseRange(i.expense.spentOn, from, to) ? [i.expense] : []));
  const monthSales = items.flatMap((i) => (i.kind === 'sale' ? [i.sale] : []));
  const monthExps = items.flatMap((i) => (i.kind === 'expense' ? [i.expense] : []));
  if (monthSales.length === 0 && monthExps.length === 0) return a;

  const top = new Map(a.top_products.map((t) => [t.name, { ...t, units: Number(t.units), revenue: Number(t.revenue) }]));
  sales.forEach((s) => {
    const cur = top.get(s.productName) ?? { name: s.productName, units: 0, revenue: 0 };
    cur.units += s.qty;
    cur.revenue = round2(cur.revenue + s.qty * s.price);
    top.set(s.productName, cur);
  });
  const cats = new Map(a.expense_breakdown.map((c) => [c.category, Number(c.amount)]));
  exps.forEach((e) => cats.set(e.category, round2((cats.get(e.category) ?? 0) + e.amount)));

  return {
    ...a,
    revenue: round2(Number(a.revenue) + sales.reduce((t, s) => t + s.qty * s.price, 0)),
    expenses: round2(Number(a.expenses) + exps.reduce((t, e) => t + e.amount, 0)),
    units: round3(Number(a.units) + sales.reduce((t, s) => t + s.qty, 0)),
    sales_count: Number(a.sales_count) + sales.length,
    top_products: [...top.values()].sort((x, y) => y.revenue - x.revenue).slice(0, 5),
    expense_breakdown: [...cats.entries()].map(([category, amount]) => ({ category, amount })).sort((x, y) => y.amount - x.amount),
    monthly: a.monthly.map((m) => ({
      ...m,
      revenue: round2(
        Number(m.revenue) +
          monthSales.filter((s) => toDateKey(new Date(s.soldAt)).slice(0, 7) === m.month).reduce((t, s) => t + s.qty * s.price, 0),
      ),
      expenses: round2(
        Number(m.expenses) + monthExps.filter((e) => e.spentOn.slice(0, 7) === m.month).reduce((t, e) => t + e.amount, 0),
      ),
    })),
  };
}

export async function getAnalytics(
  storeId: string,
  from: string | null = null,
  to: string | null = null,
): Promise<Analytics> {
  const data = await read(`analytics.${storeId}.${from ?? ''}.${to ?? ''}`, () => remote.getAnalytics(storeId, from, to));
  return applyWaiting(data, await pending(storeId), from, to);
}

/**
 * Loads the main screens' data once in the background while there is a connection, so the saved
 * copy is complete and the shop opens fully even if the next launch has no signal.
 */
export async function warmCache(storeId: string): Promise<void> {
  if (!useNet.getState().connected) return;
  await Promise.allSettled([
    listProducts(storeId),
    listSales(storeId, 50),
    listExpenses(storeId, 100),
    listStoreOrders(storeId),
    lastSaleAt(storeId),
    ...PERIODS.map((p) => {
      const r = periodRange(p.key);
      return getAnalytics(storeId, r.from, r.to);
    }),
  ]);
}

// ---- saving ---------------------------------------------------------------

export interface SaleInput {
  storeId: string;
  product: Pick<Product, 'id' | 'name' | 'unit'>;
  qty: number;
  price: number;
  customer: string;
  note: string;
  /** null means "now" */
  soldAt: Date | null;
}

export type SaveResult = { queued: false; txn: string | null } | { queued: true };

async function queue(item: OutboxItem): Promise<SaveResult> {
  try {
    await useOutbox.getState().add(item);
  } catch {
    throw new AppError('Could not save this on your phone. Free some space and try again.');
  }
  useBiz.getState().bump();
  return { queued: true };
}

/** Records a sale now if the cloud answers, otherwise saves it on the phone to send later. */
export async function submitSale(input: SaleInput): Promise<SaveResult> {
  const me = uid();
  if (!me) throw new AppError('Sign in first');
  const id = newId();
  const item: OutboxItem = {
    id,
    ownerId: me,
    storeId: input.storeId,
    createdAt: new Date().toISOString(),
    status: 'waiting',
    kind: 'sale',
    sale: {
      productId: input.product.id,
      productName: input.product.name,
      unit: input.product.unit,
      qty: input.qty,
      price: input.price,
      customer: input.customer,
      note: input.note,
      soldAt: (input.soldAt ?? new Date()).toISOString(),
    },
  };
  if (!useNet.getState().connected) return queue(item);
  try {
    const sale = await remote.recordSale({
      storeId: input.storeId,
      productId: input.product.id,
      qty: input.qty,
      price: input.price,
      customer: input.customer,
      note: input.note,
      soldAt: input.soldAt,
      clientId: id,
    });
    useNet.getState().reportSuccess();
    useBiz.getState().bump();
    return { queued: false, txn: sale.txn_id };
  } catch (e) {
    // The id makes it safe to send again even if the first try reached the cloud.
    if (isNetworkError(e)) {
      useNet.getState().reportFailure();
      return queue(item);
    }
    throw e;
  }
}

export interface ExpenseInput {
  storeId: string;
  category: string;
  description: string;
  payee: string;
  amount: number;
  spentOn: string;
}

/** Saves an expense now if the cloud answers, otherwise on the phone to send later. */
export async function submitExpense(input: ExpenseInput): Promise<SaveResult> {
  const me = uid();
  if (!me) throw new AppError('Sign in first');
  const id = newId();
  const item: OutboxItem = {
    id,
    ownerId: me,
    storeId: input.storeId,
    createdAt: new Date().toISOString(),
    status: 'waiting',
    kind: 'expense',
    expense: {
      category: input.category,
      description: input.description,
      payee: input.payee,
      amount: input.amount,
      spentOn: input.spentOn,
    },
  };
  if (!useNet.getState().connected) return queue(item);
  try {
    await remote.addExpense({ ...input, clientId: id });
    useNet.getState().reportSuccess();
    useBiz.getState().bump();
    return { queued: false, txn: null };
  } catch (e) {
    if (isNetworkError(e)) {
      useNet.getState().reportFailure();
      return queue(item);
    }
    throw e;
  }
}

/** Removes something saved on the phone that has not been sent (the owner changed their mind). */
export async function discardQueued(rowId: string): Promise<void> {
  const id = rowId.startsWith('queued-') ? rowId.slice('queued-'.length) : rowId;
  await useOutbox.getState().remove(id);
  useBiz.getState().bump();
}

export const isQueuedRow = (id: string) => id.startsWith('queued-');
