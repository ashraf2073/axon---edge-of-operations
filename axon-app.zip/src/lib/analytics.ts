import type { Analytics, Currency } from '../types';
import { expenseLabel } from '../theme';
import { money } from './format';

export interface Totals {
  revenue: number;
  expenses: number;
  profit: number;
  margin: number;
}

/** profit = revenue - expenses; margin = profit as a percentage of revenue. */
export function totals(a: Pick<Analytics, 'revenue' | 'expenses'>): Totals {
  const revenue = Number(a.revenue) || 0;
  const expenses = Number(a.expenses) || 0;
  const profit = revenue - expenses;
  const margin = revenue > 0 ? (profit / revenue) * 100 : 0;
  return { revenue, expenses, profit, margin };
}

export type Tone = 'bad' | 'warn' | 'good' | 'info';

export interface Advice {
  tone: Tone;
  title: string;
  body: string;
}

/** The "AXON Analysis" box on the Profit and Loss page. */
export function analysisAdvice(a: Analytics, cur: Currency): Advice | null {
  const { revenue, expenses, profit, margin } = totals(a);
  if (!revenue && !expenses) return null;

  if (profit < 0) {
    const gap = Math.abs(profit);
    const uncovered = expenses > 0 ? Math.round((gap / expenses) * 100) : 0;
    const top = a.expense_breakdown[0];
    const topLine =
      top && expenses > 0
        ? ` Your biggest cost is ${expenseLabel(top.category)}, at ${Math.round((top.amount / expenses) * 100)}% of your spending.`
        : '';
    return {
      tone: 'bad',
      title: 'You are running at a loss',
      body:
        `Your business is currently at a ${money(gap, cur)} loss. ${uncovered}% of your spending is not covered by sales.${topLine} ` +
        'Immediate actions to consider: review your top expense category, look at whether any fixed costs can be renegotiated, ' +
        'and check that your selling prices cover your cost price plus overhead. Focus on your highest-selling products to drive more volume.',
    };
  }
  const m = margin.toFixed(1);
  if (margin < 10) {
    return {
      tone: 'warn',
      title: 'Thin profit margin',
      body:
        `Profit margin is very thin at ${m}%. You are breaking even but have little safety net. ` +
        'Look at which products have the best margin and prioritise those. Consider small price adjustments: ' +
        'even a 5 to 10% price increase on fast-moving items can significantly improve margins.',
    };
  }
  if (margin < 25) {
    return {
      tone: 'good',
      title: 'Decent profit',
      body:
        `Decent profit of ${money(profit, cur)} at ${m}% margin. You are profitable, so now focus on scaling. ` +
        `Consider reinvesting ${money(profit * 0.25, cur)} into expanding your product range or marketing to new customers.`,
    };
  }
  return {
    tone: 'good',
    title: 'Excellent performance',
    body:
      `${money(profit, cur)} profit at a strong ${m}% margin. Your business is healthy. ` +
      `Consider reinvesting ${money(profit * 0.3, cur)} into growth, building an emergency fund for slow months, or expanding to a second product line.`,
  };
}

/** Short live tips for the Suggestions page, based on the business's own numbers. */
export function smartTips(a: Analytics | null, cur: Currency, lastSaleAt: string | null): Advice[] {
  if (!a) return [];
  const tips: Advice[] = [];
  const { revenue, profit, margin } = totals(a);

  if (a.product_count === 0) {
    tips.push({
      tone: 'warn',
      title: 'Add your first item',
      body: 'Open Stock and add what your business sells: goods, farm produce, animals or services. Include a price and a stock level.',
    });
  } else if (a.sales_count === 0 && revenue === 0) {
    tips.push({
      tone: 'info',
      title: 'Record your first sale',
      body: 'You have items but no sales yet. Every time a customer buys something, tap Sell on the item.',
    });
  }
  if (a.expenses === 0 && a.product_count > 0) {
    tips.push({
      tone: 'bad',
      title: 'Log your expenses',
      body: 'Add your rent, wages, utilities and stock purchases under Costs. Without them your profit figure is not accurate.',
    });
  }
  if (a.new_orders > 0) {
    tips.push({
      tone: 'warn',
      title: `${a.new_orders} new customer ${a.new_orders === 1 ? 'order is' : 'orders are'} waiting`,
      body: 'Open Sales, then Orders, to accept or complete them. Customers see your update straight away.',
    });
  }
  if (a.low_stock.length > 0) {
    const names = a.low_stock.slice(0, 3).map((p) => p.name).join(', ');
    tips.push({
      tone: 'warn',
      title: 'Low stock alert',
      body: `${names}${a.low_stock.length > 3 ? ' and more are' : a.low_stock.length > 1 ? ' are' : ' is'} at or below the low-stock level. Restock soon to avoid missing sales.`,
    });
  }
  if (profit < 0 && revenue > 0) {
    tips.push({
      tone: 'bad',
      title: 'You are running at a loss',
      body: `Expenses exceed revenue by ${money(Math.abs(profit), cur)}. Review your largest costs and consider adjusting your prices.`,
    });
  } else if (revenue > 0 && margin < 15) {
    tips.push({
      tone: 'warn',
      title: 'Thin profit margin',
      body: `Your margin is ${margin.toFixed(1)}%. Small price adjustments on your best sellers can make a significant difference.`,
    });
  } else if (revenue > 0 && margin >= 25) {
    tips.push({
      tone: 'good',
      title: 'Strong performance',
      body: `${margin.toFixed(1)}% margin. Your business is healthy. Consider reinvesting ${money(profit * 0.3, cur)} to grow further.`,
    });
  }
  if (lastSaleAt && a.sales_count > 0) {
    const days = (Date.now() - new Date(lastSaleAt).getTime()) / 86400000;
    if (days > 7) {
      tips.push({
        tone: 'info',
        title: 'No recent sales recorded',
        body: 'It has been over 7 days since a sale was logged. Keep your records up to date for accurate analysis.',
      });
    }
  }
  return tips;
}

export const GENERAL_TIPS: { title: string; body: string }[] = [
  {
    title: 'Know your stock levels',
    body: 'Always keep your stock updated after every sale. Running out of a popular product means lost revenue you cannot recover.',
  },
  {
    title: 'Price above your costs',
    body: 'Your selling price must cover the cost of the item plus a share of rent, wages, and other overheads, not just the purchase price.',
  },
  {
    title: 'Review your expenses monthly',
    body: 'Go through every expense at the end of each month. Small recurring costs add up. Cut what is not generating value.',
  },
  {
    title: 'Focus on your best sellers',
    body: 'Identify the top 3 products generating the most revenue and make sure they are always in stock and well priced.',
  },
  {
    title: 'Record every sale, no exceptions',
    body: 'Unrecorded sales mean your profit calculation is wrong. Even cash sales must be logged to get an accurate picture.',
  },
  {
    title: 'Reinvest a portion of profit',
    body: 'Aim to reinvest 20 to 30 percent of monthly profit back into stock, marketing, or tools that help you grow faster.',
  },
];

export const SHOPPER_TIPS: { title: string; body: string }[] = [
  {
    title: 'Check the stock before you order',
    body: 'Each item shows how many are left. Order the amount you really need so other customers can buy too.',
  },
  {
    title: 'Confirm the payment details',
    body: 'At checkout the store shows how it wants to be paid. Pay the store directly and keep the message or receipt.',
  },
  {
    title: 'Keep your phone reachable',
    body: 'Stores call or message the number on your order to arrange pickup or delivery.',
  },
  {
    title: 'No hidden fees',
    body: 'The total shown at checkout is the price of the items. AXON adds no extra charges.',
  },
];
