import type { FeedbackPriority, FeedbackStatus, FeedbackType, OrderStatus, PayMethod, ProductKind, StoreKind } from '../types';

export const STORE_KINDS: { key: StoreKind; label: string }[] = [
  { key: 'shop', label: 'Shop' },
  { key: 'farm', label: 'Farm' },
  { key: 'supermarket', label: 'Supermarket' },
  { key: 'company', label: 'Company' },
  { key: 'service', label: 'Service' },
  { key: 'other', label: 'Other' },
];

export function storeKindLabel(k: string): string {
  return STORE_KINDS.find((x) => x.key === k)?.label ?? k;
}

export const PRODUCT_KINDS: { key: ProductKind; label: string; hint: string }[] = [
  { key: 'good', label: 'Goods', hint: 'Things you stock and sell' },
  { key: 'farm', label: 'Farm produce', hint: 'Milk, eggs, maize, vegetables' },
  { key: 'animal', label: 'Animal', hint: 'Cows, goats, chickens' },
  { key: 'service', label: 'Service', hint: 'Work you do for customers' },
];

export function productKindLabel(k: string): string {
  return PRODUCT_KINDS.find((x) => x.key === k)?.label ?? k;
}

export const PAY_METHODS: { key: PayMethod; label: string }[] = [
  { key: 'mpesa', label: 'M-Pesa' },
  { key: 'cash', label: 'Cash' },
  { key: 'bank', label: 'Bank' },
  { key: 'card', label: 'Card' },
  { key: 'airtel', label: 'Airtel Money' },
];

export function payLabel(k: string): string {
  return PAY_METHODS.find((x) => x.key === k)?.label ?? k;
}

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  placed: 'New',
  processing: 'Processing',
  complete: 'Complete',
  cancelled: 'Cancelled',
};

export const FEEDBACK_TYPES: { key: FeedbackType; label: string }[] = [
  { key: 'feature', label: 'Feature idea' },
  { key: 'improvement', label: 'Improvement' },
  { key: 'bug', label: 'Problem' },
  { key: 'praise', label: 'Praise' },
  { key: 'other', label: 'Other' },
];

export const FEEDBACK_PRIORITIES: { key: FeedbackPriority; label: string }[] = [
  { key: 'low', label: 'Low' },
  { key: 'medium', label: 'Medium' },
  { key: 'high', label: 'High' },
];

export const FEEDBACK_STATUSES: { key: FeedbackStatus; label: string }[] = [
  { key: 'new', label: 'New' },
  { key: 'reviewing', label: 'Reviewing' },
  { key: 'planned', label: 'Planned' },
  { key: 'done', label: 'Done' },
  { key: 'dismissed', label: 'Dismissed' },
];

export const SLOGAN = 'edge of operations';

export const ABOUT = {
  name:
    'An axon is the long projection of a nerve cell that carries signals through the body, connecting every part of a living system. ' +
    'AXON does the same for your business: it connects your items, your customers, your expenses and your profit into one clear picture. ' +
    'The gap in the logo, the synapse, stands for the spark of insight between your raw numbers and your next smart decision.',
  slogan:
    '"Edge of operations": AXON sits at the sharp edge where effort becomes money. ' +
    'It is built for the shopkeeper, the farmer and the small business owner who works hard and deserves tools that match their hustle.',
  steps: [
    'Build a profile for your business: shop, farm, company or supermarket.',
    'Add your goods, farm produce, animals or services with pictures, prices and stock levels.',
    'Record every sale. Stock goes down, you get a transaction ID, and revenue adds up.',
    'Log every expense: rent, wages, goods, insurance, taxes, maintenance.',
    'AXON works out the rest. Revenue minus expenses is your real profit, with advice when you are at a loss.',
    'Customers open your store in the AXON app, add items to a cart and place orders. You see them the moment they arrive.',
  ],
  founder:
    'Ashraf built AXON because running a business is hard enough without bad software making it harder. ' +
    'AXON is honest, fast, and made for the kind of businesses that keep communities alive: the corner shop, the poultry farm, ' +
    'the salon, the logistics company. No ghost fees. No bloat. Just clarity.',
};

export const PRIVACY_UPDATED = 'October 2026';

export const PRIVACY: { title: string; body: string[] }[] = [
  {
    title: 'Our commitment',
    body: [
      'AXON stores the information you give it so your business and your customers stay connected. We do not sell your data and we do not show ads.',
      'There are no ghost fees: AXON does not take a cut of your sales and does not add charges to customer orders.',
    ],
  },
  {
    title: 'What we store',
    body: [
      'Account: your name, email, phone number and whether you are a store owner or a customer.',
      'Store owners: your business profile, items with prices, pictures and stock levels, sales and expenses.',
      'Customers: the name and phone number you use at checkout, your orders and your wishlist.',
      'Everyone: suggestions you send to the AXON team.',
    ],
  },
  {
    title: 'Where it is stored',
    body: [
      'Your data is kept in the cloud on Supabase, a hosted database, login and file storage service, so it works on every device and so customers can see the items a store publishes.',
      'Data travels over encrypted connections (HTTPS) and is encrypted at rest by the provider. AXON is not end-to-end encrypted. Because the data is on a server, the AXON team and the hosting provider can technically access it. That access is used only to run, secure and support the app.',
    ],
  },
  {
    title: 'Who can see what',
    body: [
      'A store owner sees only their own business data, plus the name, phone number, items and notes on orders placed with their store.',
      'A customer sees the stores and items that stores publish, plus their own orders and wishlist.',
      'Other people cannot see your data. This is enforced by security rules in the database itself, not only by the app screens.',
    ],
  },
  {
    title: 'Passwords and resets',
    body: [
      'Your password is handled by the login service and stored only in hashed form. We cannot see it.',
      'If you forget it, a 6-digit code is emailed to the address on your account. The code works once and expires quickly. Anyone who can read that inbox can reset the password, so keep your email secure.',
    ],
  },
  {
    title: 'What stays on your phone',
    body: [
      'Your login, and for customers the cart.',
      'For store owners: a copy of the numbers you last looked at, so your shop still shows without signal, and any sales and expenses you saved while offline. These are sent to the cloud when the connection returns. Signing out removes the copy of your numbers. Items not yet sent stay on the phone until they are sent or you remove them.',
    ],
  },
  {
    title: 'Pictures',
    body: [
      'Pictures you add for items and your business logo are uploaded to cloud storage and can be viewed by anyone with the link, so customers can see them. Do not upload pictures you want to keep private.',
    ],
  },
  {
    title: 'Payments',
    body: [
      'AXON does not process payments and never holds your money. Customers pay the store directly, by M-Pesa, cash, bank, card or Airtel Money. The payment method on an order is a record only.',
    ],
  },
  {
    title: 'No tracking',
    body: ['AXON contains no advertising, no third-party trackers and no analytics scripts.'],
  },
  {
    title: 'Your choices',
    body: [
      'You can edit your profile and business data at any time.',
      'You can delete your account in Settings. This removes your account and, for store owners, every business, item, sale and expense you created. A customer who deletes an account is unlinked from past orders, but the name and phone typed at checkout stay in the store\'s own order records.',
      'To ask for a copy of your data, use the Contact page.',
    ],
  },
  {
    title: 'Who may use AXON',
    body: ['AXON is meant for business owners and shoppers aged 18 and over.'],
  },
  {
    title: 'Contact',
    body: ['Questions about privacy? Reach us through the Contact page, or visit ashrafabdalla.onrender.com.'],
  },
];
