import { decode } from 'base64-arraybuffer';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import { IMAGE_BUCKET } from '../config';
import { AppError, friendly } from './errors';
import { supabase } from './supabase';

/** Opens the camera or the gallery. Returns a local file path, or null if cancelled. */
export async function pickImage(source: 'library' | 'camera'): Promise<string | null> {
  if (source === 'camera') {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) throw new AppError('Allow camera access in your phone settings to take a picture.');
  }
  const options: ImagePicker.ImagePickerOptions = {
    mediaTypes: ['images'],
    allowsEditing: true,
    aspect: [1, 1],
    quality: 0.8,
  };
  const res =
    source === 'camera'
      ? await ImagePicker.launchCameraAsync(options)
      : await ImagePicker.launchImageLibraryAsync(options);
  if (res.canceled || !res.assets[0]) return null;
  return res.assets[0].uri;
}

/** Shrinks the picture (max 1000 px) and uploads it to the store's folder. Returns the public link. */
export async function uploadImage(storeId: string, uri: string): Promise<string> {
  const context = ImageManipulator.manipulate(uri, { maxWidth: 1000, maxHeight: 1000 });
  const rendered = await context.renderAsync();
  const out = await rendered.saveAsync({ compress: 0.72, format: SaveFormat.JPEG, base64: true });
  if (!out.base64) throw new AppError('Could not prepare the picture. Try another one.');

  const name = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}.jpg`;
  const path = `${storeId}/${name}`;
  const { error } = await supabase.storage
    .from(IMAGE_BUCKET)
    .upload(path, decode(out.base64), { contentType: 'image/jpeg' });
  if (error) throw new AppError(friendly(error));
  return supabase.storage.from(IMAGE_BUCKET).getPublicUrl(path).data.publicUrl;
}

/** Path inside the bucket for one of our public links, or null for foreign links. */
export function pathFromUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  const marker = `/${IMAGE_BUCKET}/`;
  const i = url.indexOf(marker);
  if (i < 0) return null;
  return decodeURIComponent(url.slice(i + marker.length).split('?')[0]);
}

/** Best-effort removal of an old picture. Never throws. */
export async function deleteImageByUrl(url: string | null | undefined): Promise<void> {
  const path = pathFromUrl(url);
  if (!path) return;
  try {
    await supabase.storage.from(IMAGE_BUCKET).remove([path]);
  } catch {
    // an orphaned picture is harmless
  }
}
