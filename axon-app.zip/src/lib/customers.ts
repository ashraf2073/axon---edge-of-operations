import type { Order } from '../types';

export interface CustomerSummary {
  /** the customer's account id; for an order whose account was deleted, the phone number */
  key: string;
  name: string;
  phone: string;
  /** orders not cancelled */
  orders: number;
  /** total of completed orders */
  spent: number;
  open: number;
  lastAt: string;
  firstAt: string;
}

export const customerKey = (o: Pick<Order, 'customer_id' | 'customer_phone'>) =>
  o.customer_id ?? `phone:${o.customer_phone}`;

/**
 * Turns a store's orders into its customers. A customer is one AXON account, so the same person is
 * recognised on every order they place with this store, whatever name or phone they typed at checkout.
 * Each store only ever sees the orders placed with it, so customers of other stores never appear here.
 */
export function groupCustomers(orders: Order[]): CustomerSummary[] {
  const map = new Map<string, CustomerSummary>();
  [...orders]
    .sort((a, b) => a.created_at.localeCompare(b.created_at))
    .forEach((o) => {
      const k = customerKey(o);
      const cur = map.get(k) ?? {
        key: k,
        name: o.customer_name,
        phone: o.customer_phone,
        orders: 0,
        spent: 0,
        open: 0,
        lastAt: o.created_at,
        firstAt: o.created_at,
      };
      // the newest details win
      cur.name = o.customer_name || cur.name;
      cur.phone = o.customer_phone || cur.phone;
      cur.lastAt = o.created_at;
      if (o.status !== 'cancelled') cur.orders += 1;
      if (o.status === 'complete') cur.spent += Number(o.total);
      if (o.status === 'placed' || o.status === 'processing') cur.open += 1;
      map.set(k, cur);
    });
  return [...map.values()].filter((c) => c.orders > 0 || c.open > 0).sort((a, b) => b.lastAt.localeCompare(a.lastAt));
}
