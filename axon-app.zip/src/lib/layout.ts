/** How many cards fit across: 2 on phones, more on tablets and wide windows. */
export function gridColumns(width: number): number {
  if (width >= 1100) return 5;
  if (width >= 900) return 4;
  if (width >= 600) return 3;
  return 2;
}

/** Width of one card in a wrapping grid with the screen's 16 px side padding. */
export function cardWidth(width: number, gap = 12, side = 16): number {
  const cols = gridColumns(width);
  return Math.floor((width - side * 2 - gap * (cols - 1)) / cols);
}

/** Content never stretches wider than this, so desktop windows stay readable. */
export const MAX_CONTENT = 760;
