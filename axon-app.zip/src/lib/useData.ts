import { useFocusEffect } from '@react-navigation/native';
import { useCallback, useEffect, useRef, useState } from 'react';
import { friendly } from './errors';

/**
 * Load something from the cloud and keep it fresh.
 * - runs on mount and whenever `deps` change
 * - `reload()` refetches quietly (no spinner), `refresh()` is for pull-to-refresh
 * - ignores answers that arrive late for an older request
 */
export function useData<T>(fn: () => Promise<T>, deps: readonly unknown[], enabled = true) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(enabled);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const seq = useRef(0);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  const run = useCallback(async (mode: 'load' | 'silent' | 'refresh') => {
    const id = ++seq.current;
    if (mode === 'load') setLoading(true);
    if (mode === 'refresh') setRefreshing(true);
    try {
      const res = await fnRef.current();
      if (!alive.current || id !== seq.current) return;
      setData(res);
      setError(null);
    } catch (e) {
      if (!alive.current || id !== seq.current) return;
      setError(friendly(e));
    } finally {
      if (alive.current && id === seq.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, []);

  useEffect(() => {
    if (!enabled) {
      setLoading(false);
      return;
    }
    void run('load');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, ...deps]);

  const reload = useCallback(() => void run('silent'), [run]);
  const refresh = useCallback(() => void run('refresh'), [run]);
  return { data, loading, refreshing, error, reload, refresh, setData };
}

/** Call `reload` each time a screen comes back into view (after the first time). */
export function useRefetchOnFocus(reload: () => void) {
  const first = useRef(true);
  useFocusEffect(
    useCallback(() => {
      if (first.current) {
        first.current = false;
        return;
      }
      reload();
    }, [reload]),
  );
}
