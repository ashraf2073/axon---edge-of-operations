import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * A copy of the last numbers each screen loaded, kept on the phone so an owner without signal
 * still sees their shop. The cloud database stays the source of truth: a copy is only used when
 * the connection is down, and is replaced each time a fresh answer arrives.
 */
const PREFIX = 'axon.cache.v1.';

const keyOf = (uid: string, key: string) => `${PREFIX}${uid}.${key}`;

export async function writeCache(uid: string, key: string, data: unknown): Promise<void> {
  try {
    await AsyncStorage.setItem(keyOf(uid, key), JSON.stringify({ at: new Date().toISOString(), data }));
  } catch {
    // a full phone must never break a screen that has fresh data
  }
}

export async function readCache<T>(uid: string, key: string): Promise<{ at: string; data: T } | null> {
  try {
    const raw = await AsyncStorage.getItem(keyOf(uid, key));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { at: string; data: T };
    return parsed && 'data' in parsed ? parsed : null;
  } catch {
    return null;
  }
}

/** Removes every saved copy that belongs to one person (used on sign out). */
export async function clearCache(uid: string): Promise<void> {
  try {
    const all = await AsyncStorage.getAllKeys();
    const mine = all.filter((k) => k.startsWith(`${PREFIX}${uid}.`));
    if (mine.length) await AsyncStorage.multiRemove(mine);
  } catch {
    // nothing to clean up
  }
}
