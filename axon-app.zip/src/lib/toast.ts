import { create } from 'zustand';

export type ToastKind = 'success' | 'error' | 'info';

interface ToastState {
  id: number;
  msg: string;
  kind: ToastKind;
  show: (msg: string, kind?: ToastKind) => void;
  hide: () => void;
}

export const useToast = create<ToastState>((set) => ({
  id: 0,
  msg: '',
  kind: 'info',
  show: (msg, kind = 'info') => set((s) => ({ id: s.id + 1, msg, kind })),
  hide: () => set({ msg: '' }),
}));

export const toast = {
  success: (m: string) => useToast.getState().show(m, 'success'),
  error: (m: string) => useToast.getState().show(m, 'error'),
  info: (m: string) => useToast.getState().show(m, 'info'),
};
