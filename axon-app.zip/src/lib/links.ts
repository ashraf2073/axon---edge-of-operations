import { Linking } from 'react-native';
import { toast } from './toast';

/** Opens a web page, the phone dialler, a WhatsApp chat or the email app. */
export async function openLink(url: string): Promise<void> {
  try {
    await Linking.openURL(url);
  } catch {
    toast.error('Could not open that link on this phone.');
  }
}
