/**
 * After a customer submits an order the phone logs them out, so the next person who picks it up
 * (a shared phone at a shop, for example) cannot open that account. Only the login on this phone
 * ends; the account, the order and the cart of other devices stay as they were.
 */
export const autoLogout = { seconds: 12 };
