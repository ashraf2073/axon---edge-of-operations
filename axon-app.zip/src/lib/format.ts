import type { Currency, DateFormat } from '../types';

export const CURRENCIES: { code: Currency; symbol: string; name: string }[] = [
  { code: 'KES', symbol: 'KSh', name: 'Kenyan shilling' },
  { code: 'USD', symbol: '$', name: 'US dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British pound' },
  { code: 'TZS', symbol: 'TSh', name: 'Tanzanian shilling' },
  { code: 'UGX', symbol: 'USh', name: 'Ugandan shilling' },
  { code: 'NGN', symbol: 'NGN', name: 'Nigerian naira' },
];

export function currencySymbol(code: Currency | string): string {
  return CURRENCIES.find((c) => c.code === code)?.symbol ?? String(code);
}

function group(intPart: string): string {
  return intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * Money style (2 decimals): 1234.5 becomes "1,234.50" and whole numbers lose the decimals ("1,234").
 * Any other precision, used for quantities and percentages, drops trailing zeros: 2.5 stays "2.5".
 */
export function num(n: number, maxDecimals = 2): string {
  const factor = 10 ** maxDecimals;
  const v = Math.round((Number(n) || 0) * factor) / factor;
  const [i, d] = Math.abs(v).toFixed(maxDecimals).split('.');
  const digits = d && maxDecimals !== 2 ? d.replace(/0+$/, '') : d;
  const frac = digits && Number(digits) !== 0 ? '.' + digits : '';
  return (v < 0 ? '-' : '') + group(i) + frac;
}

/** Quantities such as 2.5 kg or 40 litres. */
export function qty(n: number): string {
  return num(n, 3);
}

/** Money with the currency symbol. compact: 1.25M, 12.4K. */
export function money(n: number, cur: Currency | string = 'KES', compact = false): string {
  const v = Number(n) || 0;
  const sym = currencySymbol(cur);
  const sign = v < 0 ? '-' : '';
  const a = Math.abs(v);
  let body: string;
  if (compact && a >= 1e6) body = (a / 1e6).toFixed(2) + 'M';
  else if (compact && a >= 1e3) body = (a / 1e3).toFixed(1) + 'K';
  else body = num(a, 2);
  const spaced = sym.length > 1 && /^[A-Za-z]+$/.test(sym) ? sym + ' ' : sym;
  return `${sign}${spaced}${body}`;
}

const pad = (n: number) => String(n).padStart(2, '0');

/** Accepts a Date, an ISO timestamp, or a plain YYYY-MM-DD date. */
export function parseDate(s: string | Date): Date {
  if (s instanceof Date) return s;
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    const [y, m, d] = s.split('-').map(Number);
    return new Date(y, m - 1, d);
  }
  return new Date(s);
}

export function toDateKey(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function formatDate(s: string | Date, fmt: DateFormat = 'DD/MM/YYYY'): string {
  const d = parseDate(s);
  if (Number.isNaN(d.getTime())) return '';
  const dd = pad(d.getDate());
  const mm = pad(d.getMonth() + 1);
  const yy = d.getFullYear();
  if (fmt === 'MM/DD/YYYY') return `${mm}/${dd}/${yy}`;
  if (fmt === 'YYYY-MM-DD') return `${yy}-${mm}-${dd}`;
  return `${dd}/${mm}/${yy}`;
}

export function formatDateTime(s: string | Date, fmt: DateFormat = 'DD/MM/YYYY'): string {
  const d = parseDate(s);
  if (Number.isNaN(d.getTime())) return '';
  return `${formatDate(d, fmt)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "2026-05" becomes "May". */
export function monthShort(key: string): string {
  const m = Number(key.split('-')[1]);
  return MONTHS[m - 1] ?? key;
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'just now';
  if (min < 60) return `${min} min ago`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d} d ago`;
  return formatDate(iso);
}

export function localTimeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

export type Period = 'month' | '3m' | 'year' | 'all';

export const PERIODS: { key: Period; label: string }[] = [
  { key: 'month', label: 'This month' },
  { key: '3m', label: '3 months' },
  { key: 'year', label: 'This year' },
  { key: 'all', label: 'All time' },
];

/** Start (inclusive) and end (exclusive) of a period, in the phone's local time. */
export function periodRange(p: Period, now = new Date()): { from: string | null; to: string | null } {
  if (p === 'all') return { from: null, to: null };
  const y = now.getFullYear();
  const m = now.getMonth();
  if (p === 'month') return { from: new Date(y, m, 1).toISOString(), to: new Date(y, m + 1, 1).toISOString() };
  if (p === '3m') return { from: new Date(y, m - 2, 1).toISOString(), to: new Date(y, m + 1, 1).toISOString() };
  return { from: new Date(y, 0, 1).toISOString(), to: new Date(y + 1, 0, 1).toISOString() };
}

export function firstName(full: string): string {
  return (full || '').trim().split(/\s+/)[0] || '';
}

export function initials(name: string): string {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return 'A';
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

export function digitsOnly(s: string): string {
  return s.replace(/[^\d+]/g, '');
}

export function parseNumber(s: string): number {
  const v = parseFloat(s.replace(/,/g, '').trim());
  return Number.isFinite(v) ? v : NaN;
}
