export const NO_INTERNET = 'No internet connection. Check your data or Wi-Fi and try again.';

const NETWORK_WORDS = [
  'network request failed',
  'failed to fetch',
  'network error',
  'networkerror',
  'timed out',
  'load failed',
  'fetch failed',
  'no internet connection',
];

/** True when the problem is the connection (so waiting and trying again can work), not the request. */
export function isNetworkError(e: unknown): boolean {
  if (!e) return false;
  const name = typeof e === 'object' && 'name' in e ? String((e as { name: unknown }).name) : '';
  if (name === 'AuthRetryableFetchError') return true;
  const raw =
    typeof e === 'string' ? e : typeof e === 'object' && 'message' in e ? String((e as { message: unknown }).message) : '';
  const m = raw.toLowerCase();
  return NETWORK_WORDS.some((w) => m.includes(w));
}

/** True when the login has run out, so sending should pause until the app has a fresh one. */
export function isSessionError(e: unknown): boolean {
  const raw =
    typeof e === 'string' ? e : e && typeof e === 'object' && 'message' in e ? String((e as { message: unknown }).message) : '';
  const m = raw.toLowerCase();
  return m.includes('jwt expired') || m.includes('invalid jwt') || m.includes('refresh token') || m.includes('session expired') || m.includes('sign in first');
}

/** Turn any error from Supabase or the network into a sentence a shop owner can act on. */
export function friendly(e: unknown): string {
  const raw =
    typeof e === 'string'
      ? e
      : e && typeof e === 'object' && 'message' in e
        ? String((e as { message: unknown }).message)
        : '';
  const m = raw.toLowerCase();

  if (!raw) return 'Something went wrong. Please try again.';
  if (NETWORK_WORDS.some((w) => m.includes(w))) return NO_INTERNET;
  if (m.includes('token has expired or is invalid') || m.includes('otp_expired') || m.includes('otp expired')) {
    return 'That code is wrong or has expired. Check the newest email, or ask for a new code.';
  }
  if (m.includes('invalid login credentials')) return 'Wrong email or password.';
  if (m.includes('email not confirmed')) return 'Please confirm your email first. Check your inbox for the link, then log in.';
  if (m.includes('user already registered') || m.includes('already been registered')) {
    return 'An account with this email already exists. Try logging in instead.';
  }
  if (m.includes('password should be at least') || m.includes('weak password')) {
    return 'Password is too weak. Use at least 8 characters.';
  }
  if (m.includes('rate limit') || m.includes('too many requests') || m.includes('over_email_send_rate_limit')) {
    return 'Too many attempts. Please wait a minute and try again.';
  }
  if (m.includes('new password should be different')) return 'Choose a password you have not used before.';
  if (m.includes('jwt expired') || m.includes('invalid jwt') || m.includes('refresh token') || m.includes('session expired')) {
    return 'Your session expired. Please log in again.';
  }
  if (m.includes('row-level security') || m.includes('permission denied')) {
    return 'You do not have permission to do that.';
  }
  if (m.includes('cannot coerce the result to a single json object') || m.includes('json object requested')) {
    return 'That could not be found. It may have been removed, or it is not yours to change.';
  }
  if (m.includes('duplicate key')) return 'That already exists.';
  if (m.includes('violates check constraint')) return 'One of the values is not allowed. Please check your entries.';
  if (m.includes('function public.axon_') && m.includes('does not exist')) {
    return 'The AXON backend is not set up yet. Run supabase/schema.sql in your Supabase project.';
  }
  if (m.includes('relation') && m.includes('axon_') && m.includes('does not exist')) {
    return 'The AXON backend is not set up yet. Run supabase/schema.sql in your Supabase project.';
  }
  if (m.includes('could not find the function') || m.includes('could not find the table')) {
    return 'The AXON backend is not set up yet. Run supabase/schema.sql in your Supabase project.';
  }
  return raw;
}

export class AppError extends Error {}

/** Throw a friendly error when a Supabase call returned one. */
export function check<T>(res: { data: T | null; error: unknown }): T {
  if (res.error) throw new AppError(friendly(res.error));
  return res.data as T;
}

export function isValidEmail(s: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s.trim());
}
