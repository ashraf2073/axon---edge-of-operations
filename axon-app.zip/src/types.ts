export type Role = 'owner' | 'customer';
export type DateFormat = 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD';
export type Currency = 'KES' | 'USD' | 'EUR' | 'GBP' | 'TZS' | 'UGX' | 'NGN';
export type StoreKind = 'shop' | 'farm' | 'company' | 'supermarket' | 'service' | 'other';
export type ProductKind = 'good' | 'farm' | 'animal' | 'service';
export type PayMethod = 'mpesa' | 'cash' | 'bank' | 'card' | 'airtel';
export type OrderStatus = 'placed' | 'processing' | 'complete' | 'cancelled';
export type FeedbackType = 'feature' | 'bug' | 'improvement' | 'praise' | 'other';
export type FeedbackPriority = 'low' | 'medium' | 'high';
export type FeedbackStatus = 'new' | 'reviewing' | 'planned' | 'done' | 'dismissed';

export interface Profile {
  id: string;
  role: Role;
  full_name: string;
  phone: string;
  email: string;
  date_format: DateFormat;
  consent_at: string | null;
  consent_contact: boolean;
}

export interface Store {
  id: string;
  owner_id: string;
  code: string;
  name: string;
  kind: StoreKind;
  description: string;
  location: string;
  phone: string;
  currency: Currency;
  payment_info: string;
  logo_url: string | null;
  created_at: string;
}

export interface Product {
  id: string;
  store_id: string;
  name: string;
  category: string;
  kind: ProductKind;
  description: string;
  unit: string;
  price: number;
  cost: number;
  stock: number;
  track_stock: boolean;
  low_alert: number;
  image_url: string | null;
  active: boolean;
  created_at: string;
}

export interface Sale {
  id: string;
  store_id: string;
  product_id: string | null;
  order_id: string | null;
  product_name: string;
  unit: string;
  txn_id: string;
  qty: number;
  unit_price: number;
  total: number;
  customer: string;
  note: string;
  sold_at: string;
  /** true for a sale saved on this phone that has not reached the cloud yet */
  pending?: boolean;
}

export interface Expense {
  id: string;
  store_id: string;
  category: string;
  description: string;
  payee: string;
  amount: number;
  spent_on: string;
  created_at: string;
  /** true for an expense saved on this phone that has not reached the cloud yet */
  pending?: boolean;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  name: string;
  unit: string;
  image_url: string | null;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  code: string;
  store_id: string;
  customer_id: string | null;
  customer_name: string;
  customer_phone: string;
  pay_method: PayMethod;
  notes: string;
  total: number;
  currency: Currency;
  status: OrderStatus;
  /** the store approves the payment by hand; AXON never handles the money */
  payment_status: 'awaiting' | 'approved';
  payment_approved_at: string | null;
  created_at: string;
  updated_at: string;
  items?: OrderItem[];
  store?: Pick<Store, 'name' | 'phone' | 'payment_info' | 'currency' | 'logo_url'> | null;
}

export interface Feedback {
  id: string;
  type: FeedbackType;
  priority: FeedbackPriority;
  message: string;
  status: FeedbackStatus;
  role: string;
  store_name: string;
  contact_name?: string;
  contact_email?: string;
  created_at: string;
}

export interface MonthPoint {
  month: string;
  revenue: number;
  expenses: number;
}

export interface Analytics {
  revenue: number;
  expenses: number;
  units: number;
  sales_count: number;
  monthly: MonthPoint[];
  top_products: { name: string; units: number; revenue: number }[];
  expense_breakdown: { category: string; amount: number }[];
  low_stock: { id: string; name: string; stock: number; low_alert: number; unit: string }[];
  new_orders: number;
  open_orders: number;
  product_count: number;
}

export interface StoreWithCount extends Store {
  products?: { count: number }[];
}
