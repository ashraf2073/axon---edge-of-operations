export const colors = {
  bg: '#06060f',
  dk: '#0c0c18',
  card: '#11111c',
  card2: '#171724',
  border: '#1e1e2e',
  border2: '#28283c',
  blue: '#0057b8',
  blueLight: '#3390ff',
  blueDark: '#003d8a',
  pink: '#ff1f6e',
  pinkLight: '#ff6fa3',
  pinkDark: '#b5004d',
  text: '#f0f0fa',
  off: '#9898b8',
  muted: '#52526e',
  green: '#00cc88',
  amber: '#ffab00',
  red: '#ff3a52',
  purple: '#7c5cf6',
  white: '#ffffff',
} as const;

/** Soft tinted backgrounds for badges and banners. */
export function tint(hex: string, alpha = 0.12): string {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

export const fonts = {
  head: 'Syne_800ExtraBold',
  headBold: 'Syne_700Bold',
  ui: 'Syne_600SemiBold',
  body: 'DMSans_400Regular',
  bodyMed: 'DMSans_500Medium',
  bodyBold: 'DMSans_700Bold',
} as const;

export const radius = { sm: 8, md: 12, lg: 16, xl: 22, pill: 999 } as const;

export const EXPENSE_CATEGORIES = [
  { key: 'Rent', label: 'Rent / Premises', color: '#7c5cf6' },
  { key: 'Wages', label: 'Wages / Salaries', color: '#3390ff' },
  { key: 'Stock', label: 'Stock / Goods Purchase', color: '#ff9f1c' },
  { key: 'Utilities', label: 'Utilities (water, electricity)', color: '#06d6a0' },
  { key: 'Transport', label: 'Transport / Delivery', color: '#ffd166' },
  { key: 'Maintenance', label: 'Maintenance / Repairs', color: '#ef476f' },
  { key: 'Insurance', label: 'Insurance', color: '#118ab2' },
  { key: 'Taxes', label: 'Taxes / Levies', color: '#e63946' },
  { key: 'Marketing', label: 'Marketing / Advertising', color: '#ff1f6e' },
  { key: 'Equipment', label: 'Equipment / Tools', color: '#8338ec' },
  { key: 'Other', label: 'Other', color: '#aaaaaa' },
] as const;

export function expenseColor(key: string): string {
  return EXPENSE_CATEGORIES.find((c) => c.key === key)?.color ?? '#aaaaaa';
}

export function expenseLabel(key: string): string {
  return EXPENSE_CATEGORIES.find((c) => c.key === key)?.label ?? key;
}
