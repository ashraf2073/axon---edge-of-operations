import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import { IS_CONFIGURED } from '../config';
import { AccountErrorScreen, ConsentScreen, ProfileMissingScreen, SetupRequiredScreen } from '../screens/auth/Gates';
import { LoginScreen } from '../screens/auth/Login';
import { ResetScreen } from '../screens/auth/Reset';
import { SignupScreen } from '../screens/auth/Signup';
import { WelcomeScreen } from '../screens/auth/Welcome';
import { CustomerTabs } from '../screens/customer/CustomerTabs';
import { CheckoutScreen } from '../screens/customer/Checkout';
import { OrderDoneScreen } from '../screens/customer/OrderDone';
import { ProductDetailScreen } from '../screens/customer/ProductDetail';
import { StorefrontScreen } from '../screens/customer/Storefront';
import { BusinessesScreen } from '../screens/owner/Businesses';
import { MoreScreen } from '../screens/owner/More';
import { OutboxScreen } from '../screens/owner/Outbox';
import { OwnerTabs } from '../screens/owner/OwnerTabs';
import { ProductFormScreen } from '../screens/owner/ProductForm';
import { StoreFormScreen } from '../screens/owner/StoreForm';
import { AboutScreen } from '../screens/shared/About';
import { AdminGateScreen } from '../screens/shared/AdminGate';
import { AdminPanelScreen } from '../screens/shared/AdminPanel';
import { ChangePasswordScreen } from '../screens/shared/ChangePassword';
import { ContactScreen } from '../screens/shared/Contact';
import { PrivacyScreen } from '../screens/shared/Privacy';
import { SettingsScreen } from '../screens/shared/Settings';
import { SuggestionsScreen } from '../screens/shared/Suggestions';
import { usePrefs } from '../state/prefs';
import { useSession } from '../state/session';
import { colors } from '../theme';
import { Splash } from '../ui/Splash';
import type { RootParams } from './types';

const Stack = createNativeStackNavigator<RootParams>();

type Mode =
  | 'loading'
  | 'setup'
  | 'consent'
  | 'auth'
  | 'error'
  | 'missing'
  | 'store'
  | 'owner'
  | 'customer';

/** Decides which part of the app the person sees, from where they are in the sign-in journey. */
function useMode(): Mode {
  const prefsLoaded = usePrefs((s) => s.loaded);
  const consent = usePrefs((s) => s.consent);
  const ready = useSession((s) => s.ready);
  const session = useSession((s) => s.session);
  const accountLoaded = useSession((s) => s.accountLoaded);
  const accountError = useSession((s) => s.accountError);
  const profile = useSession((s) => s.profile);
  const fromCache = useSession((s) => s.fromCache);
  const recovering = useSession((s) => s.recovering);
  const storeCount = useSession((s) => s.stores.length);
  const signingIn = useSession((s) => s.pendingRole !== null);

  if (!IS_CONFIGURED) return 'setup';
  if (!prefsLoaded || !ready) return 'loading';
  if (!consent) return 'consent';
  // While a password is being reset the person is briefly logged in; they stay on the reset screen.
  if (recovering) return 'auth';
  // Without a connection the app opens from the saved copy of the account.
  if (!session && !fromCache) return 'auth';
  // While a log-in is running, the log-in screen stays on top so it can show a wrong-role message.
  if (signingIn && !accountLoaded) return 'auth';
  if (!accountLoaded) return accountError ? 'error' : 'loading';
  if (!profile) return 'missing';
  if (profile.role === 'owner') return storeCount === 0 ? 'store' : 'owner';
  return 'customer';
}

function infoScreens() {
  return (
    <>
      <Stack.Screen name="About" component={AboutScreen} />
      <Stack.Screen name="Contact" component={ContactScreen} />
      <Stack.Screen name="Privacy" component={PrivacyScreen} />
      <Stack.Screen name="AdminGate" component={AdminGateScreen} />
      <Stack.Screen name="AdminPanel" component={AdminPanelScreen} />
    </>
  );
}

function accountScreens() {
  return (
    <>
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="ChangePassword" component={ChangePasswordScreen} />
      <Stack.Screen name="Suggestions" component={SuggestionsScreen} />
      {infoScreens()}
    </>
  );
}

export function RootNavigator() {
  const mode = useMode();

  if (mode === 'setup') return <SetupRequiredScreen />;
  if (mode === 'loading') return <Splash message="Loading" />;
  if (mode === 'consent') return <ConsentScreen />;
  if (mode === 'error') return <AccountErrorScreen />;
  if (mode === 'missing') return <ProfileMissingScreen />;

  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
        contentStyle: { backgroundColor: colors.bg },
      }}
    >
      {mode === 'auth' ? (
        <>
          <Stack.Screen name="Welcome" component={WelcomeScreen} />
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="Signup" component={SignupScreen} />
          <Stack.Screen name="Reset" component={ResetScreen} />
          {infoScreens()}
        </>
      ) : mode === 'store' ? (
        <Stack.Screen name="StoreSetup" component={StoreFormScreen} />
      ) : mode === 'owner' ? (
        <>
          <Stack.Screen name="OwnerTabs" component={OwnerTabs} />
          <Stack.Screen name="ProductForm" component={ProductFormScreen} />
          <Stack.Screen name="StoreForm" component={StoreFormScreen} />
          <Stack.Screen name="Businesses" component={BusinessesScreen} />
          <Stack.Screen name="More" component={MoreScreen} />
          <Stack.Screen name="Outbox" component={OutboxScreen} />
          {accountScreens()}
        </>
      ) : (
        <>
          <Stack.Screen name="CustomerTabs" component={CustomerTabs} />
          <Stack.Screen name="Storefront" component={StorefrontScreen} />
          <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
          <Stack.Screen name="Checkout" component={CheckoutScreen} />
          <Stack.Screen name="OrderDone" component={OrderDoneScreen} options={{ gestureEnabled: false }} />
          {accountScreens()}
        </>
      )}
    </Stack.Navigator>
  );
}
