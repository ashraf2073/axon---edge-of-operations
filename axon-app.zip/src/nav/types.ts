import type { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import type { CompositeNavigationProp, NavigatorScreenParams } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { Currency, PayMethod, Role } from '../types';

export type RootParams = {
  // signed out
  Welcome: undefined;
  Login: { role: Role };
  Signup: { role: Role };
  Reset: undefined;
  AdminGate: undefined;
  AdminPanel: { code: string };
  // signed in but not finished
  StoreSetup: undefined;
  // store owner
  OwnerTabs: NavigatorScreenParams<OwnerTabParams> | undefined;
  ProductForm: { id?: string } | undefined;
  StoreForm: { id?: string } | undefined;
  Businesses: undefined;
  More: undefined;
  Outbox: undefined;
  // customer
  CustomerTabs: NavigatorScreenParams<CustomerTabParams> | undefined;
  Storefront: { storeId: string };
  ProductDetail: { productId: string };
  Checkout: undefined;
  OrderDone: { code: string; total: number; currency: Currency; storeName: string; payMethod: PayMethod };
  // both
  Settings: undefined;
  ChangePassword: undefined;
  Suggestions: undefined;
  About: undefined;
  Contact: undefined;
  Privacy: undefined;
};

export type OwnerTabParams = {
  Dash: undefined;
  Stock: undefined;
  Sales: { segment?: 'log' | 'orders' } | undefined;
  Costs: undefined;
  Analysis: undefined;
};

export type CustomerTabParams = {
  Shop: undefined;
  Wishlist: undefined;
  Cart: undefined;
  Orders: undefined;
  Me: undefined;
};

/** Navigation inside the business tabs, which can also open any root screen. */
export type OwnerNav = CompositeNavigationProp<
  BottomTabNavigationProp<OwnerTabParams>,
  NativeStackNavigationProp<RootParams>
>;

/** Navigation inside the customer tabs, which can also open any root screen. */
export type CustomerNav = CompositeNavigationProp<
  BottomTabNavigationProp<CustomerTabParams>,
  NativeStackNavigationProp<RootParams>
>;
