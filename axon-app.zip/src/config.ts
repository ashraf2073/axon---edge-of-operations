// =====================================================================
// AXON settings. This is the only file you need to edit before building.
//
// 1. Open your Supabase project > Project Settings > API.
// 2. Copy the "Project URL" into SUPABASE_URL.
// 3. Copy the "anon" key (or the "publishable" key) into SUPABASE_ANON_KEY.
//
// The anon/publishable key is designed to be public. It is safe inside
// the app because the security rules in supabase/schema.sql protect the
// data. NEVER put the "service_role" or "secret" key here.
//
// Builds on a computer or on GitHub can also set these two names as
// environment variables instead of editing this file:
//   EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY
// =====================================================================

const PLACEHOLDER_URL = 'https://YOUR-PROJECT-REF.supabase.co';
const PLACEHOLDER_KEY = 'YOUR-ANON-OR-PUBLISHABLE-KEY';

export const SUPABASE_URL: string = process.env.EXPO_PUBLIC_SUPABASE_URL || PLACEHOLDER_URL;
export const SUPABASE_ANON_KEY: string = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || PLACEHOLDER_KEY;

export const IS_CONFIGURED =
  SUPABASE_URL !== PLACEHOLDER_URL && SUPABASE_ANON_KEY !== PLACEHOLDER_KEY;

/** Storage bucket created by supabase/schema.sql. */
export const IMAGE_BUCKET = 'axon-images';

export const APP_VERSION = '1.0.0';

/** Contact details shown on the Contact and About pages. */
export const CONTACT = {
  studio: 'Tribridge Studios',
  founder: 'Ashraf Abdalla',
  instagramHandle: '@tribridge_studios',
  instagramUrl: 'https://www.instagram.com/tribridge_studios',
  whatsappDisplay: '+254 759 858 428',
  whatsappUrl: 'https://wa.me/254759858428',
  phoneDisplay: '+254 759 858 428',
  phoneUrl: 'tel:+254759858428',
  email: 'servicestribridge@gmail.com',
  emailUrl: 'mailto:servicestribridge@gmail.com',
  websiteDisplay: 'ashrafabdalla.onrender.com',
  websiteUrl: 'https://ashrafabdalla.onrender.com',
} as const;
