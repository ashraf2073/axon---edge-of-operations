import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { APP_VERSION } from '../../config';
import { deleteMyAccount, updateProfile } from '../../api/account';
import { friendly } from '../../lib/errors';
import { formatDate, initials } from '../../lib/format';
import { toast } from '../../lib/toast';
import type { RootParams } from '../../nav/types';
import { useOutbox } from '../../state/outbox';
import { useSession } from '../../state/session';
import { colors, fonts, radius, tint } from '../../theme';
import type { DateFormat } from '../../types';
import { Button } from '../../ui/Button';
import { Badge, Chip, ChipWrap } from '../../ui/Chips';
import { MenuRow, Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { Header, Screen } from '../../ui/Screen';
import { Sheet } from '../../ui/Sheet';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Settings'>;

const DATE_FORMATS: DateFormat[] = ['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD'];

export function SettingsScreen({ navigation }: Props) {
  const profile = useSession((s) => s.profile);
  const stores = useSession((s) => s.stores);
  const patchProfile = useSession((s) => s.patchProfile);
  const signOut = useSession((s) => s.signOut);
  const waiting = useOutbox((s) => s.items.filter((i) => i.ownerId === profile?.id && i.status === 'waiting').length);

  const [editOpen, setEditOpen] = useState(false);
  const [name, setName] = useState(profile?.full_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [editBusy, setEditBusy] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  const [delOpen, setDelOpen] = useState(false);
  const [delText, setDelText] = useState('');
  const [delBusy, setDelBusy] = useState(false);
  const [delError, setDelError] = useState<string | null>(null);

  if (!profile) return null;
  const owner = profile.role === 'owner';

  const saveProfile = async () => {
    setEditError(null);
    if (name.trim().length < 2) return setEditError('Enter your full name.');
    if (phone.replace(/\D/g, '').length < 7) return setEditError('Enter a valid phone number.');
    setEditBusy(true);
    try {
      await updateProfile(profile.id, { full_name: name.trim(), phone: phone.trim() });
      patchProfile({ full_name: name.trim(), phone: phone.trim() });
      setEditOpen(false);
      toast.success('Profile updated.');
    } catch (e) {
      setEditError(friendly(e));
    } finally {
      setEditBusy(false);
    }
  };

  const setFormat = async (f: DateFormat) => {
    if (f === profile.date_format) return;
    const before = profile.date_format;
    patchProfile({ date_format: f });
    try {
      await updateProfile(profile.id, { date_format: f });
    } catch (e) {
      patchProfile({ date_format: before });
      toast.error(friendly(e));
    }
  };

  const confirmSignOut = () => {
    const note =
      waiting > 0
        ? ` ${waiting} saved ${waiting === 1 ? 'item is' : 'items are'} still waiting to be sent. They stay on this phone and go out after you log in again.`
        : '';
    Alert.alert('Sign out?', `You will need your email and password to log in again.${note}`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', onPress: () => void signOut() },
    ]);
  };

  const deleteAccount = async () => {
    setDelError(null);
    if (delText.trim().toUpperCase() !== 'DELETE') return setDelError('Type DELETE to confirm.');
    setDelBusy(true);
    try {
      await deleteMyAccount(stores.map((s) => s.id));
      await useOutbox.getState().purge(profile.id);
      try {
        await signOut();
      } catch {
        // the account is already gone; the local session is cleared either way
      }
    } catch (e) {
      setDelError(friendly(e));
      setDelBusy(false);
    }
  };

  return (
    <Screen>
      <Header title="Settings" />

      <Card style={{ marginBottom: 6 }}>
        <Row gap={14}>
          <View
            style={{
              width: 56,
              height: 56,
              borderRadius: radius.pill,
              backgroundColor: tint(owner ? colors.pink : colors.blueLight, 0.16),
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text style={{ fontFamily: fonts.head, fontSize: 20, color: owner ? colors.pinkLight : colors.blueLight }}>
              {initials(profile.full_name)}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text v="h3" numberOfLines={1}>
              {profile.full_name}
            </Text>
            <Text v="small" numberOfLines={1}>
              {profile.email}
            </Text>
            <Text v="small" numberOfLines={1}>
              {profile.phone}
            </Text>
          </View>
          <Badge label={owner ? 'Store owner' : 'Customer'} color={owner ? colors.pink : colors.blueLight} />
        </Row>
        <Button
          title="Edit name and phone"
          variant="outline"
          size="sm"
          icon="edit-2"
          onPress={() => {
            setName(profile.full_name);
            setPhone(profile.phone);
            setEditError(null);
            setEditOpen(true);
          }}
          style={{ marginTop: 12 }}
        />
      </Card>

      <SectionTitle title="Date format" />
      <ChipWrap>
        {DATE_FORMATS.map((f) => (
          <Chip key={f} label={`${f}  (${formatDate(new Date(), f)})`} selected={profile.date_format === f} onPress={() => void setFormat(f)} />
        ))}
      </ChipWrap>

      <SectionTitle title="Security" />
      <MenuRow icon="lock" label="Change password" onPress={() => navigation.navigate('ChangePassword')} color={colors.amber} />

      <SectionTitle title="Help and information" />
      <MenuRow icon="edit-3" label="Suggestions and feedback" onPress={() => navigation.navigate('Suggestions')} color={colors.pink} />
      <MenuRow icon="message-circle" label="Contact us" onPress={() => navigation.navigate('Contact')} color={colors.green} />
      <MenuRow icon="info" label="About AXON" onPress={() => navigation.navigate('About')} />
      <MenuRow icon="file-text" label="Privacy Policy" onPress={() => navigation.navigate('Privacy')} color={colors.purple} />

      <SectionTitle title="Account" />
      <MenuRow icon="log-out" label="Sign out" onPress={confirmSignOut} color={colors.off} right={<View />} />
      <MenuRow
        icon="trash-2"
        label="Delete my account"
        sub={owner ? 'Removes your account and every business you created' : 'Removes your account and wishlist'}
        danger
        onPress={() => {
          setDelText('');
          setDelError(null);
          setDelOpen(true);
        }}
        right={<View />}
      />

      <Pressable
        onPress={() => navigation.navigate('AdminGate')}
        hitSlop={10}
        accessibilityRole="button"
        style={{ alignSelf: 'center', marginTop: 22 }}
      >
        <Text v="small" color={colors.muted}>
          Admin
        </Text>
      </Pressable>
      <Text v="tiny" center style={{ marginTop: 6 }}>
        AXON {APP_VERSION}
      </Text>

      <Sheet visible={editOpen} onClose={() => setEditOpen(false)} title="Edit profile">
        {editError ? (
          <Notice tone="bad">
            <Text v="body" color={colors.text}>
              {editError}
            </Text>
          </Notice>
        ) : null}
        <Input label="Full name" icon="user" value={name} onChangeText={setName} autoCapitalize="words" />
        <Input label="Phone number" icon="phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
        <Text v="small" style={{ marginBottom: 12 }}>
          Your email is your login and can not be changed here.
        </Text>
        <Button title="Save" onPress={saveProfile} loading={editBusy} />
        <View style={{ height: 8 }} />
      </Sheet>

      <Sheet visible={delOpen} onClose={() => !delBusy && setDelOpen(false)} title="Delete account">
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {owner
              ? 'This permanently deletes your account and every business, item, sale and expense you created. Customer orders placed with your stores are deleted too. This can not be undone.'
              : 'This permanently deletes your account and wishlist. Orders you placed stay in the stores records, unlinked from you. This can not be undone.'}
          </Text>
        </Notice>
        {delError ? (
          <Notice tone="warn">
            <Text v="body" color={colors.text}>
              {delError}
            </Text>
          </Notice>
        ) : null}
        <Input label="Type DELETE to confirm" value={delText} onChangeText={setDelText} autoCapitalize="characters" autoCorrect={false} />
        <Button title="Delete everything" variant="danger" icon="trash-2" onPress={deleteAccount} loading={delBusy} />
        <View style={{ height: 8 }} />
      </Sheet>
    </Screen>
  );
}
