import React from 'react';
import { View } from 'react-native';
import { PRIVACY, PRIVACY_UPDATED } from '../../lib/content';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

/** The policy text on its own, so it can sit inside a screen or a sheet. */
export function PrivacyBody() {
  return (
    <View>
      <Text v="small" style={{ marginBottom: 14 }}>
        Last updated {PRIVACY_UPDATED}
      </Text>
      {PRIVACY.map((s) => (
        <View key={s.title} style={{ marginBottom: 16 }}>
          <Text v="h3" style={{ marginBottom: 6 }}>
            {s.title}
          </Text>
          {s.body.map((p, i) => (
            <Text key={i} v="body" style={{ marginBottom: 6 }}>
              {p}
            </Text>
          ))}
        </View>
      ))}
    </View>
  );
}

export function PrivacyScreen() {
  return (
    <Screen>
      <Header title="Privacy Policy" />
      <PrivacyBody />
    </Screen>
  );
}
