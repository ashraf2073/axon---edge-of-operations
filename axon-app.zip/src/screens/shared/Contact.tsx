import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React from 'react';
import { Pressable, View } from 'react-native';
import { CONTACT } from '../../config';
import { openLink } from '../../lib/links';
import type { RootParams } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors, radius, tint } from '../../theme';
import { Button } from '../../ui/Button';
import { BrandIcon, Icon, type BrandName, type IconName } from '../../ui/Icon';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Contact'>;

interface Channel {
  key: string;
  label: string;
  value: string;
  url: string;
  color: string;
  brand?: BrandName;
  icon?: IconName;
}

const CHANNELS: Channel[] = [
  { key: 'whatsapp', label: 'WhatsApp', value: CONTACT.whatsappDisplay, url: CONTACT.whatsappUrl, color: '#25D366', brand: 'whatsapp' },
  { key: 'instagram', label: 'Instagram', value: CONTACT.instagramHandle, url: CONTACT.instagramUrl, color: '#E1306C', brand: 'instagram' },
  { key: 'phone', label: 'Phone', value: CONTACT.phoneDisplay, url: CONTACT.phoneUrl, color: colors.blueLight, icon: 'phone' },
  { key: 'email', label: 'Email', value: CONTACT.email, url: CONTACT.emailUrl, color: '#EA4335', brand: 'gmail' },
  { key: 'web', label: 'Website', value: CONTACT.websiteDisplay, url: CONTACT.websiteUrl, color: colors.pink, icon: 'globe' },
];

export function ContactScreen({ navigation }: Props) {
  const signedIn = useSession((s) => !!s.session && s.accountLoaded);
  return (
    <Screen>
      <Header title="Contact us" subtitle={CONTACT.studio} />
      <Text v="body" style={{ marginBottom: 16 }}>
        Something not working, or want to talk? Tap any option below and it opens straight away.
      </Text>

      {CHANNELS.map((c) => (
        <Pressable
          key={c.key}
          onPress={() => void openLink(c.url)}
          accessibilityRole="link"
          accessibilityLabel={`${c.label}: ${c.value}`}
          style={({ pressed }) => [
            {
              flexDirection: 'row',
              alignItems: 'center',
              gap: 14,
              backgroundColor: colors.card,
              borderWidth: 1,
              borderColor: tint(c.color, 0.35),
              borderRadius: radius.lg,
              padding: 14,
              marginBottom: 10,
            },
            pressed ? { opacity: 0.85 } : null,
          ]}
        >
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: radius.md,
              backgroundColor: c.color,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {c.brand ? <BrandIcon name={c.brand} size={26} /> : <Icon name={c.icon ?? 'link'} size={24} color={colors.white} />}
          </View>
          <View style={{ flex: 1 }}>
            <Text v="h3">{c.label}</Text>
            <Text v="body" numberOfLines={1}>
              {c.value}
            </Text>
          </View>
          <Icon name="external-link" size={18} color={colors.muted} />
        </Pressable>
      ))}

      {signedIn ? (
        <Button
          title="Send a suggestion or report a problem"
          icon="edit-3"
          variant="outline"
          onPress={() => navigation.navigate('Suggestions')}
          style={{ marginTop: 6 }}
        />
      ) : null}
    </Screen>
  );
}
