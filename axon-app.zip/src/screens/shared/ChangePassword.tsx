import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { changePassword } from '../../api/account';
import { friendly } from '../../lib/errors';
import { toast } from '../../lib/toast';
import type { RootParams } from '../../nav/types';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'ChangePassword'>;

export function ChangePasswordScreen({ navigation }: Props) {
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState(false);

  const submit = async () => {
    setTouched(true);
    setError(null);
    if (pw.length < 8 || pw !== pw2) return;
    setBusy(true);
    try {
      await changePassword(pw);
      toast.success('Password changed.');
      navigation.goBack();
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Header title="Change password" />
      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}
      <Input
        label="New password"
        icon="lock"
        value={pw}
        onChangeText={setPw}
        secure
        autoCapitalize="none"
        autoComplete="new-password"
        placeholder="At least 8 characters"
        error={touched && pw.length < 8 ? 'Use at least 8 characters.' : null}
      />
      <Input
        label="Confirm new password"
        icon="lock"
        value={pw2}
        onChangeText={setPw2}
        secure
        autoCapitalize="none"
        autoComplete="new-password"
        placeholder="Type it again"
        error={touched && pw !== pw2 ? 'The two passwords do not match.' : null}
        onSubmitEditing={submit}
      />
      <Button title="Save new password" onPress={submit} loading={busy} />
    </Screen>
  );
}
