import React, { useState } from 'react';
import { View } from 'react-native';
import { getAnalytics, lastSaleAt } from '../../lib/ownerData';
import { myFeedback, submitFeedback } from '../../api/account';
import { GENERAL_TIPS, SHOPPER_TIPS, smartTips } from '../../lib/analytics';
import { FEEDBACK_PRIORITIES, FEEDBACK_STATUSES, FEEDBACK_TYPES } from '../../lib/content';
import { friendly } from '../../lib/errors';
import { timeAgo } from '../../lib/format';
import { toast } from '../../lib/toast';
import { useData } from '../../lib/useData';
import { useBiz } from '../../state/biz';
import { usePrefs } from '../../state/prefs';
import { useActiveStore, useSession } from '../../state/session';
import { colors } from '../../theme';
import type { FeedbackPriority, FeedbackType } from '../../types';
import { AdviceCard, feedbackStatusColor } from '../../ui/Advice';
import { Button } from '../../ui/Button';
import { Badge, ChipWrap, Chip } from '../../ui/Chips';
import { Checkbox, Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

const MAX = 2000;

export function SuggestionsScreen() {
  const profile = useSession((s) => s.profile);
  const store = useActiveStore();
  const version = useBiz((s) => s.version);
  const consent = usePrefs((s) => s.consent);
  const owner = profile?.role === 'owner';
  const liveOwner = owner && !!store;

  const analytics = useData(() => getAnalytics(store!.id), [store?.id, version], liveOwner);
  const lastSale = useData(() => lastSaleAt(store!.id), [store?.id, version], liveOwner);
  const history = useData(() => myFeedback(), []);

  const [type, setType] = useState<FeedbackType>('feature');
  const [priority, setPriority] = useState<FeedbackPriority>('medium');
  const [message, setMessage] = useState('');
  const [contact, setContact] = useState(consent?.contact ?? false);
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const tips = liveOwner && store ? smartTips(analytics.data, store.currency, lastSale.data ?? null) : [];
  const short = message.trim().length < 10;

  const send = async () => {
    setTouched(true);
    setError(null);
    if (short) return;
    setBusy(true);
    try {
      await submitFeedback({ type, priority, message, includeContact: contact, storeId: store?.id ?? null });
      toast.success('Thank you. Your message reached the AXON team.');
      setMessage('');
      setTouched(false);
      history.reload();
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen onRefresh={() => { analytics.refresh(); history.reload(); }} refreshing={analytics.refreshing}>
      <Header title="Suggestions" subtitle={owner ? 'Advice for your business' : 'Tips for shoppers'} />

      {owner ? (
        <>
          {!store ? (
            <Notice tone="info">
              <Text v="body" color={colors.text}>
                Create a business first and AXON will give you advice based on your own numbers.
              </Text>
            </Notice>
          ) : null}
          {tips.length > 0 ? <SectionTitle title="Based on your numbers" style={{ marginTop: 4 }} /> : null}
          {tips.map((t, i) => (
            <AdviceCard key={`${t.title}-${i}`} advice={t} />
          ))}
          <SectionTitle title="Good habits for any business" />
          {GENERAL_TIPS.map((t) => (
            <Card key={t.title} style={{ marginBottom: 8 }}>
              <Text v="h3">{t.title}</Text>
              <Text v="body" style={{ marginTop: 4 }}>
                {t.body}
              </Text>
            </Card>
          ))}
        </>
      ) : (
        <>
          <SectionTitle title="Shopping on AXON" style={{ marginTop: 4 }} />
          {SHOPPER_TIPS.map((t) => (
            <Card key={t.title} style={{ marginBottom: 8 }}>
              <Text v="h3">{t.title}</Text>
              <Text v="body" style={{ marginTop: 4 }}>
                {t.body}
              </Text>
            </Card>
          ))}
        </>
      )}

      <SectionTitle title="Tell us what to improve" />
      <Card>
        {error ? (
          <Notice tone="bad">
            <Text v="body" color={colors.text}>
              {error}
            </Text>
          </Notice>
        ) : null}
        <Text v="label" style={{ marginBottom: 8 }}>
          What is it about
        </Text>
        <ChipWrap>
          {FEEDBACK_TYPES.map((t) => (
            <Chip key={t.key} label={t.label} selected={type === t.key} onPress={() => setType(t.key)} />
          ))}
        </ChipWrap>
        <Text v="label" style={{ marginTop: 14, marginBottom: 8 }}>
          How important
        </Text>
        <ChipWrap>
          {FEEDBACK_PRIORITIES.map((p) => (
            <Chip
              key={p.key}
              label={p.label}
              selected={priority === p.key}
              color={p.key === 'high' ? colors.red : p.key === 'medium' ? colors.amber : colors.green}
              onPress={() => setPriority(p.key)}
            />
          ))}
        </ChipWrap>
        <View style={{ height: 14 }} />
        <Input
          label="Your message"
          value={message}
          onChangeText={(t) => setMessage(t.slice(0, MAX))}
          multiline
          placeholder="Describe the change you want, or the problem you found."
          error={touched && short ? 'Write at least 10 characters.' : null}
          hint={`${message.length} / ${MAX}`}
        />
        <Checkbox checked={contact} onChange={setContact}>
          <Text v="body" color={colors.text}>
            Include my name and email so the team can reply.
          </Text>
        </Checkbox>
        <Button title="Send to the AXON team" icon="send" onPress={send} loading={busy} />
      </Card>

      <SectionTitle title="Your messages" />
      {history.data && history.data.length > 0 ? (
        history.data.map((f) => {
          const sc = feedbackStatusColor(f.status);
          return (
            <Card key={f.id} style={{ marginBottom: 8 }}>
              <Row justify="space-between" style={{ marginBottom: 6 }}>
                <Row gap={6}>
                  <Badge label={FEEDBACK_TYPES.find((t) => t.key === f.type)?.label ?? f.type} />
                  <Badge label={FEEDBACK_STATUSES.find((s) => s.key === f.status)?.label ?? f.status} color={sc} />
                </Row>
                <Text v="tiny">{timeAgo(f.created_at)}</Text>
              </Row>
              <Text v="body" numberOfLines={4}>
                {f.message}
              </Text>
            </Card>
          );
        })
      ) : (
        <Text v="small">{history.loading ? 'Loading...' : 'You have not sent anything yet.'}</Text>
      )}
    </Screen>
  );
}
