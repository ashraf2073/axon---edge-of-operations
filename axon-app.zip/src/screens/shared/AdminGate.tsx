import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { adminCall } from '../../api/account';
import { friendly } from '../../lib/errors';
import type { RootParams } from '../../nav/types';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'AdminGate'>;

/** Passcode screen. The passcode is checked on the server, never inside the app. */
export function AdminGateScreen({ navigation }: Props) {
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const unlock = async () => {
    const value = code.trim();
    if (!value) {
      setError('Enter the admin passcode.');
      return;
    }
    setError(null);
    setBusy(true);
    try {
      await adminCall(value, 'login');
      navigation.replace('AdminPanel', { code: value });
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Header title="Admin" subtitle="Suggestions and feedback inbox" />
      <Text v="body" style={{ marginBottom: 16 }}>
        This area is for the AXON team. Enter the admin passcode to read the suggestions people have sent.
      </Text>
      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}
      <Input
        label="Admin passcode"
        icon="key"
        value={code}
        onChangeText={setCode}
        secure
        autoCapitalize="none"
        autoCorrect={false}
        placeholder="Passcode"
        returnKeyType="go"
        onSubmitEditing={unlock}
      />
      <Button title="Unlock" icon="unlock" onPress={unlock} loading={busy} />
      <Text v="small" center color={colors.muted} style={{ marginTop: 14 }}>
        Five wrong tries lock this screen for 15 minutes.
      </Text>
    </Screen>
  );
}
