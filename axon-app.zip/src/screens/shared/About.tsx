import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React from 'react';
import { View } from 'react-native';
import { APP_VERSION, CONTACT } from '../../config';
import { ABOUT, SLOGAN } from '../../lib/content';
import { openLink } from '../../lib/links';
import type { RootParams } from '../../nav/types';
import { colors, fonts, radius, tint } from '../../theme';
import { Button } from '../../ui/Button';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { Logo } from '../../ui/Logo';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'About'>;

export function AboutScreen({ navigation }: Props) {
  return (
    <Screen>
      <Header title="About AXON" />
      <View style={{ alignItems: 'center', marginTop: 4, marginBottom: 22 }}>
        <Logo size={88} pulse />
        <Text style={{ fontFamily: fonts.head, fontSize: 34, letterSpacing: 10, color: colors.white, marginTop: 14, marginLeft: 10 }}>
          AXON
        </Text>
        <Text style={{ fontFamily: fonts.ui, fontSize: 11, letterSpacing: 3.5, color: colors.off, marginTop: 6, textTransform: 'uppercase' }}>
          {SLOGAN}
        </Text>
        <Text v="tiny" style={{ marginTop: 8 }}>
          Version {APP_VERSION}
        </Text>
      </View>

      <Card style={{ marginBottom: 10 }}>
        <Text v="h3" style={{ marginBottom: 6 }}>
          What the name means
        </Text>
        <Text v="body">{ABOUT.name}</Text>
      </Card>
      <Card style={{ marginBottom: 10 }}>
        <Text v="h3" style={{ marginBottom: 6 }}>
          The slogan
        </Text>
        <Text v="body">{ABOUT.slogan}</Text>
      </Card>

      <SectionTitle title="How AXON works" />
      <Card>
        {ABOUT.steps.map((s, i) => (
          <Row key={i} gap={12} align="flex-start" style={{ marginBottom: i === ABOUT.steps.length - 1 ? 0 : 12 }}>
            <View
              style={{
                width: 26,
                height: 26,
                borderRadius: radius.pill,
                backgroundColor: tint(colors.pink, 0.14),
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text style={{ fontFamily: fonts.headBold, fontSize: 12, color: colors.pinkLight }}>{i + 1}</Text>
            </View>
            <Text v="body" style={{ flex: 1 }}>
              {s}
            </Text>
          </Row>
        ))}
      </Card>

      <SectionTitle title="The founder" />
      <Card style={{ marginBottom: 14 }}>
        <Text v="h3">{CONTACT.founder}</Text>
        <Text v="small" color={colors.pinkLight} style={{ marginBottom: 8 }}>
          Founder, {CONTACT.studio}
        </Text>
        <Text v="body">{ABOUT.founder}</Text>
      </Card>

      <Button title={`Visit ${CONTACT.websiteDisplay}`} icon="globe" variant="blue" onPress={() => void openLink(CONTACT.websiteUrl)} />
      <Button title="Contact us" icon="message-circle" variant="outline" onPress={() => navigation.navigate('Contact')} style={{ marginTop: 8 }} />
    </Screen>
  );
}
