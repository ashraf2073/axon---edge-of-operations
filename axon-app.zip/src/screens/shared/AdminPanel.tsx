import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Alert, Pressable, Share, View, useWindowDimensions } from 'react-native';
import { adminCall } from '../../api/account';
import { FEEDBACK_PRIORITIES, FEEDBACK_STATUSES, FEEDBACK_TYPES } from '../../lib/content';
import { friendly } from '../../lib/errors';
import { formatDateTime, timeAgo } from '../../lib/format';
import { openLink } from '../../lib/links';
import { toast } from '../../lib/toast';
import { useData } from '../../lib/useData';
import type { RootParams } from '../../nav/types';
import { colors, radius } from '../../theme';
import type { Feedback, FeedbackStatus } from '../../types';
import { feedbackStatusColor } from '../../ui/Advice';
import { Button } from '../../ui/Button';
import { Badge, Chip, ChipRow } from '../../ui/Chips';
import { Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { Header, Screen } from '../../ui/Screen';
import { Sheet } from '../../ui/Sheet';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'AdminPanel'>;

interface Stats {
  owners: number;
  customers: number;
  stores: number;
  products: number;
  orders: number;
  feedback: Record<string, number>;
}

type Filter = 'all' | FeedbackStatus;

export function AdminPanelScreen({ navigation, route }: Props) {
  const { width } = useWindowDimensions();
  const [code, setCode] = useState(route.params.code);
  const [filter, setFilter] = useState<Filter>('all');
  const [pwOpen, setPwOpen] = useState(false);
  const [newCode, setNewCode] = useState('');
  const [newCode2, setNewCode2] = useState('');
  const [pwError, setPwError] = useState<string | null>(null);
  const [pwBusy, setPwBusy] = useState(false);

  const { data, loading, refreshing, error, reload, refresh } = useData(async () => {
    const [stats, list] = await Promise.all([
      adminCall<Stats>(code, 'stats'),
      adminCall<Feedback[]>(code, 'list_feedback'),
    ]);
    return { stats, list };
  }, [code]);

  const setStatus = async (id: string, status: FeedbackStatus) => {
    try {
      await adminCall(code, 'set_status', { id, status });
      reload();
    } catch (e) {
      toast.error(friendly(e));
    }
  };

  const remove = (f: Feedback) => {
    Alert.alert('Delete this message?', 'It will be removed for good.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await adminCall(code, 'delete_feedback', { id: f.id });
            toast.success('Deleted.');
            reload();
          } catch (e) {
            toast.error(friendly(e));
          }
        },
      },
    ]);
  };

  const list = (data?.list ?? []).filter((f) => filter === 'all' || f.status === filter);

  const exportText = async () => {
    if (!list.length) {
      toast.info('Nothing to export.');
      return;
    }
    const lines = list.map((f) =>
      [
        `[${formatDateTime(f.created_at)}] ${f.type.toUpperCase()} / ${f.priority} / ${f.status}`,
        `From: ${f.role}${f.store_name ? ' (' + f.store_name + ')' : ''}${f.contact_name ? ', ' + f.contact_name : ''}${f.contact_email ? ', ' + f.contact_email : ''}`,
        f.message,
      ].join('\n'),
    );
    try {
      await Share.share({ message: lines.join('\n\n----\n\n'), title: 'AXON suggestions' });
    } catch {
      // the share sheet was dismissed
    }
  };

  const saveCode = async () => {
    setPwError(null);
    if (newCode.length < 8 || newCode.length > 64) {
      setPwError('Use 8 to 64 characters.');
      return;
    }
    if (newCode !== newCode2) {
      setPwError('The two entries do not match.');
      return;
    }
    setPwBusy(true);
    try {
      await adminCall(code, 'change_code', { new_code: newCode });
      setCode(newCode);
      setPwOpen(false);
      setNewCode('');
      setNewCode2('');
      toast.success('Passcode changed. Use the new one next time.');
    } catch (e) {
      setPwError(friendly(e));
    } finally {
      setPwBusy(false);
    }
  };

  const tile = Math.floor((width - 32 - 16) / 3);
  const stats = data?.stats;
  const counts = stats?.feedback ?? {};
  const totalFeedback = Object.values(counts).reduce((a, b) => a + Number(b), 0);

  return (
    <Screen onRefresh={refresh} refreshing={refreshing}>
      <Header
        title="Admin"
        subtitle="Suggestions and feedback"
        right={
          <Pressable onPress={() => navigation.goBack()} hitSlop={8} accessibilityRole="button">
            <Text v="small" color={colors.blueLight}>
              Lock
            </Text>
          </Pressable>
        }
      />

      {loading && !data ? (
        <Loading label="Loading" />
      ) : error && !data ? (
        <ErrorState message={error} onRetry={reload} />
      ) : (
        <>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            <StatTile w={tile} label="Owners" value={stats?.owners ?? 0} color={colors.pinkLight} />
            <StatTile w={tile} label="Customers" value={stats?.customers ?? 0} color={colors.blueLight} />
            <StatTile w={tile} label="Stores" value={stats?.stores ?? 0} color={colors.green} />
            <StatTile w={tile} label="Items" value={stats?.products ?? 0} color={colors.amber} />
            <StatTile w={tile} label="Orders" value={stats?.orders ?? 0} color={colors.purple} />
            <StatTile w={tile} label="Messages" value={totalFeedback} color={colors.text} />
          </View>

          <SectionTitle title="Messages" action="Export" onAction={exportText} />
          <ChipRow>
            <Chip label={`All (${totalFeedback})`} selected={filter === 'all'} onPress={() => setFilter('all')} />
            {FEEDBACK_STATUSES.map((s) => (
              <Chip
                key={s.key}
                label={`${s.label} (${counts[s.key] ?? 0})`}
                selected={filter === s.key}
                color={feedbackStatusColor(s.key)}
                onPress={() => setFilter(s.key)}
              />
            ))}
          </ChipRow>

          <View style={{ height: 10 }} />
          {list.length === 0 ? (
            <EmptyState icon="inbox" title="No messages here" body="New suggestions will show up when people send them." />
          ) : (
            list.map((f) => (
              <Card key={f.id} style={{ marginBottom: 10 }}>
                <Row justify="space-between" style={{ marginBottom: 8 }}>
                  <Row gap={6} wrap style={{ flex: 1 }}>
                    <Badge label={FEEDBACK_TYPES.find((t) => t.key === f.type)?.label ?? f.type} />
                    <Badge
                      label={FEEDBACK_PRIORITIES.find((p) => p.key === f.priority)?.label ?? f.priority}
                      color={f.priority === 'high' ? colors.red : f.priority === 'medium' ? colors.amber : colors.green}
                    />
                  </Row>
                  <Text v="tiny">{timeAgo(f.created_at)}</Text>
                </Row>
                <Text v="bodyMed">{f.message}</Text>
                <Text v="small" style={{ marginTop: 8 }}>
                  From a {f.role}
                  {f.store_name ? ` (${f.store_name})` : ''}
                </Text>
                {f.contact_name || f.contact_email ? (
                  <Row gap={6} wrap style={{ marginTop: 2 }}>
                    {f.contact_name ? <Text v="small">{f.contact_name}</Text> : null}
                    {f.contact_email ? (
                      <Text v="small" color={colors.blueLight} onPress={() => void openLink(`mailto:${f.contact_email}`)}>
                        {f.contact_email}
                      </Text>
                    ) : null}
                  </Row>
                ) : (
                  <Text v="tiny" style={{ marginTop: 2 }}>
                    Sender chose not to share contact details.
                  </Text>
                )}
                <View style={{ height: 10 }} />
                <ChipRow>
                  {FEEDBACK_STATUSES.map((s) => (
                    <Chip
                      key={s.key}
                      label={s.label}
                      selected={f.status === s.key}
                      color={feedbackStatusColor(s.key)}
                      onPress={() => void setStatus(f.id, s.key)}
                    />
                  ))}
                </ChipRow>
                <Pressable
                  onPress={() => remove(f)}
                  accessibilityRole="button"
                  accessibilityLabel="Delete message"
                  style={{ alignSelf: 'flex-end', marginTop: 10, paddingVertical: 4 }}
                >
                  <Text v="small" color={colors.red}>
                    Delete
                  </Text>
                </Pressable>
              </Card>
            ))
          )}

          <SectionTitle title="Security" />
          <Button title="Change admin passcode" icon="key" variant="outline" onPress={() => setPwOpen(true)} />
        </>
      )}

      <Sheet visible={pwOpen} onClose={() => setPwOpen(false)} title="Change passcode">
        <Notice tone="info">
          <Text v="body" color={colors.text}>
            Pick a passcode of 8 to 64 characters that is hard to guess. It is stored as a hash and can not be read back.
          </Text>
        </Notice>
        {pwError ? (
          <Notice tone="bad">
            <Text v="body" color={colors.text}>
              {pwError}
            </Text>
          </Notice>
        ) : null}
        <Input
          label="New passcode"
          icon="key"
          value={newCode}
          onChangeText={setNewCode}
          secure
          autoCapitalize="none"
          autoCorrect={false}
        />
        <Input
          label="Type it again"
          icon="key"
          value={newCode2}
          onChangeText={setNewCode2}
          secure
          autoCapitalize="none"
          autoCorrect={false}
        />
        <Button title="Save passcode" onPress={saveCode} loading={pwBusy} />
        <View style={{ height: 8 }} />
      </Sheet>
    </Screen>
  );
}

function StatTile({ w, label, value, color }: { w: number; label: string; value: number; color: string }) {
  return (
    <View
      style={{
        width: w,
        backgroundColor: colors.card,
        borderWidth: 1,
        borderColor: colors.border,
        borderRadius: radius.lg,
        padding: 12,
      }}
    >
      <Text v="tiny">{label}</Text>
      <Text v="num" color={color} style={{ marginTop: 2 }}>
        {value}
      </Text>
    </View>
  );
}
