import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useEffect, useState } from 'react';
import { requestResetCode, resetWithCode } from '../../api/account';
import { friendly, isValidEmail } from '../../lib/errors';
import { toast } from '../../lib/toast';
import type { RootParams } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Reset'>;

/** Seconds before another code can be asked for (Supabase allows one email a minute). */
const RESEND_SECONDS = 60;

export function ResetScreen({ navigation }: Props) {
  const setRecovering = useSession((s) => s.setRecovering);
  const [stage, setStage] = useState<'email' | 'code' | 'done'>('email');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState(false);
  const [wait, setWait] = useState(0);

  useEffect(() => {
    if (wait <= 0) return;
    const t = setTimeout(() => setWait((w) => w - 1), 1000);
    return () => clearTimeout(t);
  }, [wait]);

  // leaving this screen must never leave the app thinking a reset is half done
  useEffect(() => () => setRecovering(false), [setRecovering]);

  const digits = code.replace(/\D/g, '');

  const sendCode = async (again: boolean) => {
    setError(null);
    setTouched(true);
    if (!isValidEmail(email)) return;
    setBusy(true);
    try {
      await requestResetCode(email);
      setWait(RESEND_SECONDS);
      if (again) {
        toast.success('A new code was sent.');
      } else {
        setTouched(false);
        setStage('code');
      }
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    setError(null);
    setTouched(true);
    if (digits.length < 6 || pw.length < 8 || pw !== pw2) return;
    setBusy(true);
    // while the code is checked the person is briefly logged in; keep them on this screen
    setRecovering(true);
    try {
      await resetWithCode(email, digits, pw);
      setStage('done');
    } catch (e) {
      setError(friendly(e));
    } finally {
      setRecovering(false);
      setBusy(false);
    }
  };

  if (stage === 'done') {
    return (
      <Screen>
        <Header title="Password changed" back={false} />
        <Notice tone="good">
          <Text v="body" color={colors.text}>
            Your password was changed and you were signed out everywhere. Log in with the new password.
          </Text>
        </Notice>
        <Button title="Back to start" onPress={() => navigation.popToTop()} />
      </Screen>
    );
  }

  return (
    <Screen>
      <Header title="Reset password" onBack={() => (stage === 'code' ? setStage('email') : navigation.goBack())} />
      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}

      {stage === 'email' ? (
        <>
          <Text v="body" style={{ marginBottom: 16 }}>
            Enter the email you signed up with. We will email you a 6-digit code.
          </Text>
          <Input
            label="Email"
            icon="mail"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            placeholder="you@example.com"
            error={touched && !isValidEmail(email) ? 'Enter a valid email address.' : null}
            onSubmitEditing={() => void sendCode(false)}
          />
          <Button title="Send code" onPress={() => void sendCode(false)} loading={busy} />
        </>
      ) : (
        <>
          <Notice tone="info" icon="mail">
            <Text v="body" color={colors.text}>
              If {email.trim()} has an AXON account, a code is on its way. It can take a minute. Check your spam folder too.
            </Text>
          </Notice>
          <Input
            label="Code from the email"
            icon="key"
            value={code}
            onChangeText={setCode}
            keyboardType="number-pad"
            maxLength={10}
            autoCapitalize="none"
            autoComplete="one-time-code"
            placeholder="6-digit code"
            error={touched && digits.length < 6 ? 'Enter the code from the email.' : null}
          />
          <Input
            label="New password"
            icon="lock"
            value={pw}
            onChangeText={setPw}
            secure
            autoCapitalize="none"
            placeholder="At least 8 characters"
            error={touched && pw.length < 8 ? 'Use at least 8 characters.' : null}
          />
          <Input
            label="Confirm new password"
            icon="lock"
            value={pw2}
            onChangeText={setPw2}
            secure
            autoCapitalize="none"
            placeholder="Type it again"
            error={touched && pw !== pw2 ? 'The two passwords do not match.' : null}
          />
          <Button title="Reset password" onPress={() => void submit()} loading={busy} />
          <Button
            title={wait > 0 ? `Send a new code in ${wait}s` : 'Send a new code'}
            variant="ghost"
            onPress={() => void sendCode(true)}
            disabled={wait > 0 || busy}
            style={{ marginTop: 8 }}
          />
        </>
      )}
    </Screen>
  );
}
