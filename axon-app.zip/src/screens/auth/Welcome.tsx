import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React from 'react';
import { Pressable, View } from 'react-native';
import { SLOGAN } from '../../lib/content';
import type { RootParams } from '../../nav/types';
import { colors, fonts, radius, tint } from '../../theme';
import type { Role } from '../../types';
import { Button } from '../../ui/Button';
import { Icon, type IconName } from '../../ui/Icon';
import { Logo } from '../../ui/Logo';
import { Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Welcome'>;

export function WelcomeScreen({ navigation }: Props) {
  const go = (name: 'Login' | 'Signup', role: Role) => navigation.navigate(name, { role });
  return (
    <Screen>
      <View style={{ alignItems: 'center', marginTop: 26, marginBottom: 26 }}>
        <Logo size={84} pulse />
        <Text
          style={{ fontFamily: fonts.head, fontSize: 34, letterSpacing: 10, color: colors.white, marginTop: 14, marginLeft: 10 }}
        >
          AXON
        </Text>
        <Text
          style={{ fontFamily: fonts.ui, fontSize: 11, letterSpacing: 3.5, color: colors.off, marginTop: 6, textTransform: 'uppercase' }}
        >
          {SLOGAN}
        </Text>
      </View>

      <Text v="h1" center style={{ marginBottom: 6 }}>
        How will you use AXON?
      </Text>
      <Text v="body" center style={{ marginBottom: 20 }}>
        Business owners and customers have separate logins.
      </Text>

      <RoleCard
        icon="briefcase"
        title="I run a business"
        body="Shop, farm, company or supermarket. Add your items, record sales and costs, and see your profit."
        color={colors.pink}
        primaryLabel="Log in as business"
        onPrimary={() => go('Login', 'owner')}
        secondaryLabel="Create a business account"
        onSecondary={() => go('Signup', 'owner')}
      />
      <RoleCard
        icon="shopping-cart"
        title="I am a customer"
        body="Browse stores, save favourites, fill a cart and place orders that reach the store at once."
        color={colors.blueLight}
        primaryLabel="Log in as customer"
        onPrimary={() => go('Login', 'customer')}
        secondaryLabel="Create a customer account"
        onSecondary={() => go('Signup', 'customer')}
      />

      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 18, marginTop: 8, flexWrap: 'wrap' }}>
        {(
          [
            ['About', 'About'],
            ['Contact', 'Contact'],
            ['Privacy', 'Privacy'],
            ['Admin', 'AdminGate'],
          ] as const
        ).map(([label, route]) => (
          <Pressable key={label} onPress={() => navigation.navigate(route)} hitSlop={8} accessibilityRole="link">
            <Text v="small" color={colors.muted}>
              {label}
            </Text>
          </Pressable>
        ))}
      </View>
    </Screen>
  );
}

function RoleCard({
  icon,
  title,
  body,
  color,
  primaryLabel,
  onPrimary,
  secondaryLabel,
  onSecondary,
}: {
  icon: IconName;
  title: string;
  body: string;
  color: string;
  primaryLabel: string;
  onPrimary: () => void;
  secondaryLabel: string;
  onSecondary: () => void;
}) {
  return (
    <View
      style={{
        backgroundColor: colors.card,
        borderRadius: radius.xl,
        borderWidth: 1,
        borderColor: tint(color, 0.35),
        padding: 16,
        marginBottom: 14,
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 }}>
        <View
          style={{
            width: 44,
            height: 44,
            borderRadius: radius.md,
            backgroundColor: tint(color, 0.14),
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name={icon} size={22} color={color} />
        </View>
        <Text v="h2" style={{ flex: 1 }}>
          {title}
        </Text>
      </View>
      <Text v="body" style={{ marginBottom: 14 }}>
        {body}
      </Text>
      <Button title={primaryLabel} onPress={onPrimary} variant={color === colors.pink ? 'primary' : 'blue'} />
      <Button title={secondaryLabel} onPress={onSecondary} variant="ghost" size="sm" style={{ marginTop: 6 }} />
    </View>
  );
}
