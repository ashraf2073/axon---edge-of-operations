import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { signUp } from '../../api/account';
import { friendly, isValidEmail } from '../../lib/errors';
import type { RootParams } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Chips';
import { Checkbox, Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';
import { usePrefs } from '../../state/prefs';

type Props = NativeStackScreenProps<RootParams, 'Signup'>;

export function SignupScreen({ navigation, route }: Props) {
  const { role } = route.params;
  const owner = role === 'owner';
  const signIn = useSession((s) => s.signIn);
  const syncConsent = usePrefs((s) => s.syncToAccount);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [agree, setAgree] = useState(false);
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmEmail, setConfirmEmail] = useState(false);

  const errs = {
    name: name.trim().length < 2 ? 'Enter your full name.' : null,
    email: !isValidEmail(email) ? 'Enter a valid email address.' : null,
    phone: phone.replace(/\D/g, '').length < 7 ? 'Enter a valid phone number.' : null,
    password: password.length < 8 ? 'Use at least 8 characters.' : null,
    confirm: confirm !== password ? 'The two passwords do not match.' : null,
  };
  const bad = Object.values(errs).some(Boolean) || !agree;

  const submit = async () => {
    setTouched(true);
    setError(null);
    if (bad) return;
    setBusy(true);
    try {
      const { needsConfirmation } = await signUp({ email, password, fullName: name, phone, role });
      if (needsConfirmation) {
        setConfirmEmail(true);
      } else {
        await signIn(role, email, password);
        void syncConsent();
      }
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  if (confirmEmail) {
    return (
      <Screen>
        <Header title="Check your email" back={false} />
        <Notice tone="good">
          <Text v="body" color={colors.text}>
            We sent a confirmation link to {email.trim()}. Open it, then come back and log in.
          </Text>
        </Notice>
        <Button title="Go to login" onPress={() => navigation.replace('Login', { role })} />
      </Screen>
    );
  }

  const show = (k: keyof typeof errs) => (touched ? errs[k] : null);

  return (
    <Screen>
      <Header title={owner ? 'Create business account' : 'Create customer account'} onBack={() => navigation.goBack()} />
      <View style={{ marginBottom: 16 }}>
        <Badge label={owner ? 'Store owner' : 'Customer'} color={owner ? colors.pink : colors.blueLight} />
        <Text v="body" style={{ marginTop: 10 }}>
          {owner
            ? 'Next you will set up your business profile. If you ever forget your password, we email you a code to reset it.'
            : 'Then you can start shopping. If you ever forget your password, we email you a code to reset it.'}
        </Text>
      </View>

      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}

      <Input label="Full name" icon="user" value={name} onChangeText={setName} autoCapitalize="words" placeholder="Your name" error={show('name')} />
      <Input
        label="Email"
        icon="mail"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        autoComplete="email"
        keyboardType="email-address"
        placeholder="you@example.com"
        error={show('email')}
      />
      <Input
        label="Phone number"
        icon="phone"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
        autoComplete="tel"
        placeholder="07XX XXX XXX"
        error={show('phone')}
      />
      <Input
        label="Password"
        icon="lock"
        value={password}
        onChangeText={setPassword}
        secure
        autoCapitalize="none"
        autoComplete="new-password"
        placeholder="At least 8 characters"
        error={show('password')}
      />
      <Input
        label="Confirm password"
        icon="lock"
        value={confirm}
        onChangeText={setConfirm}
        secure
        autoCapitalize="none"
        autoComplete="new-password"
        placeholder="Type it again"
        error={show('confirm')}
      />

      <Checkbox checked={agree} onChange={setAgree} error={touched}>
        <Text v="body">
          I agree to the{' '}
          <Text v="body" color={colors.blueLight} onPress={() => navigation.navigate('Privacy')}>
            Privacy Policy
          </Text>
          . My account and business data are stored securely in the cloud so they work on every device.
        </Text>
      </Checkbox>
      {touched && !agree ? (
        <Text v="small" color={colors.red} style={{ marginTop: -8, marginBottom: 12 }}>
          Please accept to continue.
        </Text>
      ) : null}

      <Button title="Create account" onPress={submit} loading={busy} />
      <Pressable onPress={() => navigation.replace('Login', { role })} hitSlop={8} style={{ alignSelf: 'center', marginTop: 16 }}>
        <Text v="small">
          Already have an account? <Text v="small" color={colors.blueLight}>Log in</Text>
        </Text>
      </Pressable>
    </Screen>
  );
}
