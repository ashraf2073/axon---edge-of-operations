import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { friendly, isValidEmail } from '../../lib/errors';
import type { RootParams } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Badge } from '../../ui/Chips';
import { Screen, Header } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Login'>;

export function LoginScreen({ navigation, route }: Props) {
  const { role } = route.params;
  const signIn = useSession((s) => s.signIn);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState(false);

  const owner = role === 'owner';
  const emailErr = touched && !isValidEmail(email) ? 'Enter a valid email address.' : null;
  const passErr = touched && !password ? 'Enter your password.' : null;

  const submit = async () => {
    setTouched(true);
    setError(null);
    if (!isValidEmail(email) || !password) return;
    setBusy(true);
    try {
      await signIn(role, email, password);
      // the app switches to the right home screen by itself
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <Header title={owner ? 'Business login' : 'Customer login'} onBack={() => navigation.goBack()} />
      <View style={{ marginBottom: 18 }}>
        <Badge label={owner ? 'Store owner' : 'Customer'} color={owner ? colors.pink : colors.blueLight} />
        <Text v="h1" style={{ marginTop: 10 }}>
          Welcome back
        </Text>
        <Text v="body" style={{ marginTop: 4 }}>
          {owner
            ? 'Log in to manage your items, sales, costs and profit.'
            : 'Log in to browse stores, save favourites and place orders.'}
        </Text>
      </View>

      {error ? <Notice tone="bad">{<Text v="body" color={colors.text}>{error}</Text>}</Notice> : null}

      <Input
        label="Email"
        icon="mail"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        autoComplete="email"
        keyboardType="email-address"
        textContentType="emailAddress"
        placeholder="you@example.com"
        error={emailErr}
      />
      <Input
        label="Password"
        icon="lock"
        value={password}
        onChangeText={setPassword}
        secure
        autoCapitalize="none"
        autoComplete="current-password"
        textContentType="password"
        placeholder="Your password"
        error={passErr}
        onSubmitEditing={submit}
        returnKeyType="go"
      />

      <Pressable onPress={() => navigation.navigate('Reset')} hitSlop={8} style={{ alignSelf: 'flex-end', marginBottom: 18 }}>
        <Text v="small" color={colors.blueLight}>
          Forgot password?
        </Text>
      </Pressable>

      <Button title="Log in" onPress={submit} loading={busy} />

      <View style={{ height: 1, backgroundColor: colors.border, marginVertical: 22 }} />

      <Text v="body" center>
        {owner ? 'New business on AXON?' : 'New to AXON?'}
      </Text>
      <Button
        title={owner ? 'Create a business account' : 'Create a customer account'}
        variant="outline"
        onPress={() => navigation.replace('Signup', { role })}
        style={{ marginTop: 10 }}
      />
      <Button
        title={owner ? 'I am a customer instead' : 'I run a business instead'}
        variant="ghost"
        size="sm"
        onPress={() => navigation.replace('Login', { role: owner ? 'customer' : 'owner' })}
        style={{ marginTop: 6 }}
      />
    </Screen>
  );
}
