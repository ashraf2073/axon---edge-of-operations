import React, { useState } from 'react';
import { View } from 'react-native';
import { CONTACT } from '../../config';
import { SLOGAN } from '../../lib/content';
import { openLink } from '../../lib/links';
import { useSession } from '../../state/session';
import { usePrefs } from '../../state/prefs';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Checkbox, Notice } from '../../ui/Fields';
import { Card } from '../../ui/Layout';
import { Logo } from '../../ui/Logo';
import { Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';
import { PrivacyBody } from '../shared/Privacy';
import { Sheet } from '../../ui/Sheet';

/** Shown until the Supabase address and key are filled in. */
export function SetupRequiredScreen() {
  return (
    <Screen>
      <View style={{ alignItems: 'center', marginVertical: 24 }}>
        <Logo size={72} />
      </View>
      <Text v="h1" center>
        One setup step left
      </Text>
      <Text v="body" center style={{ marginTop: 8, marginBottom: 18 }}>
        This copy of AXON is not connected to a backend yet.
      </Text>
      <Card>
        <Text v="bodyMed">1. Create a free project at supabase.com.</Text>
        <Text v="bodyMed" style={{ marginTop: 8 }}>
          2. Open SQL Editor, paste the file supabase/schema.sql and press Run.
        </Text>
        <Text v="bodyMed" style={{ marginTop: 8 }}>
          3. Copy the Project URL and the anon key from Project Settings, API.
        </Text>
        <Text v="bodyMed" style={{ marginTop: 8 }}>
          4. Paste them into src/config.ts, then build the app again.
        </Text>
      </Card>
      <Text v="small" center style={{ marginTop: 16 }}>
        The README in the project folder has the full steps.
      </Text>
    </Screen>
  );
}

/** The account could not be loaded (usually no internet). */
export function AccountErrorScreen() {
  const message = useSession((s) => s.accountError);
  const load = useSession((s) => s.loadAccount);
  const signOut = useSession((s) => s.signOut);
  const [busy, setBusy] = useState(false);
  return (
    <Screen>
      <View style={{ alignItems: 'center', marginVertical: 24 }}>
        <Logo size={72} />
      </View>
      <Text v="h1" center>
        Cannot reach your account
      </Text>
      <Notice tone="warn">
        <Text v="body" color={colors.text}>
          {message ?? 'Check your internet connection and try again.'}
        </Text>
      </Notice>
      <Button
        title="Try again"
        loading={busy}
        onPress={async () => {
          setBusy(true);
          try {
            await load({ force: true });
          } catch {
            // the message above updates itself
          } finally {
            setBusy(false);
          }
        }}
      />
      <Button title="Sign out" variant="ghost" onPress={() => void signOut()} style={{ marginTop: 8 }} />
    </Screen>
  );
}

/** Signed in, but there is no AXON profile for this login. */
export function ProfileMissingScreen() {
  const signOut = useSession((s) => s.signOut);
  return (
    <Screen>
      <View style={{ alignItems: 'center', marginVertical: 24 }}>
        <Logo size={72} />
      </View>
      <Text v="h1" center>
        No AXON profile found
      </Text>
      <Text v="body" center style={{ marginTop: 8, marginBottom: 18 }}>
        This login exists, but it was not created in AXON. Sign out and create an AXON account, or log in with a different email.
      </Text>
      <Button title="Sign out" onPress={() => void signOut()} />
      <Button
        title="Contact support"
        variant="ghost"
        onPress={() => void openLink(CONTACT.emailUrl)}
        style={{ marginTop: 8 }}
      />
    </Screen>
  );
}

/** First launch: explains where data lives and asks for agreement. */
export function ConsentScreen() {
  const accept = usePrefs((s) => s.accept);
  const [agree, setAgree] = useState(false);
  const [contact, setContact] = useState(false);
  const [showPolicy, setShowPolicy] = useState(false);
  const [touched, setTouched] = useState(false);

  return (
    <Screen>
      <View style={{ alignItems: 'center', marginTop: 18, marginBottom: 10 }}>
        <Logo size={64} />
        <Text v="label" style={{ marginTop: 10 }}>
          {SLOGAN}
        </Text>
      </View>
      <Text v="h1" center style={{ marginBottom: 8 }}>
        Before you start
      </Text>
      <Text v="body" center style={{ marginBottom: 18 }}>
        AXON keeps your account, your business records and your orders in the cloud so they work on every device and so customers can see what a store sells.
      </Text>

      <Card style={{ marginBottom: 16 }}>
        <Text v="bodyMed">What this means</Text>
        <Text v="body" style={{ marginTop: 6 }}>
          Your data is stored on secure servers, sent over encrypted connections and protected by access rules so only you (and, for orders, the store involved) can see it. We never sell it, show ads, or add ghost fees.
        </Text>
        <Button
          title="Read the full Privacy Policy"
          variant="ghost"
          size="sm"
          full={false}
          onPress={() => setShowPolicy(true)}
          style={{ marginTop: 8 }}
        />
      </Card>

      <Checkbox checked={agree} onChange={setAgree} error={touched}>
        <Text v="body" color={colors.text}>
          I have read the Privacy Policy and agree that AXON stores my account and business data in the cloud. (Required)
        </Text>
      </Checkbox>
      {touched && !agree ? (
        <Text v="small" color={colors.red} style={{ marginTop: -8, marginBottom: 12 }}>
          You need to agree to use AXON.
        </Text>
      ) : null}
      <Checkbox checked={contact} onChange={setContact}>
        <Text v="body" color={colors.text}>
          When I send feedback, include my name and email so the team can reply. (Optional)
        </Text>
      </Checkbox>

      <Button
        title="Agree and continue"
        onPress={() => {
          setTouched(true);
          if (agree) void accept(contact);
        }}
      />

      <Sheet visible={showPolicy} onClose={() => setShowPolicy(false)} title="Privacy Policy">
        <PrivacyBody />
      </Sheet>
    </Screen>
  );
}
