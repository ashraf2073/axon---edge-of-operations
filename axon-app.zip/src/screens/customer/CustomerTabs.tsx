import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react';
import type { CustomerTabParams } from '../../nav/types';
import { useCart } from '../../state/cart';
import { useCustomerOrdersRealtime } from '../../state/realtime';
import { useSession } from '../../state/session';
import { colors, fonts } from '../../theme';
import { Icon, type IconName } from '../../ui/Icon';
import { CartScreen } from './Cart';
import { MeScreen } from './Me';
import { OrdersScreen } from './Orders';
import { ShopScreen } from './Shop';
import { WishlistScreen } from './Wishlist';

const Tab = createBottomTabNavigator<CustomerTabParams>();

const TABS: { name: keyof CustomerTabParams; title: string; icon: IconName }[] = [
  { name: 'Shop', title: 'Shop', icon: 'shopping-bag' },
  { name: 'Wishlist', title: 'Wishlist', icon: 'heart' },
  { name: 'Cart', title: 'Cart', icon: 'shopping-cart' },
  { name: 'Orders', title: 'Orders', icon: 'package' },
  { name: 'Me', title: 'Me', icon: 'user' },
];

const SCREENS = {
  Shop: ShopScreen,
  Wishlist: WishlistScreen,
  Cart: CartScreen,
  Orders: OrdersScreen,
  Me: MeScreen,
} as const;

export function CustomerTabs() {
  const uid = useSession((s) => s.profile?.id);
  const cartCount = useCart((s) => s.items.length);
  useCustomerOrdersRealtime(uid);

  return (
    <Tab.Navigator
      initialRouteName="Shop"
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.pink,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: { backgroundColor: colors.dk, borderTopColor: colors.border, borderTopWidth: 1 },
        tabBarLabelStyle: { fontFamily: fonts.ui, fontSize: 10 },
        tabBarBadgeStyle: { backgroundColor: colors.pink, color: colors.white, fontFamily: fonts.bodyBold, fontSize: 10 },
        sceneStyle: { backgroundColor: colors.bg },
      }}
    >
      {TABS.map((t) => (
        <Tab.Screen
          key={t.name}
          name={t.name}
          component={SCREENS[t.name]}
          options={{
            title: t.title,
            tabBarBadge: t.name === 'Cart' && cartCount > 0 ? cartCount : undefined,
            tabBarIcon: ({ color, size }) => <Icon name={t.icon} size={size} color={color} />,
          }}
        />
      ))}
    </Tab.Navigator>
  );
}
