import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { Alert, Pressable, View } from 'react-native';
import { money, num } from '../../lib/format';
import type { CustomerNav } from '../../nav/types';
import { cartTotal, useCart } from '../../state/cart';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Notice } from '../../ui/Fields';
import { Icon } from '../../ui/Icon';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { ProductImage, QtyStepper } from '../../ui/Product';
import { Screen } from '../../ui/Screen';
import { EmptyState } from '../../ui/States';
import { Text } from '../../ui/Text';

export function CartScreen() {
  const nav = useNavigation<CustomerNav>();
  const store = useCart((s) => s.store);
  const items = useCart((s) => s.items);
  const total = useCart(cartTotal);
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const clear = useCart((s) => s.clear);
  const cur = store?.currency ?? 'KES';

  const confirmClear = () =>
    Alert.alert('Empty your cart?', 'All items will be removed.', [
      { text: 'Keep them', style: 'cancel' },
      { text: 'Empty cart', style: 'destructive', onPress: clear },
    ]);

  return (
    <Screen
      bottom={false}
      footer={
        items.length > 0 ? (
          <View>
            <Row justify="space-between" style={{ marginBottom: 10 }}>
              <Text v="body">Total to pay</Text>
              <Text v="num" color={colors.pinkLight}>
                {money(total, cur)}
              </Text>
            </Row>
            <Button title="Checkout" icon="arrow-right" onPress={() => nav.navigate('Checkout')} />
          </View>
        ) : undefined
      }
    >
      <View style={{ marginTop: 10, marginBottom: 14 }}>
        <Text v="h1">Your cart</Text>
        {store ? <Text v="small">From {store.name}</Text> : null}
      </View>

      {items.length === 0 ? (
        <EmptyState
          icon="shopping-cart"
          title="Your cart is empty"
          body="Find something you like and tap the plus button on its card."
          actionLabel="Start shopping"
          onAction={() => nav.navigate('Shop')}
        />
      ) : (
        <>
          {items.map((i) => (
            <Card key={i.productId} style={{ marginBottom: 10 }}>
              <Row gap={12} align="flex-start">
                <ProductImage uri={i.imageUrl} style={{ width: 72, height: 72, borderRadius: 12 }} />
                <View style={{ flex: 1 }}>
                  <Text v="bodyMed" numberOfLines={2}>
                    {i.name}
                  </Text>
                  <Text v="small">
                    {money(i.price, cur)} per {i.unit}
                  </Text>
                  <View style={{ height: 8 }} />
                  <QtyStepper value={i.qty} onChange={(n) => setQty(i.productId, n)} min={0.001} max={i.maxQty} />
                </View>
                <View style={{ alignItems: 'flex-end', justifyContent: 'space-between', alignSelf: 'stretch' }}>
                  <Pressable
                    onPress={() => remove(i.productId)}
                    hitSlop={10}
                    accessibilityRole="button"
                    accessibilityLabel={`Remove ${i.name}`}
                  >
                    <Icon name="trash-2" size={18} color={colors.muted} />
                  </Pressable>
                  <Text v="numSm" color={colors.pinkLight}>
                    {money(Math.round(i.price * i.qty * 100) / 100, cur)}
                  </Text>
                </View>
              </Row>
            </Card>
          ))}

          <SectionTitle title="Summary" />
          <Card>
            <Row justify="space-between" style={{ marginBottom: 6 }}>
              <Text v="body">
                Items ({items.length}, {num(items.reduce((t, i) => t + i.qty, 0), 3)} units)
              </Text>
              <Text v="bodyMed">{money(total, cur)}</Text>
            </Row>
            <Row justify="space-between" style={{ marginBottom: 6 }}>
              <Text v="body">AXON fees</Text>
              <Text v="bodyMed" color={colors.green}>
                None
              </Text>
            </Row>
            <Row justify="space-between">
              <Text v="h3">Total</Text>
              <Text v="num" color={colors.pinkLight}>
                {money(total, cur)}
              </Text>
            </Row>
          </Card>
          <View style={{ height: 10 }} />
          <Notice tone="info">
            <Text v="body" color={colors.text}>
              You pay the store directly. Pickup or delivery is arranged with the store after you order.
            </Text>
          </Notice>
          <Button title="Empty cart" variant="ghost" size="sm" onPress={confirmClear} />
        </>
      )}
    </Screen>
  );
}
