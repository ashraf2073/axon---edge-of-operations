import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { getStore, placeOrder } from '../../api/customer';
import { PAY_METHODS } from '../../lib/content';
import { friendly } from '../../lib/errors';
import { money, num } from '../../lib/format';
import { openLink } from '../../lib/links';
import { useData } from '../../lib/useData';
import type { RootParams } from '../../nav/types';
import { useBiz } from '../../state/biz';
import { cartTotal, useCart } from '../../state/cart';
import { useSession } from '../../state/session';
import { colors, radius, tint } from '../../theme';
import type { PayMethod } from '../../types';
import { Button } from '../../ui/Button';
import { Notice } from '../../ui/Fields';
import { Icon } from '../../ui/Icon';
import { Input } from '../../ui/Input';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { ProductImage } from '../../ui/Product';
import { Header, Screen } from '../../ui/Screen';
import { EmptyState } from '../../ui/States';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Checkout'>;

export function CheckoutScreen({ navigation }: Props) {
  const profile = useSession((s) => s.profile);
  const cartStore = useCart((s) => s.store);
  const items = useCart((s) => s.items);
  const total = useCart(cartTotal);
  const clear = useCart((s) => s.clear);
  const bump = useBiz((s) => s.bump);
  const store = useData(() => getStore(cartStore!.id), [cartStore?.id], !!cartStore);

  const [name, setName] = useState(profile?.full_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [method, setMethod] = useState<PayMethod>('mpesa');
  const [notes, setNotes] = useState('');
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!cartStore || items.length === 0) {
    return (
      <Screen>
        <Header title="Checkout" />
        <EmptyState icon="shopping-cart" title="Your cart is empty" actionLabel="Back to shopping" onAction={() => navigation.popToTop()} />
      </Screen>
    );
  }

  const cur = cartStore.currency;
  const errs = {
    name: name.trim().length < 2 ? 'Enter your name.' : null,
    phone: phone.replace(/\D/g, '').length < 7 ? 'Enter a phone number the store can reach.' : null,
  };
  const bad = Object.values(errs).some(Boolean);

  const submit = async () => {
    setTouched(true);
    setError(null);
    if (bad) return;
    setBusy(true);
    try {
      const order = await placeOrder({
        storeId: cartStore.id,
        items: items.map((i) => ({ productId: i.productId, qty: i.qty })),
        payMethod: method,
        name: name.trim(),
        phone: phone.trim(),
        notes: notes.trim(),
      });
      clear();
      bump();
      navigation.replace('OrderDone', {
        code: order.code,
        total: Number(order.total),
        currency: order.currency,
        storeName: cartStore.name,
        payMethod: method,
      });
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen
      footer={
        <View>
          <Row justify="space-between" style={{ marginBottom: 10 }}>
            <View>
              <Text v="body">Total to pay</Text>
              <Text v="tiny" color={colors.green}>
                No extra fees
              </Text>
            </View>
            <Text v="num" color={colors.pinkLight}>
              {money(total, cur)}
            </Text>
          </Row>
          <Button title="Place order" icon="check" onPress={submit} loading={busy} />
        </View>
      }
    >
      <Header title="Checkout" subtitle={cartStore.name} />

      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}

      <SectionTitle title="Your details" style={{ marginTop: 4 }} />
      <Input label="Your name" icon="user" value={name} onChangeText={setName} autoCapitalize="words" error={touched ? errs.name : null} />
      <Input
        label="Phone number"
        icon="phone"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
        error={touched ? errs.phone : null}
        hint="The store calls or messages this number about your order."
      />

      <SectionTitle title="Payment method" />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {PAY_METHODS.map((m) => {
          const on = m.key === method;
          return (
            <Pressable
              key={m.key}
              onPress={() => setMethod(m.key)}
              accessibilityRole="radio"
              accessibilityState={{ selected: on }}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 8,
                paddingHorizontal: 14,
                height: 46,
                borderRadius: radius.md,
                borderWidth: 1.5,
                borderColor: on ? colors.pink : colors.border2,
                backgroundColor: on ? tint(colors.pink, 0.12) : colors.dk,
              }}
            >
              <Icon name={on ? 'check-circle' : 'circle'} size={17} color={on ? colors.pink : colors.muted} />
              <Text v="bodyMed" color={on ? colors.text : colors.off}>
                {m.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <View style={{ height: 12 }} />
      <Notice tone="info">
        <Text v="body" color={colors.text}>
          {store.data?.payment_info
            ? store.data.payment_info
            : 'The store will tell you how to pay when it contacts you.'}
        </Text>
        <Text v="small" style={{ marginTop: 6 }}>
          You pay the store directly. AXON never handles your money and adds no fees.
        </Text>
      </Notice>
      {store.data?.phone ? (
        <Pressable onPress={() => void openLink(`tel:${store.data!.phone}`)} accessibilityRole="link" hitSlop={6} style={{ marginBottom: 10 }}>
          <Row gap={6}>
            <Icon name="phone" size={14} color={colors.blueLight} />
            <Text v="small" color={colors.blueLight}>
              Call the store: {store.data.phone}
            </Text>
          </Row>
        </Pressable>
      ) : null}

      <Input
        label="Note for the store (optional)"
        value={notes}
        onChangeText={setNotes}
        multiline
        maxLength={500}
        placeholder="Pickup time, delivery place, anything the store should know"
      />

      <SectionTitle title="Order summary" />
      <Card>
        {items.map((i) => (
          <Row key={i.productId} gap={10} style={{ marginBottom: 10 }}>
            <ProductImage uri={i.imageUrl} style={{ width: 44, height: 44, borderRadius: 10 }} />
            <View style={{ flex: 1 }}>
              <Text v="bodyMed" numberOfLines={1}>
                {i.name}
              </Text>
              <Text v="tiny">
                {num(i.qty, 3)} {i.unit} at {money(i.price, cur)}
              </Text>
            </View>
            <Text v="bold">{money(Math.round(i.price * i.qty * 100) / 100, cur)}</Text>
          </Row>
        ))}
        <Row justify="space-between" style={{ paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border }}>
          <Text v="h3">Total</Text>
          <Text v="num" color={colors.pinkLight}>
            {money(total, cur)}
          </Text>
        </Row>
      </Card>
      <View style={{ height: 8 }} />
    </Screen>
  );
}
