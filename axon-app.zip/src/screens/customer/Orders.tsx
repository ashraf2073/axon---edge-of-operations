import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { cancelMyOrder, listMyOrders } from '../../api/customer';
import { ORDER_STATUS_LABEL, payLabel } from '../../lib/content';
import { friendly } from '../../lib/errors';
import { formatDateTime, money, num } from '../../lib/format';
import { openLink } from '../../lib/links';
import { toast } from '../../lib/toast';
import { useData, useRefetchOnFocus } from '../../lib/useData';
import type { CustomerNav } from '../../nav/types';
import { useBiz } from '../../state/biz';
import { useSession } from '../../state/session';
import { colors, tint } from '../../theme';
import type { Order, OrderStatus } from '../../types';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Chips';
import { Icon } from '../../ui/Icon';
import { Card, Row } from '../../ui/Layout';
import { ProductImage } from '../../ui/Product';
import { Screen } from '../../ui/Screen';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

const STATUS_COLOR: Record<OrderStatus, string> = {
  placed: colors.amber,
  processing: colors.blueLight,
  complete: colors.green,
  cancelled: colors.muted,
};

const STEPS: { key: OrderStatus; label: string }[] = [
  { key: 'placed', label: 'Placed' },
  { key: 'processing', label: 'Accepted' },
  { key: 'complete', label: 'Complete' },
];

export function OrdersScreen() {
  const nav = useNavigation<CustomerNav>();
  const profile = useSession((s) => s.profile);
  const fmt = profile?.date_format ?? 'DD/MM/YYYY';
  const version = useBiz((s) => s.version);
  const bump = useBiz((s) => s.bump);
  const q = useData(() => listMyOrders(profile!.id), [profile?.id, version], !!profile);
  useRefetchOnFocus(q.reload);
  const [busy, setBusy] = useState<string | null>(null);

  const cancel = (o: Order) =>
    Alert.alert('Cancel this order?', 'The store has not accepted it yet, so you can cancel it now.', [
      { text: 'Keep order', style: 'cancel' },
      {
        text: 'Cancel order',
        style: 'destructive',
        onPress: async () => {
          setBusy(o.id);
          try {
            await cancelMyOrder(o.id);
            bump();
            toast.success('Order cancelled.');
          } catch (e) {
            toast.error(friendly(e));
          } finally {
            setBusy(null);
          }
        },
      },
    ]);

  return (
    <Screen bottom={false} onRefresh={q.refresh} refreshing={q.refreshing}>
      <View style={{ marginTop: 10, marginBottom: 14 }}>
        <Text v="h1">My orders</Text>
        <Text v="small">Updates appear here as the store works on them</Text>
      </View>

      {q.loading && !q.data ? (
        <Loading />
      ) : q.error && !q.data ? (
        <ErrorState message={q.error} onRetry={q.reload} />
      ) : (q.data ?? []).length === 0 ? (
        <EmptyState
          icon="package"
          title="No orders yet"
          body="When you place an order it shows up here, and you can follow it from placed to complete."
          actionLabel="Start shopping"
          onAction={() => nav.navigate('Shop')}
        />
      ) : (
        q.data!.map((o) => {
          const c = STATUS_COLOR[o.status];
          const stepIndex = STEPS.findIndex((s) => s.key === o.status);
          return (
            <Card key={o.id} accent={c} style={{ marginBottom: 12 }}>
              <Row justify="space-between" style={{ marginBottom: 4 }}>
                <Text v="h3">{o.code}</Text>
                <Badge label={ORDER_STATUS_LABEL[o.status]} color={c} />
              </Row>
              <Text v="small" numberOfLines={1}>
                {o.store?.name ?? 'Store'}
              </Text>
              <Text v="tiny">{formatDateTime(o.created_at, fmt)}</Text>

              {o.status !== 'cancelled' ? (
                <Row gap={6} style={{ marginTop: 12 }}>
                  {STEPS.map((s, i) => {
                    const reached = i <= stepIndex;
                    return (
                      <View key={s.key} style={{ flex: 1 }}>
                        <View
                          style={{
                            height: 4,
                            borderRadius: 2,
                            backgroundColor: reached ? colors.green : colors.border2,
                          }}
                        />
                        <Text v="tiny" color={reached ? colors.text : colors.muted} style={{ marginTop: 4 }}>
                          {s.label}
                        </Text>
                      </View>
                    );
                  })}
                </Row>
              ) : null}

              <View style={{ marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: colors.border }}>
                {(o.items ?? []).map((it) => (
                  <Row key={it.id} gap={10} style={{ marginBottom: 8 }}>
                    <ProductImage uri={it.image_url} style={{ width: 40, height: 40, borderRadius: 8 }} />
                    <View style={{ flex: 1 }}>
                      <Text v="bodyMed" numberOfLines={1}>
                        {it.name}
                      </Text>
                      <Text v="tiny">
                        {num(it.qty, 3)} {it.unit} at {money(it.price, o.currency)}
                      </Text>
                    </View>
                    <Text v="bold">{money(it.price * it.qty, o.currency)}</Text>
                  </Row>
                ))}
                <Row justify="space-between" style={{ marginTop: 4 }}>
                  <Text v="small">
                    Pay by {payLabel(o.pay_method)}
                    {o.status === 'cancelled' ? '' : o.payment_status === 'approved' ? ', approved by the store' : ', awaiting store approval'}
                  </Text>
                  <Text v="numSm" color={colors.pinkLight}>
                    {money(o.total, o.currency)}
                  </Text>
                </Row>
              </View>

              {o.store?.phone ? (
                <Pressable
                  onPress={() => void openLink(`tel:${o.store!.phone}`)}
                  accessibilityRole="link"
                  hitSlop={6}
                  style={{ marginTop: 10 }}
                >
                  <Row gap={6}>
                    <Icon name="phone" size={14} color={colors.blueLight} />
                    <Text v="small" color={colors.blueLight}>
                      Call the store: {o.store.phone}
                    </Text>
                  </Row>
                </Pressable>
              ) : null}

              {o.status === 'placed' ? (
                <Button
                  title="Cancel order"
                  variant="danger"
                  size="sm"
                  onPress={() => cancel(o)}
                  loading={busy === o.id}
                  style={{ marginTop: 12 }}
                />
              ) : null}
              {o.status === 'processing' ? (
                <Text v="small" style={{ marginTop: 10, backgroundColor: tint(colors.blueLight, 0.08), padding: 8, borderRadius: 8 }}>
                  The store accepted your order. To change it, call the store.
                </Text>
              ) : null}
            </Card>
          );
        })
      )}
    </Screen>
  );
}
