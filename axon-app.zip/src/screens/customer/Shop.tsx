import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { searchProducts, searchStores } from '../../api/customer';
import { PRODUCT_KINDS, storeKindLabel } from '../../lib/content';
import { firstName } from '../../lib/format';
import { useData } from '../../lib/useData';
import { useDebounced } from '../../lib/useDebounced';
import type { CustomerNav } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors } from '../../theme';
import type { ProductKind } from '../../types';
import { Chip, ChipRow, Segmented } from '../../ui/Chips';
import { Icon } from '../../ui/Icon';
import { Input } from '../../ui/Input';
import { Card, Row } from '../../ui/Layout';
import { ProductGrid } from '../../ui/ProductGrid';
import { ProductImage } from '../../ui/Product';
import { Screen } from '../../ui/Screen';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

type Tab = 'stores' | 'items';

export function ShopScreen() {
  const nav = useNavigation<CustomerNav>();
  const profile = useSession((s) => s.profile);
  const [tab, setTab] = useState<Tab>('stores');
  const [search, setSearch] = useState('');
  const [kind, setKind] = useState<'all' | ProductKind>('all');
  const dq = useDebounced(search.trim(), 350);

  const stores = useData(() => searchStores(dq), [dq], tab === 'stores');
  const items = useData(() => searchProducts(dq), [dq], tab === 'items');

  const visible = useMemo(
    () => (items.data ?? []).filter((p) => p.store && (kind === 'all' || p.kind === kind)),
    [items.data, kind],
  );
  const q = tab === 'stores' ? stores : items;

  return (
    <Screen bottom={false} onRefresh={q.refresh} refreshing={q.refreshing}>
      <View style={{ marginTop: 10, marginBottom: 14 }}>
        <Text v="label">Welcome, {firstName(profile?.full_name ?? '') || 'friend'}</Text>
        <Text v="h1">What are you looking for?</Text>
      </View>

      <Input
        icon="search"
        value={search}
        onChangeText={setSearch}
        placeholder={tab === 'stores' ? 'Search stores by name, place or code' : 'Search items'}
        returnKeyType="search"
        containerStyle={{ marginBottom: 10 }}
      />
      <Segmented<Tab>
        value={tab}
        onChange={setTab}
        options={[
          { key: 'stores', label: 'Stores' },
          { key: 'items', label: 'All items' },
        ]}
        style={{ marginBottom: 12 }}
      />

      {tab === 'items' ? (
        <>
          <ChipRow>
            <Chip label="All" selected={kind === 'all'} onPress={() => setKind('all')} />
            {PRODUCT_KINDS.map((k) => (
              <Chip key={k.key} label={k.label} selected={kind === k.key} onPress={() => setKind(k.key)} />
            ))}
          </ChipRow>
          <View style={{ height: 10 }} />
        </>
      ) : null}

      {q.loading && !q.data ? (
        <Loading label="Looking around" />
      ) : q.error && !q.data ? (
        <ErrorState message={q.error} onRetry={q.reload} />
      ) : tab === 'stores' ? (
        (stores.data ?? []).length === 0 ? (
          <EmptyState
            icon="shopping-bag"
            title={dq ? 'No stores match' : 'No stores yet'}
            body={dq ? 'Try another name, place or store code.' : 'Stores that join AXON will show up here.'}
          />
        ) : (
          stores.data!.map((s) => (
            <Card key={s.id} onPress={() => nav.navigate('Storefront', { storeId: s.id })} style={{ marginBottom: 10 }}>
              <Row gap={12}>
                <ProductImage uri={s.logo_url} style={{ width: 62, height: 62, borderRadius: 14 }} />
                <View style={{ flex: 1 }}>
                  <Text v="h3" numberOfLines={1}>
                    {s.name}
                  </Text>
                  <Text v="small" numberOfLines={1}>
                    {storeKindLabel(s.kind)}
                    {s.location ? ` / ${s.location}` : ''}
                  </Text>
                  <Text v="tiny">
                    {s.products?.[0]?.count ?? 0} items / code {s.code}
                  </Text>
                </View>
                <Icon name="chevron-right" size={18} color={colors.muted} />
              </Row>
            </Card>
          ))
        )
      ) : visible.length === 0 ? (
        <EmptyState
          icon="package"
          title={dq ? 'No items match' : 'No items yet'}
          body={dq ? 'Try a different word.' : 'Items that stores publish will show up here.'}
        />
      ) : (
        <ProductGrid
          items={visible.map((p) => ({
            product: p,
            store: { id: p.store!.id, name: p.store!.name, currency: p.store!.currency },
            showStore: true,
          }))}
          onOpen={(p) => nav.navigate('ProductDetail', { productId: p.id })}
        />
      )}
    </Screen>
  );
}
