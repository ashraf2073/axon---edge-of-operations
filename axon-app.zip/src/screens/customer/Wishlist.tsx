import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { View } from 'react-native';
import { listWishlist } from '../../api/customer';
import { useData, useRefetchOnFocus } from '../../lib/useData';
import type { CustomerNav } from '../../nav/types';
import { useWishlist } from '../../state/wishlist';
import { ProductGrid } from '../../ui/ProductGrid';
import { Screen } from '../../ui/Screen';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

export function WishlistScreen() {
  const nav = useNavigation<CustomerNav>();
  const version = useWishlist((s) => s.version);
  const q = useData(() => listWishlist(), [version]);
  useRefetchOnFocus(q.reload);
  const rows = (q.data ?? []).filter((p) => p.store);

  return (
    <Screen bottom={false} onRefresh={q.refresh} refreshing={q.refreshing}>
      <View style={{ marginTop: 10, marginBottom: 14 }}>
        <Text v="h1">Wishlist</Text>
        <Text v="small">Things you want to come back to</Text>
      </View>
      {q.loading && !q.data ? (
        <Loading />
      ) : q.error && !q.data ? (
        <ErrorState message={q.error} onRetry={q.reload} />
      ) : rows.length === 0 ? (
        <EmptyState
          icon="heart"
          title="Nothing saved yet"
          body="Tap the heart on any item to keep it here."
          actionLabel="Browse stores"
          onAction={() => nav.navigate('Shop')}
        />
      ) : (
        <ProductGrid
          items={rows.map((p) => ({
            product: p,
            store: { id: p.store!.id, name: p.store!.name, currency: p.store!.currency },
            showStore: true,
          }))}
          onOpen={(p) => nav.navigate('ProductDetail', { productId: p.id })}
        />
      )}
    </Screen>
  );
}
