import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Pressable, View, useWindowDimensions } from 'react-native';
import { getProduct } from '../../api/customer';
import { productKindLabel } from '../../lib/content';
import { money } from '../../lib/format';
import { MAX_CONTENT } from '../../lib/layout';
import { useData } from '../../lib/useData';
import type { RootParams } from '../../nav/types';
import { addToCart } from '../../state/cartActions';
import { useWishlist } from '../../state/wishlist';
import { colors, radius } from '../../theme';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Chips';
import { Icon } from '../../ui/Icon';
import { Card, Row } from '../../ui/Layout';
import { ProductImage, QtyStepper, stockInfo } from '../../ui/Product';
import { Header, Screen } from '../../ui/Screen';
import { ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'ProductDetail'>;

export function ProductDetailScreen({ navigation, route }: Props) {
  const { productId } = route.params;
  const { width } = useWindowDimensions();
  const q = useData(() => getProduct(productId), [productId]);
  const wished = useWishlist((s) => !!s.ids[productId]);
  const toggle = useWishlist((s) => s.toggle);
  const [qty, setQty] = useState(1);

  const p = q.data;
  const s = p ? stockInfo(p) : null;
  const store = p?.store ?? null;
  const imgSize = Math.min(width - 32, MAX_CONTENT);
  const max = p?.track_stock ? p.stock : null;
  const cartStore = store ? { id: store.id, name: store.name, currency: store.currency } : null;
  const total = p ? Math.round(p.price * qty * 100) / 100 : 0;

  return (
    <Screen
      footer={
        p && cartStore && s ? (
          <View>
            <Row justify="space-between" style={{ marginBottom: 10 }}>
              <Text v="body">Total for {qty} {p.unit}</Text>
              <Text v="num" color={colors.pinkLight}>
                {money(total, cartStore.currency)}
              </Text>
            </Row>
            <Row gap={10}>
              <View style={{ flex: 1 }}>
                <Button
                  title="Add to cart"
                  icon="shopping-cart"
                  variant="outline"
                  disabled={s.out}
                  onPress={() => addToCart(cartStore, p, qty)}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Button
                  title="Buy now"
                  disabled={s.out}
                  onPress={() =>
                    addToCart(cartStore, p, qty, () => navigation.navigate('CustomerTabs', { screen: 'Cart' }))
                  }
                />
              </View>
            </Row>
          </View>
        ) : undefined
      }
    >
      <Header title="Item" />
      {q.loading && !p ? (
        <Loading />
      ) : q.error && !p ? (
        <ErrorState message={q.error} onRetry={q.reload} />
      ) : p && s ? (
        <View style={{ alignItems: 'center' }}>
          <View style={{ width: '100%', maxWidth: MAX_CONTENT }}>
            <View style={{ borderRadius: radius.xl, overflow: 'hidden', alignSelf: 'center' }}>
              <ProductImage uri={p.image_url} style={{ width: imgSize, height: imgSize }} />
              <Pressable
                onPress={() => void toggle(p.id)}
                hitSlop={8}
                accessibilityRole="button"
                accessibilityLabel={wished ? 'Remove from wishlist' : 'Add to wishlist'}
                style={{
                  position: 'absolute',
                  top: 12,
                  right: 12,
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: 'rgba(6,6,15,0.62)',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="heart" size={20} color={wished ? colors.pink : colors.white} />
              </Pressable>
            </View>

            <View style={{ marginTop: 16 }}>
              <Text style={{ fontFamily: 'Syne_800ExtraBold', fontSize: 30, color: colors.pinkLight }}>
                {money(p.price, store?.currency ?? 'KES')}
                <Text v="body"> / {p.unit}</Text>
              </Text>
              <Text v="h2" style={{ marginTop: 6 }}>
                {p.name}
              </Text>
              <Row gap={8} wrap style={{ marginTop: 8 }}>
                <Badge label={productKindLabel(p.kind)} />
                <Badge label={p.category} color={colors.purple} />
                <Badge label={s.label} color={s.color} />
              </Row>
              <Text v="small" style={{ marginTop: 8 }}>
                The price shown is the price you pay. AXON adds no extra fees.
              </Text>
            </View>

            {store ? (
              <Card
                onPress={() => navigation.navigate('Storefront', { storeId: store.id })}
                style={{ marginTop: 16 }}
              >
                <Row gap={12}>
                  <ProductImage uri={store.logo_url} style={{ width: 44, height: 44, borderRadius: 12 }} />
                  <View style={{ flex: 1 }}>
                    <Text v="tiny">Sold by</Text>
                    <Text v="bodyMed" numberOfLines={1}>
                      {store.name}
                    </Text>
                  </View>
                  <Icon name="chevron-right" size={18} color={colors.muted} />
                </Row>
              </Card>
            ) : null}

            {p.description ? (
              <View style={{ marginTop: 16 }}>
                <Text v="label" style={{ marginBottom: 6 }}>
                  About this item
                </Text>
                <Text v="body">{p.description}</Text>
              </View>
            ) : null}

            {!s.out ? (
              <View style={{ marginTop: 18 }}>
                <Text v="label" style={{ marginBottom: 8 }}>
                  How many {p.unit}
                </Text>
                <QtyStepper value={qty} onChange={setQty} min={0.001} max={max} />
              </View>
            ) : (
              <Text v="bodyMed" color={colors.red} style={{ marginTop: 18 }}>
                This item is sold out right now.
              </Text>
            )}
            <View style={{ height: 8 }} />
          </View>
        </View>
      ) : null}
    </Screen>
  );
}
