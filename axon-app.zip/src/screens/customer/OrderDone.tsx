import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useCallback, useEffect, useState } from 'react';
import { View } from 'react-native';
import { autoLogout } from '../../lib/autoLogout';
import { payLabel } from '../../lib/content';
import { money } from '../../lib/format';
import type { RootParams } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors, tint } from '../../theme';
import { Button } from '../../ui/Button';
import { Notice } from '../../ui/Fields';
import { Icon } from '../../ui/Icon';
import { Card, Row } from '../../ui/Layout';
import { Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'OrderDone'>;

export function OrderDoneScreen({ route }: Props) {
  const { code, total, currency, storeName, payMethod } = route.params;
  const signOut = useSession((s) => s.signOut);
  const [left, setLeft] = useState(autoLogout.seconds);
  const [leaving, setLeaving] = useState(false);

  const logOut = useCallback(() => {
    setLeaving(true);
    // this phone only: the customer's other devices stay signed in
    void signOut('local');
  }, [signOut]);

  useEffect(() => {
    if (left <= 0) {
      logOut();
      return;
    }
    const t = setTimeout(() => setLeft((n) => n - 1), 1000);
    return () => clearTimeout(t);
  }, [left, logOut]);

  return (
    <Screen>
      <View style={{ alignItems: 'center', marginTop: 36, marginBottom: 20 }}>
        <View
          style={{
            width: 84,
            height: 84,
            borderRadius: 42,
            backgroundColor: tint(colors.green, 0.14),
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name="check" size={42} color={colors.green} />
        </View>
        <Text v="h1" center style={{ marginTop: 18 }}>
          Submitted
        </Text>
        <Text v="body" center style={{ marginTop: 6, maxWidth: 320 }}>
          {storeName} has your order. Your payment by {payLabel(payMethod)} is now waiting for the store to approve it. The store will
          contact you on your phone.
        </Text>
      </View>

      <Card style={{ marginBottom: 14 }}>
        <Row justify="space-between" style={{ marginBottom: 8 }}>
          <Text v="body">Order number</Text>
          <Text v="h3" color={colors.pinkLight}>
            {code}
          </Text>
        </Row>
        <Row justify="space-between" style={{ marginBottom: 8 }}>
          <Text v="body">Store</Text>
          <Text v="bodyMed">{storeName}</Text>
        </Row>
        <Row justify="space-between" style={{ marginBottom: 8 }}>
          <Text v="body">Payment</Text>
          <Text v="bodyMed">{payLabel(payMethod)}, awaiting approval</Text>
        </Row>
        <Row justify="space-between">
          <Text v="body">Total to pay</Text>
          <Text v="numSm" color={colors.pinkLight}>
            {money(total, currency)}
          </Text>
        </Row>
      </Card>

      <Notice tone="info" icon="lock">
        <Text v="body" color={colors.text}>
          {leaving
            ? 'Logging you out.'
            : `Write down your order number. For your safety you will be logged out in ${left} seconds, so nobody else can use your account on this phone.`}
        </Text>
      </Notice>
      <Text v="small" center color={colors.muted} style={{ marginBottom: 12 }}>
        Log in again any time to follow your order.
      </Text>
      <Button title="Log out now" icon="log-out" onPress={logOut} loading={leaving} />
    </Screen>
  );
}
