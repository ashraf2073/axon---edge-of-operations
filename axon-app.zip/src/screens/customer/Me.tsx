import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { Alert, View } from 'react-native';
import { initials } from '../../lib/format';
import type { CustomerNav } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors, fonts, radius, tint } from '../../theme';
import { Badge } from '../../ui/Chips';
import { MenuRow } from '../../ui/Fields';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

export function MeScreen() {
  const nav = useNavigation<CustomerNav>();
  const profile = useSession((s) => s.profile);
  const signOut = useSession((s) => s.signOut);

  const confirmSignOut = () =>
    Alert.alert('Sign out?', 'You will need your email and password to log in again.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', onPress: () => void signOut() },
    ]);

  return (
    <Screen bottom={false}>
      <View style={{ marginTop: 10, marginBottom: 14 }}>
        <Text v="h1">Me</Text>
      </View>

      {profile ? (
        <Card style={{ marginBottom: 6 }}>
          <Row gap={14}>
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: radius.pill,
                backgroundColor: tint(colors.blueLight, 0.16),
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text style={{ fontFamily: fonts.head, fontSize: 20, color: colors.blueLight }}>{initials(profile.full_name)}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text v="h3" numberOfLines={1}>
                {profile.full_name}
              </Text>
              <Text v="small" numberOfLines={1}>
                {profile.email}
              </Text>
              <Text v="small" numberOfLines={1}>
                {profile.phone}
              </Text>
            </View>
            <Badge label="Customer" color={colors.blueLight} />
          </Row>
        </Card>
      ) : null}

      <SectionTitle title="Account" />
      <MenuRow icon="settings" label="Settings" sub="Profile and password" onPress={() => nav.navigate('Settings')} />
      <MenuRow icon="package" label="My orders" onPress={() => nav.navigate('Orders')} color={colors.amber} />
      <MenuRow icon="heart" label="Wishlist" onPress={() => nav.navigate('Wishlist')} color={colors.pink} />

      <SectionTitle title="Help" />
      <MenuRow icon="edit-3" label="Suggestions and feedback" onPress={() => nav.navigate('Suggestions')} color={colors.green} />
      <MenuRow icon="message-circle" label="Contact us" onPress={() => nav.navigate('Contact')} color={colors.green} />
      <MenuRow icon="info" label="About AXON" onPress={() => nav.navigate('About')} />
      <MenuRow icon="file-text" label="Privacy Policy" onPress={() => nav.navigate('Privacy')} color={colors.purple} />

      <SectionTitle title="Session" />
      <MenuRow icon="log-out" label="Sign out" onPress={confirmSignOut} color={colors.off} right={<View />} />
    </Screen>
  );
}
