import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { getStore, listStoreProducts } from '../../api/customer';
import { storeKindLabel } from '../../lib/content';
import { money } from '../../lib/format';
import { openLink } from '../../lib/links';
import { useData } from '../../lib/useData';
import type { RootParams } from '../../nav/types';
import { cartTotal, useCart } from '../../state/cart';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Chip, ChipRow } from '../../ui/Chips';
import { Icon } from '../../ui/Icon';
import { Input } from '../../ui/Input';
import { Card, Row } from '../../ui/Layout';
import { ProductGrid } from '../../ui/ProductGrid';
import { ProductImage } from '../../ui/Product';
import { Header, Screen } from '../../ui/Screen';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Storefront'>;

export function StorefrontScreen({ navigation, route }: Props) {
  const { storeId } = route.params;
  const store = useData(() => getStore(storeId), [storeId]);
  const items = useData(() => listStoreProducts(storeId), [storeId]);
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('All');

  const inCart = useCart((s) => (s.store?.id === storeId ? s.items.length : 0));
  const total = useCart((s) => (s.store?.id === storeId ? cartTotal(s) : 0));

  const all = items.data ?? [];
  const categories = useMemo(() => ['All', ...Array.from(new Set(all.map((p) => p.category))).sort()], [all]);
  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return all.filter(
      (p) => (cat === 'All' || p.category === cat) && (!s || p.name.toLowerCase().includes(s) || p.description.toLowerCase().includes(s)),
    );
  }, [all, search, cat]);

  const s = store.data;

  return (
    <Screen
      onRefresh={() => {
        store.refresh();
        items.reload();
      }}
      refreshing={store.refreshing}
      footer={
        inCart > 0 && s ? (
          <Button
            title={`View cart (${inCart})  ${money(total, s.currency)}`}
            icon="shopping-cart"
            onPress={() => navigation.navigate('CustomerTabs', { screen: 'Cart' })}
          />
        ) : undefined
      }
    >
      <Header title={s?.name ?? 'Store'} subtitle={s ? storeKindLabel(s.kind) : undefined} />

      {store.loading && !s ? (
        <Loading label="Opening the store" />
      ) : store.error && !s ? (
        <ErrorState message={store.error} onRetry={store.reload} />
      ) : s ? (
        <>
          <Card style={{ marginBottom: 14 }}>
            <Row gap={14} align="flex-start">
              <ProductImage uri={s.logo_url} style={{ width: 72, height: 72, borderRadius: 16 }} />
              <View style={{ flex: 1 }}>
                <Text v="h2" numberOfLines={2}>
                  {s.name}
                </Text>
                {s.location ? (
                  <Row gap={6}>
                    <Icon name="map-pin" size={13} color={colors.muted} />
                    <Text v="small">{s.location}</Text>
                  </Row>
                ) : null}
                {s.phone ? (
                  <Pressable onPress={() => void openLink(`tel:${s.phone}`)} accessibilityRole="link" hitSlop={6}>
                    <Row gap={6}>
                      <Icon name="phone" size={13} color={colors.blueLight} />
                      <Text v="small" color={colors.blueLight}>
                        {s.phone}
                      </Text>
                    </Row>
                  </Pressable>
                ) : null}
              </View>
            </Row>
            {s.description ? (
              <Text v="body" style={{ marginTop: 12 }}>
                {s.description}
              </Text>
            ) : null}
            {s.payment_info ? (
              <View style={{ marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: colors.border }}>
                <Text v="label" style={{ marginBottom: 4 }}>
                  How to pay
                </Text>
                <Text v="body">{s.payment_info}</Text>
              </View>
            ) : null}
          </Card>

          {items.loading && !items.data ? (
            <Loading label="Loading items" />
          ) : items.error && !items.data ? (
            <ErrorState message={items.error} onRetry={items.reload} />
          ) : all.length === 0 ? (
            <EmptyState icon="package" title="Nothing for sale yet" body="This store has not published any items. Check back soon." />
          ) : (
            <>
              <Input icon="search" value={search} onChangeText={setSearch} placeholder={`Search ${s.name}`} containerStyle={{ marginBottom: 8 }} />
              {categories.length > 2 ? (
                <ChipRow>
                  {categories.map((c) => (
                    <Chip key={c} label={c} selected={cat === c} onPress={() => setCat(c)} />
                  ))}
                </ChipRow>
              ) : null}
              <View style={{ height: 10 }} />
              {filtered.length === 0 ? (
                <Text v="body" center color={colors.muted} style={{ marginTop: 20 }}>
                  Nothing matches your search.
                </Text>
              ) : (
                <ProductGrid
                  items={filtered.map((p) => ({ product: p, store: { id: s.id, name: s.name, currency: s.currency } }))}
                  onOpen={(p) => navigation.navigate('ProductDetail', { productId: p.id })}
                />
              )}
            </>
          )}
        </>
      ) : null}
    </Screen>
  );
}
