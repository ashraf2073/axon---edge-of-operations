import { useRoute, type RouteProp } from '@react-navigation/native';
import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { approvePayment, deleteSale, setOrderStatus } from '../../api/owner';
import { ORDER_STATUS_LABEL, payLabel } from '../../lib/content';
import { customerKey, groupCustomers } from '../../lib/customers';
import { friendly } from '../../lib/errors';
import { formatDateTime, money, num, timeAgo } from '../../lib/format';
import { openLink } from '../../lib/links';
import { toast } from '../../lib/toast';
import { discardQueued, isQueuedRow, listProducts, listSales, listStoreOrders } from '../../lib/ownerData';
import { useData } from '../../lib/useData';
import type { OwnerTabParams } from '../../nav/types';
import { useBiz } from '../../state/biz';
import { useActiveStore, useSession } from '../../state/session';
import { colors, radius } from '../../theme';
import type { Currency, DateFormat, Order, OrderStatus, Product, Sale } from '../../types';
import { Button } from '../../ui/Button';
import { Badge, Chip, ChipRow, Segmented } from '../../ui/Chips';
import { Notice } from '../../ui/Fields';
import { Icon } from '../../ui/Icon';
import { Input } from '../../ui/Input';
import { Card, Row } from '../../ui/Layout';
import { OwnerFrame } from '../../ui/OwnerFrame';
import { ProductImage, stockInfo } from '../../ui/Product';
import { Sheet } from '../../ui/Sheet';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';
import { SellSheet } from './SellSheet';

type Seg = 'log' | 'orders' | 'customers';
type OrderFilter = 'open' | 'complete' | 'cancelled' | 'all';

const STATUS_COLOR: Record<OrderStatus, string> = {
  placed: colors.pink,
  processing: colors.blueLight,
  complete: colors.green,
  cancelled: colors.muted,
};

export function SalesScreen() {
  const route = useRoute<RouteProp<OwnerTabParams, 'Sales'>>();
  const store = useActiveStore();
  const fmt = useSession((s) => s.profile?.date_format ?? 'DD/MM/YYYY');
  const version = useBiz((s) => s.version);
  const bump = useBiz((s) => s.bump);

  const [seg, setSeg] = useState<Seg>(route.params?.segment ?? 'log');
  useEffect(() => {
    if (route.params?.segment) setSeg(route.params.segment);
  }, [route.params]);

  const [limit, setLimit] = useState(50);
  const [orderFilter, setOrderFilter] = useState<OrderFilter>('open');
  const [pick, setPick] = useState(false);
  const [sell, setSell] = useState<Product | null>(null);
  const [busyOrder, setBusyOrder] = useState<string | null>(null);

  const sales = useData(() => listSales(store!.id, limit), [store?.id, version, limit], !!store);
  const orders = useData(() => listStoreOrders(store!.id), [store?.id, version], !!store);

  if (!store) return null;
  const cur = store.currency;
  const newCount = (orders.data ?? []).filter((o) => o.status === 'placed').length;
  const shownTotal = (sales.data ?? []).reduce((t, s) => t + Number(s.total), 0);

  const removeSale = (s: Sale) => {
    if (isQueuedRow(s.id)) {
      Alert.alert('Remove this saved sale?', `${s.product_name} x ${num(s.qty, 3)} has not been sent yet. Removing it means it will never be recorded.`, [
        { text: 'Keep it', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            void discardQueued(s.id).then(() => toast.success('Removed.'));
          },
        },
      ]);
      return;
    }
    Alert.alert('Delete this sale?', `${s.product_name} x ${num(s.qty, 3)}. The stock goes back on the shelf.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteSale(s.id);
            bump();
            toast.success('Sale deleted.');
          } catch (e) {
            toast.error(friendly(e));
          }
        },
      },
    ]);
  };

  const changeStatus = async (o: Order, status: Exclude<OrderStatus, 'placed'>) => {
    setBusyOrder(o.id);
    try {
      await setOrderStatus(o.id, status);
      bump();
      toast.success(`Order ${o.code} is now ${ORDER_STATUS_LABEL[status].toLowerCase()}.`);
    } catch (e) {
      toast.error(friendly(e));
    } finally {
      setBusyOrder(null);
    }
  };

  const approve = async (o: Order) => {
    setBusyOrder(o.id);
    try {
      await approvePayment(o.id);
      bump();
      toast.success(`Payment approved for order ${o.code}. It is now being prepared.`);
    } catch (e) {
      toast.error(friendly(e));
    } finally {
      setBusyOrder(null);
    }
  };

  const confirmCancel = (o: Order) => {
    Alert.alert(
      'Cancel this order?',
      o.status === 'complete'
        ? 'The sale is removed from your revenue and the stock goes back on the shelf.'
        : 'The stock goes back on the shelf and the customer sees it is cancelled.',
      [
        { text: 'Keep order', style: 'cancel' },
        { text: 'Cancel order', style: 'destructive', onPress: () => void changeStatus(o, 'cancelled') },
      ],
    );
  };

  const customers = useMemo(() => groupCustomers(orders.data ?? []), [orders.data]);
  const returning = new Set(customers.filter((c) => c.orders >= 2).map((c) => c.key));

  const orderList = (orders.data ?? []).filter((o) =>
    orderFilter === 'all'
      ? true
      : orderFilter === 'open'
        ? o.status === 'placed' || o.status === 'processing'
        : o.status === orderFilter,
  );

  return (
    <OwnerFrame
      onRefresh={() => {
        sales.refresh();
        orders.reload();
      }}
      refreshing={sales.refreshing}
    >
      <Row justify="space-between" style={{ marginBottom: 12 }}>
        <Text v="h1">Sales</Text>
        {seg === 'log' ? <Button title="Record sale" icon="plus" size="sm" full={false} onPress={() => setPick(true)} /> : null}
      </Row>
      <Segmented<Seg>
        value={seg}
        onChange={setSeg}
        options={[
          { key: 'log', label: 'Sales log' },
          { key: 'orders', label: 'Orders', badge: newCount },
          { key: 'customers', label: 'Customers' },
        ]}
        style={{ marginBottom: 14 }}
      />

      {seg === 'log' ? (
        sales.loading && !sales.data ? (
          <Loading label="Loading sales" />
        ) : sales.error && !sales.data ? (
          <ErrorState message={sales.error} onRetry={sales.reload} />
        ) : (sales.data ?? []).length === 0 ? (
          <EmptyState
            icon="shopping-bag"
            title="No sales yet"
            body="When a customer buys something, tap Record sale, pick the item and the quantity. Stock and revenue update at once."
            actionLabel="Record a sale"
            onAction={() => setPick(true)}
          />
        ) : (
          <>
            <Text v="small" style={{ marginBottom: 10 }}>
              {sales.data!.length} sales shown, worth {money(shownTotal, cur)}
            </Text>
            {sales.data!.map((s) => (
              <Card key={s.id} accent={s.pending ? colors.amber : s.order_id ? colors.blueLight : colors.green} style={{ marginBottom: 8 }}>
                <Row justify="space-between" align="flex-start">
                  <View style={{ flex: 1 }}>
                    <Text v="bodyMed" numberOfLines={2}>
                      {s.product_name}
                    </Text>
                    <Text v="small">
                      {num(s.qty, 3)} {s.unit} at {money(s.unit_price, cur)}
                    </Text>
                  </View>
                  <Text v="numSm" color={colors.green}>
                    {money(s.total, cur)}
                  </Text>
                </Row>
                <Row justify="space-between" style={{ marginTop: 6 }}>
                  <View style={{ flex: 1 }}>
                    <Text v="tiny" numberOfLines={1}>
                      {s.txn_id} / {formatDateTime(s.sold_at, fmt)}
                    </Text>
                    {s.customer ? (
                      <Text v="tiny" numberOfLines={1}>
                        {s.customer}
                      </Text>
                    ) : null}
                    {s.note ? (
                      <Text v="tiny" numberOfLines={2}>
                        {s.note}
                      </Text>
                    ) : null}
                  </View>
                  {s.order_id ? (
                    <Badge label="Online order" color={colors.blueLight} />
                  ) : (
                    <Pressable
                      onPress={() => removeSale(s)}
                      hitSlop={10}
                      accessibilityRole="button"
                      accessibilityLabel="Delete sale"
                      style={{ padding: 4 }}
                    >
                      <Icon name="trash-2" size={17} color={colors.muted} />
                    </Pressable>
                  )}
                </Row>
              </Card>
            ))}
            {sales.data!.length >= limit ? (
              <Button title="Load more" variant="outline" size="sm" onPress={() => setLimit((n) => n + 50)} style={{ marginTop: 8 }} />
            ) : null}
          </>
        )
      ) : orders.loading && !orders.data ? (
        <Loading label="Loading orders" />
      ) : orders.error && !orders.data ? (
        <ErrorState message={orders.error} onRetry={orders.reload} />
      ) : seg === 'customers' ? (
        customers.length === 0 ? (
          <EmptyState
            icon="users"
            title="No customers yet"
            body="When someone orders from your store in the AXON app, they appear here. A customer who orders again is recognised as returning, because each customer has their own AXON account."
          />
        ) : (
          <>
            <Text v="small" style={{ marginBottom: 10 }}>
              {customers.length} {customers.length === 1 ? 'customer has' : 'customers have'} ordered from this store. Customers of other stores are never shown here.
            </Text>
            {customers.map((c) => (
              <Card key={c.key} accent={c.orders >= 2 ? colors.green : colors.blueLight} style={{ marginBottom: 8 }}>
                <Row justify="space-between" align="flex-start">
                  <View style={{ flex: 1 }}>
                    <Text v="bodyMed" numberOfLines={1}>
                      {c.name}
                    </Text>
                    {c.phone ? (
                      <Pressable onPress={() => void openLink(`tel:${c.phone}`)} accessibilityRole="link" hitSlop={6}>
                        <Text v="small" color={colors.blueLight}>
                          {c.phone}
                        </Text>
                      </Pressable>
                    ) : null}
                  </View>
                  <Badge label={c.orders >= 2 ? 'Returning' : 'New'} color={c.orders >= 2 ? colors.green : colors.blueLight} />
                </Row>
                <Text v="tiny" style={{ marginTop: 6 }}>
                  {c.orders} {c.orders === 1 ? 'order' : 'orders'} / {money(c.spent, cur)} completed / last order {timeAgo(c.lastAt)}
                  {c.open > 0 ? ` / ${c.open} open` : ''}
                </Text>
              </Card>
            ))}
          </>
        )
      ) : (
        <>
          <ChipRow>
            {(
              [
                ['open', 'Open'],
                ['complete', 'Complete'],
                ['cancelled', 'Cancelled'],
                ['all', 'All'],
              ] as const
            ).map(([k, label]) => (
              <Chip key={k} label={label} selected={orderFilter === k} onPress={() => setOrderFilter(k)} />
            ))}
          </ChipRow>
          <View style={{ height: 10 }} />
          {orderList.length === 0 ? (
            <EmptyState
              icon="inbox"
              title="No orders here"
              body="Orders placed by customers in the AXON app show up here the moment they arrive."
            />
          ) : (
            orderList.map((o) => (
              <OrderCard
                key={o.id}
                o={o}
                fmt={fmt}
                returning={returning.has(customerKey(o))}
                busy={busyOrder === o.id}
                onApprovePayment={() => void approve(o)}
                onComplete={() => void changeStatus(o, 'complete')}
                onCancel={() => confirmCancel(o)}
              />
            ))
          )}
        </>
      )}

      <PickItemSheet
        visible={pick}
        storeId={store.id}
        onClose={() => setPick(false)}
        onPick={(p) => {
          setPick(false);
          setSell(p);
        }}
        currency={cur}
      />
      <SellSheet product={sell} store={store} onClose={() => setSell(null)} />
    </OwnerFrame>
  );
}

function OrderCard({
  o,
  fmt,
  returning,
  busy,
  onApprovePayment,
  onComplete,
  onCancel,
}: {
  o: Order;
  fmt: DateFormat;
  returning: boolean;
  busy: boolean;
  onApprovePayment: () => void;
  onComplete: () => void;
  onCancel: () => void;
}) {
  const c = STATUS_COLOR[o.status];
  const awaiting = (o.status === 'placed' || o.status === 'processing') && o.payment_status === 'awaiting';
  return (
    <Card accent={c} style={{ marginBottom: 10 }}>
      <Row justify="space-between" style={{ marginBottom: 6 }}>
        <Text v="h3">{o.code}</Text>
        <Badge label={ORDER_STATUS_LABEL[o.status]} color={c} />
      </Row>
      <Text v="tiny">
        {formatDateTime(o.created_at, fmt)} ({timeAgo(o.created_at)})
      </Text>

      <View style={{ marginTop: 10 }}>
        <Row gap={8}>
          <Text v="bodyMed">{o.customer_name}</Text>
          {returning ? <Badge label="Returning customer" color={colors.green} /> : null}
        </Row>
        {o.customer_phone ? (
          <Pressable onPress={() => void openLink(`tel:${o.customer_phone}`)} accessibilityRole="link" hitSlop={6}>
            <Row gap={6}>
              <Icon name="phone" size={14} color={colors.blueLight} />
              <Text v="small" color={colors.blueLight}>
                {o.customer_phone}
              </Text>
            </Row>
          </Pressable>
        ) : null}
      </View>

      <View style={{ marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border }}>
        {(o.items ?? []).map((it) => (
          <Row key={it.id} gap={10} style={{ marginBottom: 8 }}>
            <ProductImage uri={it.image_url} style={{ width: 36, height: 36, borderRadius: 8 }} />
            <View style={{ flex: 1 }}>
              <Text v="bodyMed" numberOfLines={1}>
                {it.name}
              </Text>
              <Text v="tiny">
                {num(it.qty, 3)} {it.unit} at {money(it.price, o.currency)}
              </Text>
            </View>
            <Text v="bold">{money(it.price * it.qty, o.currency)}</Text>
          </Row>
        ))}
        <Row justify="space-between" style={{ marginTop: 4 }}>
          <Text v="small">Pay by {payLabel(o.pay_method)}</Text>
          <Text v="numSm" color={colors.green}>
            {money(o.total, o.currency)}
          </Text>
        </Row>
        {o.notes ? (
          <Text v="small" style={{ marginTop: 6 }}>
            Note: {o.notes}
          </Text>
        ) : null}
      </View>

      {awaiting ? (
        <View style={{ marginTop: 12 }}>
          <Notice tone="warn" icon="clock">
            <Text v="body" color={colors.text}>
              Payment awaiting your approval: {payLabel(o.pay_method)}, {money(o.total, o.currency)}. Make sure you have received it, then
              approve.
            </Text>
          </Notice>
        </View>
      ) : o.payment_status === 'approved' && o.status !== 'cancelled' ? (
        <View style={{ marginTop: 10, alignItems: 'flex-start' }}>
          <Badge label="Payment approved" color={colors.green} />
        </View>
      ) : null}

      {o.status === 'placed' || o.status === 'processing' || o.status === 'complete' ? (
        <Row gap={8} style={{ marginTop: 12 }} wrap>
          {awaiting ? (
            <View style={{ flex: 1, minWidth: 140 }}>
              <Button title="Approve payment" size="sm" variant="blue" icon="check" onPress={onApprovePayment} loading={busy} />
            </View>
          ) : null}
          {o.status === 'processing' && !awaiting ? (
            <View style={{ flex: 1, minWidth: 110 }}>
              <Button title="Complete" size="sm" variant="success" onPress={onComplete} loading={busy} />
            </View>
          ) : null}
          <View style={{ flex: 1, minWidth: 110 }}>
            <Button title="Cancel order" size="sm" variant="danger" onPress={onCancel} disabled={busy} />
          </View>
        </Row>
      ) : null}
    </Card>
  );
}

function PickItemSheet({
  visible,
  storeId,
  currency,
  onClose,
  onPick,
}: {
  visible: boolean;
  storeId: string;
  currency: Currency;
  onClose: () => void;
  onPick: (p: Product) => void;
}) {
  const [search, setSearch] = useState('');
  const q = useData(() => listProducts(storeId), [storeId, visible], visible);
  const list = useMemo(() => {
    const s = search.trim().toLowerCase();
    return (q.data ?? []).filter((p) => !s || p.name.toLowerCase().includes(s));
  }, [q.data, search]);

  return (
    <Sheet visible={visible} onClose={onClose} title="Which item was bought">
      <Input icon="search" value={search} onChangeText={setSearch} placeholder="Search your items" />
      {q.loading && !q.data ? (
        <Loading />
      ) : list.length === 0 ? (
        <Text v="body" center color={colors.muted} style={{ marginVertical: 20 }}>
          {(q.data ?? []).length === 0 ? 'Add an item in Stock first.' : 'Nothing matches.'}
        </Text>
      ) : (
        list.map((p) => {
          const s = stockInfo(p);
          return (
            <Pressable
              key={p.id}
              onPress={() => onPick(p)}
              disabled={s.out}
              accessibilityRole="button"
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 12,
                padding: 10,
                marginBottom: 8,
                backgroundColor: colors.card,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: radius.md,
                opacity: s.out ? 0.45 : 1,
              }}
            >
              <ProductImage uri={p.image_url} style={{ width: 46, height: 46, borderRadius: 10 }} />
              <View style={{ flex: 1 }}>
                <Text v="bodyMed" numberOfLines={1}>
                  {p.name}
                </Text>
                <Text v="tiny" color={s.color}>
                  {s.label}
                </Text>
              </View>
              <Text v="numSm" color={colors.pinkLight}>
                {money(p.price, currency)}
              </Text>
            </Pressable>
          );
        })
      )}
    </Sheet>
  );
}
