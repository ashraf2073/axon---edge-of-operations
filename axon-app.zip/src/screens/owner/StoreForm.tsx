import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Alert, Pressable, Share, View } from 'react-native';
import { createStore, deleteStore, updateStore, type StoreInput } from '../../api/owner';
import { STORE_KINDS } from '../../lib/content';
import { friendly } from '../../lib/errors';
import { CURRENCIES } from '../../lib/format';
import { deleteImageByUrl, pickImage, uploadImage } from '../../lib/images';
import { toast } from '../../lib/toast';
import type { RootParams } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors, radius } from '../../theme';
import type { Currency, StoreKind } from '../../types';
import { Button } from '../../ui/Button';
import { Chip, ChipWrap } from '../../ui/Chips';
import { MenuRow, Notice } from '../../ui/Fields';
import { Icon } from '../../ui/Icon';
import { Input } from '../../ui/Input';
import { Card } from '../../ui/Layout';
import { ProductImage } from '../../ui/Product';
import { Header, Screen } from '../../ui/Screen';
import { Sheet } from '../../ui/Sheet';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'StoreForm' | 'StoreSetup'>;

/** Used twice: as the first-run business setup, and to add or edit a business later. */
export function StoreFormScreen({ navigation, route }: Props) {
  const gate = route.name === 'StoreSetup';
  const editId = route.name === 'StoreForm' ? route.params?.id : undefined;

  const profile = useSession((s) => s.profile);
  const stores = useSession((s) => s.stores);
  const upsertStore = useSession((s) => s.upsertStore);
  const setActiveStore = useSession((s) => s.setActiveStore);
  const removeStore = useSession((s) => s.removeStore);
  const signOut = useSession((s) => s.signOut);
  const existing = editId ? (stores.find((s) => s.id === editId) ?? null) : null;

  const [name, setName] = useState(existing?.name ?? '');
  const [kind, setKind] = useState<StoreKind>(existing?.kind ?? 'shop');
  const [description, setDescription] = useState(existing?.description ?? '');
  const [location, setLocation] = useState(existing?.location ?? '');
  const [phone, setPhone] = useState(existing?.phone ?? profile?.phone ?? '');
  const [currency, setCurrency] = useState<Currency>(existing?.currency ?? 'KES');
  const [payment, setPayment] = useState(existing?.payment_info ?? '');
  const [logoUri, setLogoUri] = useState<string | null>(null);
  const [removeLogo, setRemoveLogo] = useState(false);
  const [picker, setPicker] = useState(false);
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [delOpen, setDelOpen] = useState(false);
  const [delText, setDelText] = useState('');
  const [delBusy, setDelBusy] = useState(false);

  if (!profile) return null;
  if (editId && !existing) {
    return (
      <Screen>
        <Header title="Edit business" />
        <Notice tone="warn">
          <Text v="body" color={colors.text}>
            This business no longer exists.
          </Text>
        </Notice>
        <Button title="Go back" onPress={() => navigation.goBack()} />
      </Screen>
    );
  }

  const phoneDigits = phone.replace(/\D/g, '').length;
  const errs = {
    name: name.trim().length < 2 || name.trim().length > 80 ? 'Enter a business name (2 to 80 characters).' : null,
    phone: phone.trim() && phoneDigits < 7 ? 'Enter a valid phone number, or leave it empty.' : null,
  };
  const bad = Object.values(errs).some(Boolean);
  const shownLogo = logoUri ?? (removeLogo ? null : (existing?.logo_url ?? null));

  const choose = async (source: 'library' | 'camera') => {
    setPicker(false);
    try {
      const uri = await pickImage(source);
      if (uri) {
        setLogoUri(uri);
        setRemoveLogo(false);
      }
    } catch (e) {
      toast.error(friendly(e));
    }
  };

  const submit = async () => {
    setTouched(true);
    setError(null);
    if (bad) return;
    setBusy(true);
    const input: StoreInput = {
      name: name.trim(),
      kind,
      description: description.trim(),
      location: location.trim(),
      phone: phone.trim(),
      currency,
      payment_info: payment.trim(),
    };
    let uploaded: string | null = null;
    try {
      if (existing) {
        if (logoUri) {
          uploaded = await uploadImage(existing.id, logoUri);
          input.logo_url = uploaded;
        } else if (removeLogo) {
          input.logo_url = null;
        }
        const saved = await updateStore(existing.id, input);
        if (existing.logo_url && (logoUri || removeLogo)) await deleteImageByUrl(existing.logo_url);
        upsertStore(saved);
        toast.success('Business updated.');
        navigation.goBack();
      } else {
        let saved = await createStore(profile.id, input);
        if (logoUri) {
          try {
            uploaded = await uploadImage(saved.id, logoUri);
            saved = await updateStore(saved.id, { logo_url: uploaded });
          } catch (e) {
            toast.error(`Business created, but the logo could not be saved. ${friendly(e)}`);
          }
        }
        upsertStore(saved);
        setActiveStore(saved.id);
        toast.success(`${saved.name} is ready.`);
        if (!gate) navigation.goBack();
      }
    } catch (e) {
      if (uploaded && existing) await deleteImageByUrl(uploaded);
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  const confirmDelete = async () => {
    if (!existing) return;
    if (delText.trim().toLowerCase() !== existing.name.trim().toLowerCase()) {
      return setError('Type the business name exactly to confirm.');
    }
    setDelBusy(true);
    try {
      await deleteStore(existing);
      removeStore(existing.id);
      setDelOpen(false);
      toast.success('Business deleted.');
      if (navigation.canGoBack()) navigation.goBack();
    } catch (e) {
      setError(friendly(e));
    } finally {
      setDelBusy(false);
    }
  };

  return (
    <Screen>
      <Header
        title={existing ? 'Edit business' : gate ? 'Set up your business' : 'Add a business'}
        subtitle={gate ? 'Last step before you start' : undefined}
        back={!gate}
        right={
          gate ? (
            <Pressable onPress={() => void signOut()} hitSlop={8} accessibilityRole="button">
              <Text v="small" color={colors.blueLight}>
                Sign out
              </Text>
            </Pressable>
          ) : undefined
        }
      />
      {gate ? (
        <Notice tone="info">
          <Text v="body" color={colors.text}>
            Tell AXON about your shop, farm, company or supermarket. You can add more businesses and change all of this later.
          </Text>
        </Notice>
      ) : null}
      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}

      <Pressable
        onPress={() => setPicker(true)}
        accessibilityRole="button"
        accessibilityLabel="Add or change the logo"
        style={{
          alignSelf: 'center',
          width: 110,
          height: 110,
          borderRadius: radius.xl,
          overflow: 'hidden',
          borderWidth: 1,
          borderColor: colors.border2,
          marginBottom: 6,
        }}
      >
        <ProductImage uri={shownLogo} style={{ width: '100%', height: '100%' }} />
        <View
          style={{
            position: 'absolute',
            right: 6,
            bottom: 6,
            width: 30,
            height: 30,
            borderRadius: 15,
            backgroundColor: colors.pink,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name="camera" size={15} color={colors.white} />
        </View>
      </Pressable>
      <Text v="small" center style={{ marginBottom: 16 }}>
        Business logo or picture (optional)
      </Text>

      <Input
        label="Business name"
        icon="briefcase"
        value={name}
        onChangeText={setName}
        placeholder="e.g. Mama Njeri Farm"
        maxLength={80}
        error={touched ? errs.name : null}
      />

      <Text v="label" style={{ marginBottom: 8 }}>
        Type of business
      </Text>
      <ChipWrap>
        {STORE_KINDS.map((k) => (
          <Chip key={k.key} label={k.label} selected={kind === k.key} onPress={() => setKind(k.key)} />
        ))}
      </ChipWrap>
      <View style={{ height: 14 }} />

      <Input
        label="About the business (optional)"
        value={description}
        onChangeText={setDescription}
        multiline
        maxLength={400}
        placeholder="What you sell and what makes you special"
      />
      <Input label="Location (optional)" icon="map-pin" value={location} onChangeText={setLocation} maxLength={80} placeholder="Town or area" />
      <Input
        label="Business phone (optional)"
        icon="phone"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
        error={touched ? errs.phone : null}
        hint="Customers can tap it to call you."
      />

      <Text v="label" style={{ marginBottom: 8 }}>
        Currency
      </Text>
      <ChipWrap>
        {CURRENCIES.map((c) => (
          <Chip key={c.code} label={`${c.code} (${c.symbol})`} selected={currency === c.code} onPress={() => setCurrency(c.code)} />
        ))}
      </ChipWrap>
      <View style={{ height: 14 }} />

      <Input
        label="How customers should pay (optional)"
        value={payment}
        onChangeText={setPayment}
        multiline
        maxLength={400}
        placeholder="e.g. M-Pesa Till 123456. Cash on pickup."
        hint="Shown to customers at checkout. AXON does not handle the money."
      />

      <Button title={existing ? 'Save changes' : 'Create business'} icon="check" onPress={submit} loading={busy} />

      {existing ? (
        <>
          <Card style={{ marginTop: 18 }}>
            <Text v="label">Store code</Text>
            <Text v="num" color={colors.pinkLight}>
              {existing.code}
            </Text>
            <Text v="small" style={{ marginTop: 4, marginBottom: 10 }}>
              Customers can find this business by its name or this code.
            </Text>
            <Button
              title="Share store code"
              icon="share-2"
              size="sm"
              variant="outline"
              full={false}
              onPress={() =>
                void Share.share({
                  message: `Shop at ${existing.name} on AXON. Open the AXON app and search for the code ${existing.code}.`,
                }).catch(() => undefined)
              }
            />
          </Card>
          <Button
            title="Delete this business"
            variant="danger"
            icon="trash-2"
            onPress={() => {
              setDelText('');
              setError(null);
              setDelOpen(true);
            }}
            style={{ marginTop: 14 }}
          />
        </>
      ) : null}

      <Sheet visible={picker} onClose={() => setPicker(false)} title="Logo or picture">
        <MenuRow icon="camera" label="Take a photo" onPress={() => void choose('camera')} color={colors.pink} />
        <MenuRow icon="image" label="Choose from gallery" onPress={() => void choose('library')} />
        {shownLogo ? (
          <MenuRow
            icon="trash-2"
            label="Remove picture"
            danger
            onPress={() => {
              setLogoUri(null);
              setRemoveLogo(true);
              setPicker(false);
            }}
          />
        ) : null}
        <View style={{ height: 8 }} />
      </Sheet>

      <Sheet visible={delOpen} onClose={() => !delBusy && setDelOpen(false)} title="Delete business">
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            This permanently deletes {existing?.name}, with all its items, pictures, sales, expenses and customer orders. This can not be undone.
          </Text>
        </Notice>
        {error ? (
          <Notice tone="warn">
            <Text v="body" color={colors.text}>
              {error}
            </Text>
          </Notice>
        ) : null}
        <Input label="Type the business name to confirm" value={delText} onChangeText={setDelText} autoCorrect={false} />
        <Button title="Delete everything" variant="danger" icon="trash-2" onPress={confirmDelete} loading={delBusy} />
        <View style={{ height: 8 }} />
      </Sheet>
    </Screen>
  );
}
