import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { listProducts } from '../../lib/ownerData';
import { cardWidth } from '../../lib/layout';
import { useData } from '../../lib/useData';
import type { OwnerNav } from '../../nav/types';
import { useBiz } from '../../state/biz';
import { useActiveStore } from '../../state/session';
import { colors } from '../../theme';
import type { Product } from '../../types';
import { Button } from '../../ui/Button';
import { Chip, ChipRow } from '../../ui/Chips';
import { Input } from '../../ui/Input';
import { Row } from '../../ui/Layout';
import { OwnerFrame } from '../../ui/OwnerFrame';
import { OwnerProductCard } from '../../ui/Product';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';
import { SellSheet } from './SellSheet';

const PAGE = 40;

export function StockScreen() {
  const nav = useNavigation<OwnerNav>();
  const store = useActiveStore();
  const version = useBiz((s) => s.version);
  const { width } = useWindowDimensions();
  const q = useData(() => listProducts(store!.id), [store?.id, version], !!store);
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('All');
  const [sell, setSell] = useState<Product | null>(null);
  const [shown, setShown] = useState(PAGE);

  const items = q.data ?? [];
  const categories = useMemo(() => ['All', ...Array.from(new Set(items.map((p) => p.category))).sort()], [items]);
  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return items.filter(
      (p) => (cat === 'All' || p.category === cat) && (!s || p.name.toLowerCase().includes(s) || p.category.toLowerCase().includes(s)),
    );
  }, [items, search, cat]);

  if (!store) return null;
  const w = cardWidth(width);
  const low = items.filter((p) => p.track_stock && p.low_alert > 0 && p.stock <= p.low_alert).length;

  return (
    <OwnerFrame onRefresh={q.refresh} refreshing={q.refreshing}>
      <Row justify="space-between" style={{ marginBottom: 12 }}>
        <View style={{ flex: 1 }}>
          <Text v="h1">Stock</Text>
          <Text v="small">
            {items.length} {items.length === 1 ? 'item' : 'items'}
            {low > 0 ? `, ${low} low` : ''}
          </Text>
        </View>
        <Button title="Add item" icon="plus" size="sm" full={false} onPress={() => nav.navigate('ProductForm')} />
      </Row>

      {q.loading && !q.data ? (
        <Loading label="Loading your items" />
      ) : q.error && !q.data ? (
        <ErrorState message={q.error} onRetry={q.reload} />
      ) : items.length === 0 ? (
        <EmptyState
          icon="package"
          title="No items yet"
          body="Add goods, farm produce, animals or services. Each one gets a picture, a price and a stock level."
          actionLabel="Add your first item"
          onAction={() => nav.navigate('ProductForm')}
        />
      ) : (
        <>
          <Input
            icon="search"
            value={search}
            onChangeText={(t) => {
              setSearch(t);
              setShown(PAGE);
            }}
            placeholder="Search your items"
            containerStyle={{ marginBottom: 8 }}
          />
          {categories.length > 2 ? (
            <ChipRow>
              {categories.map((c) => (
                <Chip
                  key={c}
                  label={c}
                  selected={cat === c}
                  onPress={() => {
                    setCat(c);
                    setShown(PAGE);
                  }}
                />
              ))}
            </ChipRow>
          ) : null}
          <View style={{ height: 10 }} />

          {filtered.length === 0 ? (
            <Text v="body" center style={{ marginTop: 24 }} color={colors.muted}>
              Nothing matches your search.
            </Text>
          ) : (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
              {filtered.slice(0, shown).map((p) => (
                <OwnerProductCard
                  key={p.id}
                  p={p}
                  currency={store.currency}
                  width={w}
                  onPress={() => nav.navigate('ProductForm', { id: p.id })}
                  onSell={() => setSell(p)}
                />
              ))}
            </View>
          )}
          {filtered.length > shown ? (
            <Button
              title={`Show more (${filtered.length - shown} left)`}
              variant="outline"
              size="sm"
              onPress={() => setShown((n) => n + PAGE)}
              style={{ marginTop: 16 }}
            />
          ) : null}
        </>
      )}

      <SellSheet product={sell} store={store} onClose={() => setSell(null)} />
    </OwnerFrame>
  );
}
