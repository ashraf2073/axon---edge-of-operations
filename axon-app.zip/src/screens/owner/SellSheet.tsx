import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { friendly } from '../../lib/errors';
import { money, num, parseNumber } from '../../lib/format';
import { submitSale } from '../../lib/ownerData';
import { toast } from '../../lib/toast';
import { useSession } from '../../state/session';
import { colors } from '../../theme';
import type { Product, Store } from '../../types';
import { Button } from '../../ui/Button';
import { DateField } from '../../ui/DateField';
import { Notice } from '../../ui/Fields';
import { Input } from '../../ui/Input';
import { Row } from '../../ui/Layout';
import { ProductImage, QtyStepper, stockInfo } from '../../ui/Product';
import { Sheet } from '../../ui/Sheet';
import { Text } from '../../ui/Text';

function sameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

/** The "an item was bought" form: pick how many, confirm the price, save. Stock goes down and revenue goes up. */
export function SellSheet({
  product,
  store,
  onClose,
}: {
  product: Product | null;
  store: Store;
  onClose: () => void;
}) {
  const dateFormat = useSession((s) => s.profile?.date_format ?? 'DD/MM/YYYY');
  const [qty, setQty] = useState(1);
  const [price, setPrice] = useState('');
  const [customer, setCustomer] = useState('');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(new Date());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!product) return;
    setQty(1);
    setPrice(String(product.price));
    setCustomer('');
    setNote('');
    setDate(new Date());
    setError(null);
  }, [product?.id]);

  if (!product) {
    return <Sheet visible={false} onClose={onClose} title="Record a sale" children={null} />;
  }

  const unit = parseNumber(price);
  const priceOk = Number.isFinite(unit) && unit >= 0;
  const total = priceOk ? Math.round(unit * qty * 100) / 100 : 0;
  const s = stockInfo(product);
  const max = product.track_stock ? product.stock : null;

  const save = async () => {
    setError(null);
    if (!priceOk) return setError('Enter a valid price.');
    if (!(qty > 0)) return setError('Quantity must be more than zero.');
    if (max != null && qty > max) return setError(`Only ${num(max, 3)} ${product.unit} in stock.`);
    setBusy(true);
    try {
      const now = new Date();
      const soldAt = sameDay(date, now) ? null : new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0);
      const saved = await submitSale({
        storeId: store.id,
        product,
        qty,
        price: unit,
        customer: customer.trim(),
        note: note.trim(),
        soldAt,
      });
      toast.success(
        saved.queued ? 'Saved on this phone. It will be sent when you are online.' : `Sale recorded. ${saved.txn}`,
      );
      onClose();
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      visible
      onClose={onClose}
      title="Record a sale"
      footer={
        <View>
          <Row justify="space-between" style={{ marginBottom: 10 }}>
            <Text v="body">Total</Text>
            <Text v="num" color={colors.green}>
              {money(total, store.currency)}
            </Text>
          </Row>
          <Button title="Save sale" icon="check" onPress={save} loading={busy} />
        </View>
      }
    >
      <Row gap={12} style={{ marginBottom: 14 }}>
        <ProductImage uri={product.image_url} style={{ width: 64, height: 64, borderRadius: 12 }} />
        <View style={{ flex: 1 }}>
          <Text v="h3" numberOfLines={2}>
            {product.name}
          </Text>
          <Text v="small" color={s.color}>
            {s.label}
          </Text>
        </View>
      </Row>

      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}

      <Text v="label" style={{ marginBottom: 6 }}>
        How many {product.unit}
      </Text>
      <View style={{ marginBottom: 14 }}>
        <QtyStepper value={qty} onChange={setQty} min={0.001} max={max} />
      </View>

      <Input
        label={`Price per ${product.unit}`}
        prefix={store.currency}
        value={price}
        onChangeText={setPrice}
        keyboardType="decimal-pad"
        hint="Change it for a discount or a special price. The item price stays the same."
      />
      <Input label="Customer (optional)" icon="user" value={customer} onChangeText={setCustomer} maxLength={80} />
      <Input label="Note (optional)" icon="edit-3" value={note} onChangeText={setNote} maxLength={300} />
      <DateField label="Date of sale" value={date} onChange={setDate} format={dateFormat} />
    </Sheet>
  );
}
