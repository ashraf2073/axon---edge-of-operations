import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React, { useEffect } from 'react';
import type { OwnerTabParams } from '../../nav/types';
import { warmCache } from '../../lib/ownerData';
import { useOwnerOrdersRealtime } from '../../state/realtime';
import { useActiveStore } from '../../state/session';
import { colors, fonts } from '../../theme';
import { Icon, type IconName } from '../../ui/Icon';
import { AnalysisScreen } from './Analysis';
import { CostsScreen } from './Costs';
import { DashboardScreen } from './Dashboard';
import { SalesScreen } from './Sales';
import { StockScreen } from './Stock';

const Tab = createBottomTabNavigator<OwnerTabParams>();

const TABS: { name: keyof OwnerTabParams; title: string; icon: IconName }[] = [
  { name: 'Dash', title: 'Home', icon: 'grid' },
  { name: 'Stock', title: 'Stock', icon: 'package' },
  { name: 'Sales', title: 'Sales', icon: 'shopping-bag' },
  { name: 'Costs', title: 'Costs', icon: 'credit-card' },
  { name: 'Analysis', title: 'Profit', icon: 'bar-chart-2' },
];

const SCREENS = {
  Dash: DashboardScreen,
  Stock: StockScreen,
  Sales: SalesScreen,
  Costs: CostsScreen,
  Analysis: AnalysisScreen,
} as const;

export function OwnerTabs() {
  const store = useActiveStore();
  useOwnerOrdersRealtime(store?.id);

  // keep a complete saved copy of the shop for the times there is no signal
  useEffect(() => {
    if (store?.id) void warmCache(store.id);
  }, [store?.id]);

  return (
    // the key makes every tab start fresh when the owner switches business
    <Tab.Navigator
      key={store?.id}
      initialRouteName="Dash"
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.pink,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: { backgroundColor: colors.dk, borderTopColor: colors.border, borderTopWidth: 1 },
        tabBarLabelStyle: { fontFamily: fonts.ui, fontSize: 10 },
        sceneStyle: { backgroundColor: colors.bg },
      }}
    >
      {TABS.map((t) => (
        <Tab.Screen
          key={t.name}
          name={t.name}
          component={SCREENS[t.name]}
          options={{
            title: t.title,
            tabBarIcon: ({ color, size }) => <Icon name={t.icon} size={size} color={color} />,
          }}
        />
      ))}
    </Tab.Navigator>
  );
}
