import React, { useState } from 'react';
import { Share, View } from 'react-native';
import { getAnalytics } from '../../lib/ownerData';
import { analysisAdvice, totals } from '../../lib/analytics';
import { money, num, PERIODS, periodRange, type Period } from '../../lib/format';
import { useData } from '../../lib/useData';
import { useBiz } from '../../state/biz';
import { useActiveStore } from '../../state/session';
import { colors, expenseColor, expenseLabel, radius, tint } from '../../theme';
import { AdviceCard } from '../../ui/Advice';
import { Button } from '../../ui/Button';
import { BarRow, MonthlyBars } from '../../ui/Charts';
import { Chip, ChipRow } from '../../ui/Chips';
import { Card, Divider, Row, SectionTitle } from '../../ui/Layout';
import { OwnerFrame } from '../../ui/OwnerFrame';
import { ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

export function AnalysisScreen() {
  const store = useActiveStore();
  const version = useBiz((s) => s.version);
  const [period, setPeriod] = useState<Period>('month');
  const range = periodRange(period);
  const q = useData(() => getAnalytics(store!.id, range.from, range.to), [store?.id, version, period], !!store);

  if (!store) return null;
  const cur = store.currency;
  const a = q.data;
  const t = a ? totals(a) : null;
  const advice = a ? analysisAdvice(a, cur) : null;
  const loss = !!t && t.profit < 0;
  const label = PERIODS.find((p) => p.key === period)?.label ?? '';

  const share = () => {
    if (!a || !t) return;
    const lines = [
      `${store.name} - profit and loss (${label})`,
      '',
      `Revenue: ${money(t.revenue, cur)} from ${a.sales_count} sales`,
      ...a.expense_breakdown.map((c) => `  ${expenseLabel(c.category)}: ${money(Number(c.amount), cur)}`),
      `Expenses: ${money(t.expenses, cur)}`,
      `${loss ? 'Loss' : 'Profit'}: ${money(t.profit, cur)}${t.revenue > 0 ? ` (margin ${num(t.margin, 1)}%)` : ''}`,
      '',
      'Made with AXON, edge of operations.',
    ];
    void Share.share({ message: lines.join('\n') }).catch(() => undefined);
  };

  return (
    <OwnerFrame onRefresh={q.refresh} refreshing={q.refreshing}>
      <Text v="h1">Profit and loss</Text>
      <Text v="small" style={{ marginBottom: 10 }}>
        Sales minus expenses, from your own records
      </Text>
      <ChipRow>
        {PERIODS.map((p) => (
          <Chip key={p.key} label={p.label} selected={period === p.key} onPress={() => setPeriod(p.key)} />
        ))}
      </ChipRow>
      <View style={{ height: 12 }} />

      {q.loading && !a ? (
        <Loading label="Working out your numbers" />
      ) : q.error && !a ? (
        <ErrorState message={q.error} onRetry={q.reload} />
      ) : a && t ? (
        <>
          <View
            style={{
              backgroundColor: tint(loss ? colors.red : colors.green, 0.08),
              borderColor: tint(loss ? colors.red : colors.green, 0.3),
              borderWidth: 1,
              borderRadius: radius.xl,
              padding: 16,
            }}
          >
            <Text v="label">{loss ? 'Net loss' : 'Net profit'}</Text>
            <Text
              style={{ fontFamily: 'Syne_800ExtraBold', fontSize: 32, color: loss ? colors.red : colors.green, marginTop: 4 }}
              numberOfLines={1}
              adjustsFontSizeToFit
            >
              {money(t.profit, cur)}
            </Text>
            <Text v="small" style={{ marginTop: 2 }}>
              {t.revenue > 0 ? `Margin ${num(t.margin, 1)}% of revenue` : 'No sales in this period'}
            </Text>
          </View>

          <SectionTitle title="Statement" />
          <Card>
            <Row justify="space-between">
              <View style={{ flex: 1 }}>
                <Text v="bodyMed">Revenue</Text>
                <Text v="tiny">
                  {a.sales_count} sales, {num(a.units, 3)} units
                </Text>
              </View>
              <Text v="numSm" color={colors.green}>
                {money(t.revenue, cur)}
              </Text>
            </Row>
            <Divider />
            <Text v="label" style={{ marginBottom: 8 }}>
              Less expenses
            </Text>
            {a.expense_breakdown.length === 0 ? (
              <Text v="small">No expenses in this period.</Text>
            ) : (
              a.expense_breakdown.map((c) => (
                <Row key={c.category} justify="space-between" style={{ marginBottom: 6 }}>
                  <Row gap={8} style={{ flex: 1 }}>
                    <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: expenseColor(c.category) }} />
                    <Text v="body" numberOfLines={1} style={{ flex: 1 }}>
                      {expenseLabel(c.category)}
                    </Text>
                  </Row>
                  <Text v="bold" color={colors.red}>
                    {money(Number(c.amount), cur)}
                  </Text>
                </Row>
              ))
            )}
            <Row justify="space-between" style={{ marginTop: 4 }}>
              <Text v="bodyMed">Total expenses</Text>
              <Text v="numSm" color={colors.red}>
                {money(t.expenses, cur)}
              </Text>
            </Row>
            <Divider />
            <Row justify="space-between">
              <Text v="h3">{loss ? 'Net loss' : 'Net profit'}</Text>
              <Text v="num" color={loss ? colors.red : colors.green}>
                {money(t.profit, cur)}
              </Text>
            </Row>
          </Card>

          {advice ? (
            <>
              <SectionTitle title="AXON analysis" />
              <AdviceCard advice={advice} />
            </>
          ) : null}

          {a.top_products.length > 0 ? (
            <>
              <SectionTitle title="Best sellers" />
              <Card>
                {a.top_products.map((p) => (
                  <BarRow
                    key={p.name}
                    label={p.name}
                    sub={`${num(p.units, 3)} sold`}
                    amount={Number(p.revenue)}
                    pct={t.revenue > 0 ? (Number(p.revenue) / t.revenue) * 100 : 0}
                    color={colors.blueLight}
                    currency={cur}
                  />
                ))}
              </Card>
            </>
          ) : null}

          {a.expense_breakdown.length > 0 ? (
            <>
              <SectionTitle title="Spending by category" />
              <Card>
                {a.expense_breakdown.map((c) => (
                  <BarRow
                    key={c.category}
                    label={expenseLabel(c.category)}
                    amount={Number(c.amount)}
                    pct={t.expenses > 0 ? (Number(c.amount) / t.expenses) * 100 : 0}
                    color={expenseColor(c.category)}
                    currency={cur}
                  />
                ))}
              </Card>
            </>
          ) : null}

          <SectionTitle title="Last 6 months" />
          <Card>
            <MonthlyBars data={a.monthly} currency={cur} />
          </Card>

          <Button title="Share this report" icon="share-2" variant="outline" onPress={share} style={{ marginTop: 18 }} />
        </>
      ) : null}
    </OwnerFrame>
  );
}
