import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React from 'react';
import { Alert, View } from 'react-native';
import { discardQueued } from '../../lib/ownerData';
import { formatDate, formatDateTime, money, num } from '../../lib/format';
import { toast } from '../../lib/toast';
import type { RootParams } from '../../nav/types';
import { checkConnection, useNet } from '../../state/net';
import { useOutbox, type OutboxItem } from '../../state/outbox';
import { useSession } from '../../state/session';
import { syncNow } from '../../state/sync';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Chips';
import { Notice } from '../../ui/Fields';
import { Card, Row } from '../../ui/Layout';
import { Header, Screen } from '../../ui/Screen';
import { EmptyState } from '../../ui/States';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Outbox'>;

function title(i: OutboxItem): string {
  return i.kind === 'sale' ? `${i.sale.productName} x ${num(i.sale.qty, 3)} ${i.sale.unit}` : i.expense.description || i.expense.category;
}

/** Everything saved on this phone that has not reached the cloud yet. */
export function OutboxScreen(_props: Props) {
  const uid = useSession((s) => s.profile?.id);
  const stores = useSession((s) => s.stores);
  const fmt = useSession((s) => s.profile?.date_format ?? 'DD/MM/YYYY');
  const online = useNet((s) => s.online);
  const syncing = useOutbox((s) => s.syncing);
  const all = useOutbox((s) => s.items);
  const items = all.filter((i) => i.ownerId === uid).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  const [busy, setBusy] = React.useState(false);

  const sendNow = async () => {
    setBusy(true);
    try {
      const ok = await checkConnection();
      if (!ok) {
        toast.info('Still offline. Your items are safe on this phone and will be sent when the connection returns.');
        return;
      }
      await syncNow();
    } finally {
      setBusy(false);
    }
  };

  const remove = (i: OutboxItem) => {
    Alert.alert('Remove this saved item?', `${title(i)} has not been sent yet. Removing it means it will never be recorded.`, [
      { text: 'Keep it', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          void discardQueued(i.id).then(() => toast.success('Removed.'));
        },
      },
    ]);
  };

  return (
    <Screen>
      <Header title="Waiting to send" />
      <Notice tone={online ? 'info' : 'warn'} icon={online ? 'upload-cloud' : 'wifi-off'}>
        <Text v="body" color={colors.text}>
          {online
            ? 'Saved items are sent automatically, oldest first. Each one is counted once, even if the signal drops while sending.'
            : 'You are offline. Sales and expenses you add are saved on this phone and sent as soon as the connection is back.'}
        </Text>
      </Notice>

      {items.length === 0 ? (
        <EmptyState
          icon="check-circle"
          title="Nothing is waiting"
          body="When you record a sale or an expense without signal, it is kept here until it reaches the cloud."
        />
      ) : (
        <>
          <Button title="Send now" icon="upload-cloud" onPress={() => void sendNow()} loading={busy || syncing} style={{ marginBottom: 12 }} />
          {items.map((i) => {
            const cur = stores.find((s) => s.id === i.storeId)?.currency ?? 'KES';
            const amount = i.kind === 'sale' ? i.sale.qty * i.sale.price : i.expense.amount;
            const failed = i.status === 'failed';
            return (
              <Card key={i.id} accent={failed ? colors.red : colors.amber} style={{ marginBottom: 8 }}>
                <Row justify="space-between" align="flex-start">
                  <View style={{ flex: 1 }}>
                    <Text v="bodyMed" numberOfLines={2}>
                      {title(i)}
                    </Text>
                    <Text v="tiny">
                      {i.kind === 'sale' ? `Sale / ${formatDateTime(i.sale.soldAt, fmt)}` : `Expense / ${formatDate(i.expense.spentOn, fmt)}`}
                    </Text>
                  </View>
                  <View style={{ alignItems: 'flex-end', gap: 6 }}>
                    <Text v="numSm" color={i.kind === 'sale' ? colors.green : colors.red}>
                      {money(amount, cur)}
                    </Text>
                    <Badge label={failed ? 'Not saved' : 'Waiting'} color={failed ? colors.red : colors.amber} />
                  </View>
                </Row>
                {failed && i.error ? (
                  <Text v="small" color={colors.red} style={{ marginTop: 8 }}>
                    {i.error}
                  </Text>
                ) : null}
                <Row gap={8} style={{ marginTop: 10 }}>
                  {failed ? (
                    <Button title="Try again" size="sm" variant="outline" full={false} onPress={() => void useOutbox.getState().retry(i.id)} />
                  ) : null}
                  <Button title="Remove" size="sm" variant="danger" full={false} onPress={() => remove(i)} />
                </Row>
              </Card>
            );
          })}
        </>
      )}
    </Screen>
  );
}
