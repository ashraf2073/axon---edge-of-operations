import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { Share, View } from 'react-native';
import { getAnalytics } from '../../lib/ownerData';
import { analysisAdvice, totals } from '../../lib/analytics';
import { storeKindLabel } from '../../lib/content';
import { firstName, money, num } from '../../lib/format';
import { useData } from '../../lib/useData';
import type { OwnerNav } from '../../nav/types';
import { useBiz } from '../../state/biz';
import { useActiveStore, useSession } from '../../state/session';
import { colors, radius, tint } from '../../theme';
import { AdviceCard } from '../../ui/Advice';
import { Button } from '../../ui/Button';
import { MonthlyBars, BarRow } from '../../ui/Charts';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { OwnerFrame } from '../../ui/OwnerFrame';
import { ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

export function DashboardScreen() {
  const nav = useNavigation<OwnerNav>();
  const store = useActiveStore();
  const profile = useSession((s) => s.profile);
  const version = useBiz((s) => s.version);
  const q = useData(() => getAnalytics(store!.id), [store?.id, version], !!store);

  if (!store) return null;
  const a = q.data;
  const t = a ? totals(a) : null;
  const cur = store.currency;
  const advice = a ? analysisAdvice(a, cur) : null;
  const loss = !!t && t.profit < 0;

  return (
    <OwnerFrame onRefresh={q.refresh} refreshing={q.refreshing}>
      <View style={{ marginBottom: 16 }}>
        <Text v="label">Hello, {firstName(profile?.full_name ?? '') || 'there'}</Text>
        <Text v="h1" numberOfLines={1}>
          {store.name}
        </Text>
        <Text v="small">
          {storeKindLabel(store.kind)}
          {store.location ? ` / ${store.location}` : ''}
        </Text>
      </View>

      {q.loading && !a ? (
        <Loading label="Loading your numbers" />
      ) : q.error && !a ? (
        <ErrorState message={q.error} onRetry={q.reload} />
      ) : a && t ? (
        <>
          <View
            style={{
              backgroundColor: tint(loss ? colors.red : colors.green, 0.08),
              borderColor: tint(loss ? colors.red : colors.green, 0.3),
              borderWidth: 1,
              borderRadius: radius.xl,
              padding: 16,
            }}
          >
            <Text v="label">{loss ? 'Loss, all time' : 'Profit, all time'}</Text>
            <Text style={{ fontFamily: 'Syne_800ExtraBold', fontSize: 32, color: loss ? colors.red : colors.green, marginTop: 4 }} numberOfLines={1} adjustsFontSizeToFit>
              {money(t.profit, cur)}
            </Text>
            <Text v="small" style={{ marginTop: 2 }}>
              Revenue minus expenses{t.revenue > 0 ? `. Margin ${num(t.margin, 1)}%` : ''}
            </Text>
          </View>

          <Row gap={10} style={{ marginTop: 10 }}>
            <Card style={{ flex: 1 }}>
              <Text v="label">Revenue</Text>
              <Text v="num" color={colors.green} numberOfLines={1} adjustsFontSizeToFit>
                {money(t.revenue, cur, true)}
              </Text>
              <Text v="tiny">{a.sales_count} sales</Text>
            </Card>
            <Card style={{ flex: 1 }}>
              <Text v="label">Expenses</Text>
              <Text v="num" color={colors.red} numberOfLines={1} adjustsFontSizeToFit>
                {money(t.expenses, cur, true)}
              </Text>
              <Text v="tiny">{a.expense_breakdown.length} categories</Text>
            </Card>
          </Row>

          <Row gap={8} style={{ marginTop: 14 }}>
            <View style={{ flex: 1 }}>
              <Button title="Sell" icon="shopping-bag" size="sm" variant="blue" onPress={() => nav.navigate('Stock')} />
            </View>
            <View style={{ flex: 1 }}>
              <Button title="Add cost" icon="credit-card" size="sm" variant="outline" onPress={() => nav.navigate('Costs')} />
            </View>
            <View style={{ flex: 1 }}>
              <Button title="Add item" icon="plus" size="sm" variant="outline" onPress={() => nav.navigate('ProductForm')} />
            </View>
          </Row>

          {a.new_orders > 0 ? (
            <View style={{ marginTop: 14 }}>
              <Card accent={colors.pink} onPress={() => nav.navigate('Sales', { segment: 'orders' })}>
                <Text v="h3" color={colors.pinkLight}>
                  {a.new_orders} new customer {a.new_orders === 1 ? 'order' : 'orders'}
                </Text>
                <Text v="small">Tap to accept or complete them.</Text>
              </Card>
            </View>
          ) : null}

          {a.low_stock.length > 0 ? (
            <View style={{ marginTop: 10 }}>
              <Card accent={colors.amber} onPress={() => nav.navigate('Stock')}>
                <Text v="h3" color={colors.amber}>
                  Low stock
                </Text>
                {a.low_stock.slice(0, 4).map((p) => (
                  <Text key={p.id} v="small">
                    {p.name}: {num(p.stock, 3)} {p.unit} left
                  </Text>
                ))}
                {a.low_stock.length > 4 ? <Text v="small">and {a.low_stock.length - 4} more</Text> : null}
              </Card>
            </View>
          ) : null}

          {advice ? (
            <View style={{ marginTop: 14 }}>
              <AdviceCard advice={advice} />
            </View>
          ) : null}

          <SectionTitle title="Last 6 months" />
          <Card>
            <MonthlyBars data={a.monthly} currency={cur} />
          </Card>

          {a.top_products.length > 0 ? (
            <>
              <SectionTitle title="Best sellers" action="Full report" onAction={() => nav.navigate('Analysis')} />
              <Card>
                {a.top_products.map((p) => (
                  <BarRow
                    key={p.name}
                    label={p.name}
                    sub={`${num(p.units, 3)} sold`}
                    amount={p.revenue}
                    pct={t.revenue > 0 ? (p.revenue / t.revenue) * 100 : 0}
                    color={colors.blueLight}
                    currency={cur}
                  />
                ))}
              </Card>
            </>
          ) : null}

          <SectionTitle title="Your store code" />
          <Card>
            <Text v="num" color={colors.pinkLight}>
              {store.code}
            </Text>
            <Text v="small" style={{ marginTop: 4, marginBottom: 10 }}>
              Customers find your store in the AXON app by its name or this code.
            </Text>
            <Button
              title="Share store code"
              icon="share-2"
              size="sm"
              variant="outline"
              full={false}
              onPress={() =>
                void Share.share({
                  message: `Shop at ${store.name} on AXON. Open the AXON app and search for the code ${store.code}.`,
                }).catch(() => undefined)
              }
            />
          </Card>
        </>
      ) : null}
    </OwnerFrame>
  );
}
