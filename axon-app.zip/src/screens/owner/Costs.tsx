import React, { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { deleteExpense } from '../../api/owner';
import { friendly } from '../../lib/errors';
import { formatDate, money, parseNumber, toDateKey } from '../../lib/format';
import { toast } from '../../lib/toast';
import { discardQueued, getAnalytics, isQueuedRow, listExpenses, submitExpense } from '../../lib/ownerData';
import { useData } from '../../lib/useData';
import { useBiz } from '../../state/biz';
import { useActiveStore, useSession } from '../../state/session';
import { colors, EXPENSE_CATEGORIES, expenseColor, expenseLabel } from '../../theme';
import type { Currency } from '../../types';
import { Button } from '../../ui/Button';
import { BarRow } from '../../ui/Charts';
import { Chip, ChipWrap } from '../../ui/Chips';
import { DateField } from '../../ui/DateField';
import { Notice } from '../../ui/Fields';
import { Icon } from '../../ui/Icon';
import { Input } from '../../ui/Input';
import { Card, Row, SectionTitle } from '../../ui/Layout';
import { OwnerFrame } from '../../ui/OwnerFrame';
import { Sheet } from '../../ui/Sheet';
import { EmptyState, ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

export function CostsScreen() {
  const store = useActiveStore();
  const fmt = useSession((s) => s.profile?.date_format ?? 'DD/MM/YYYY');
  const version = useBiz((s) => s.version);
  const bump = useBiz((s) => s.bump);
  const [limit, setLimit] = useState(100);
  const [open, setOpen] = useState(false);
  const list = useData(() => listExpenses(store!.id, limit), [store?.id, version, limit], !!store);
  const stats = useData(() => getAnalytics(store!.id), [store?.id, version], !!store);

  if (!store) return null;
  const cur = store.currency;
  const total = Number(stats.data?.expenses ?? 0);
  const revenue = Number(stats.data?.revenue ?? 0);

  const remove = (id: string, label: string) => {
    if (isQueuedRow(id)) {
      Alert.alert('Remove this saved expense?', `${label} has not been sent yet. Removing it means it will never be recorded.`, [
        { text: 'Keep it', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            void discardQueued(id).then(() => toast.success('Removed.'));
          },
        },
      ]);
      return;
    }
    Alert.alert('Delete this expense?', `${label} will be removed and your profit will go up by that amount.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteExpense(id);
            bump();
            toast.success('Expense deleted.');
          } catch (e) {
            toast.error(friendly(e));
          }
        },
      },
    ]);
  };

  return (
    <OwnerFrame
      onRefresh={() => {
        list.refresh();
        stats.reload();
      }}
      refreshing={list.refreshing}
    >
      <Row justify="space-between" style={{ marginBottom: 12 }}>
        <View style={{ flex: 1 }}>
          <Text v="h1">Costs</Text>
          <Text v="small">Rent, wages, stock, tax and more</Text>
        </View>
        <Button title="Add expense" icon="plus" size="sm" full={false} onPress={() => setOpen(true)} />
      </Row>

      {stats.data ? (
        <Card style={{ marginBottom: 6 }}>
          <Row justify="space-between">
            <View>
              <Text v="label">Total spent</Text>
              <Text v="num" color={colors.red}>
                {money(total, cur)}
              </Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text v="label">Revenue</Text>
              <Text v="num" color={colors.green}>
                {money(revenue, cur)}
              </Text>
            </View>
          </Row>
          <Text v="small" style={{ marginTop: 8 }}>
            Profit = revenue minus expenses = {money(revenue - total, cur)}
          </Text>
        </Card>
      ) : null}

      {stats.data && stats.data.expense_breakdown.length > 0 ? (
        <>
          <SectionTitle title="Where the money goes" />
          <Card>
            {stats.data.expense_breakdown.map((c) => (
              <BarRow
                key={c.category}
                label={expenseLabel(c.category)}
                amount={Number(c.amount)}
                pct={total > 0 ? (Number(c.amount) / total) * 100 : 0}
                color={expenseColor(c.category)}
                currency={cur}
              />
            ))}
          </Card>
        </>
      ) : null}

      <SectionTitle title="Expense history" />
      {list.loading && !list.data ? (
        <Loading label="Loading costs" />
      ) : list.error && !list.data ? (
        <ErrorState message={list.error} onRetry={list.reload} />
      ) : (list.data ?? []).length === 0 ? (
        <EmptyState
          icon="credit-card"
          title="No expenses yet"
          body="Add what you pay for: rent, wages, goods you bought, maintenance, insurance and taxes. Without them your profit is not accurate."
          actionLabel="Add your first expense"
          onAction={() => setOpen(true)}
        />
      ) : (
        <>
          {list.data!.map((e) => (
            <Card key={e.id} accent={e.pending ? colors.amber : expenseColor(e.category)} style={{ marginBottom: 8 }}>
              <Row justify="space-between" align="flex-start">
                <View style={{ flex: 1 }}>
                  <Text v="bodyMed" numberOfLines={2}>
                    {e.description || expenseLabel(e.category)}
                  </Text>
                  <Text v="tiny" numberOfLines={1}>
                    {expenseLabel(e.category)}
                    {e.payee ? ` / ${e.payee}` : ''}
                  </Text>
                  <Text v="tiny">
                    {formatDate(e.spent_on, fmt)}
                    {e.pending ? ' / Waiting to send' : ''}
                  </Text>
                </View>
                <View style={{ alignItems: 'flex-end', gap: 8 }}>
                  <Text v="numSm" color={colors.red}>
                    {money(e.amount, cur)}
                  </Text>
                  <Pressable
                    onPress={() => remove(e.id, e.description || expenseLabel(e.category))}
                    hitSlop={10}
                    accessibilityRole="button"
                    accessibilityLabel="Delete expense"
                  >
                    <Icon name="trash-2" size={16} color={colors.muted} />
                  </Pressable>
                </View>
              </Row>
            </Card>
          ))}
          {list.data!.length >= limit ? (
            <Button title="Load more" variant="outline" size="sm" onPress={() => setLimit((n) => n + 100)} style={{ marginTop: 8 }} />
          ) : null}
        </>
      )}

      <ExpenseSheet visible={open} storeId={store.id} currency={cur} onClose={() => setOpen(false)} />
    </OwnerFrame>
  );
}

function ExpenseSheet({
  visible,
  storeId,
  currency,
  onClose,
}: {
  visible: boolean;
  storeId: string;
  currency: Currency;
  onClose: () => void;
}) {
  const fmt = useSession((s) => s.profile?.date_format ?? 'DD/MM/YYYY');
  const [category, setCategory] = useState('Rent');
  const [description, setDescription] = useState('');
  const [payee, setPayee] = useState('');
  const [qty, setQty] = useState('');
  const [each, setEach] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!visible) return;
    setCategory('Rent');
    setDescription('');
    setPayee('');
    setQty('');
    setEach('');
    setAmount('');
    setDate(new Date());
    setError(null);
  }, [visible]);

  // "20 kg at 20 each" fills the amount for you
  useEffect(() => {
    const q = parseNumber(qty);
    const p = parseNumber(each);
    if (Number.isFinite(q) && Number.isFinite(p) && q > 0 && p >= 0) {
      setAmount(String(Math.round(q * p * 100) / 100));
    }
  }, [qty, each]);

  const save = async () => {
    setError(null);
    const value = parseNumber(amount);
    if (!(Number.isFinite(value) && value > 0)) return setError('Enter the amount you paid.');
    if (description.trim().length < 2) return setError('Say what it was for, for example "Shop rent for May".');
    setBusy(true);
    try {
      const saved = await submitExpense({
        storeId,
        category,
        description: description.trim(),
        payee: payee.trim(),
        amount: value,
        spentOn: toDateKey(date),
      });
      toast.success(
        saved.queued
          ? 'Saved on this phone. It will be sent when you are online.'
          : 'Expense saved. Your profit is updated.',
      );
      onClose();
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Add expense"
      footer={<Button title="Save expense" icon="check" onPress={save} loading={busy} />}
    >
      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}
      <Text v="label" style={{ marginBottom: 8 }}>
        What kind
      </Text>
      <ChipWrap>
        {EXPENSE_CATEGORIES.map((c) => (
          <Chip key={c.key} label={c.key} selected={category === c.key} color={c.color} onPress={() => setCategory(c.key)} />
        ))}
      </ChipWrap>
      <Text v="small" style={{ marginTop: 6, marginBottom: 14 }}>
        {expenseLabel(category)}
      </Text>

      <Input
        label="What was it for"
        value={description}
        onChangeText={setDescription}
        placeholder={category === 'Stock' ? 'e.g. Goat meal, 20 kg' : 'e.g. Shop rent for May'}
        maxLength={120}
      />
      <Input label="Paid to (optional)" icon="user" value={payee} onChangeText={setPayee} maxLength={80} />

      <Text v="label" style={{ marginBottom: 6 }}>
        Bought by quantity? (optional)
      </Text>
      <Row gap={10}>
        <View style={{ flex: 1 }}>
          <Input value={qty} onChangeText={setQty} keyboardType="decimal-pad" placeholder="Quantity" />
        </View>
        <View style={{ flex: 1 }}>
          <Input value={each} onChangeText={setEach} keyboardType="decimal-pad" placeholder="Price each" />
        </View>
      </Row>
      <Input
        label="Total amount paid"
        prefix={currency}
        value={amount}
        onChangeText={setAmount}
        keyboardType="decimal-pad"
        hint="Quantity times price each fills this in for you. You can still change it."
      />
      <DateField label="Date paid" value={date} onChange={setDate} format={fmt} />
      <View style={{ height: 6 }} />
    </Sheet>
  );
}
