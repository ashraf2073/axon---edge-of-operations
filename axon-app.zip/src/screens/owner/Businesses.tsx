import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React from 'react';
import { View } from 'react-native';
import { storeKindLabel } from '../../lib/content';
import type { RootParams } from '../../nav/types';
import { useSession } from '../../state/session';
import { colors } from '../../theme';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Chips';
import { Notice } from '../../ui/Fields';
import { Card, Row } from '../../ui/Layout';
import { ProductImage } from '../../ui/Product';
import { Header, Screen } from '../../ui/Screen';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'Businesses'>;

const MAX_STORES = 10;

export function BusinessesScreen({ navigation }: Props) {
  const stores = useSession((s) => s.stores);
  const activeId = useSession((s) => s.activeStoreId);
  const setActive = useSession((s) => s.setActiveStore);

  return (
    <Screen>
      <Header title="Your businesses" subtitle={`${stores.length} of ${MAX_STORES}`} />
      <Text v="body" style={{ marginBottom: 14 }}>
        Each business has its own items, sales, costs and profit. Switch between them any time.
      </Text>

      {stores.map((s) => {
        const active = s.id === activeId;
        return (
          <Card key={s.id} accent={active ? colors.pink : undefined} style={{ marginBottom: 10 }}>
            <Row gap={12} align="flex-start">
              <ProductImage uri={s.logo_url} style={{ width: 56, height: 56, borderRadius: 14 }} />
              <View style={{ flex: 1 }}>
                <Row justify="space-between">
                  <Text v="h3" numberOfLines={1} style={{ flex: 1 }}>
                    {s.name}
                  </Text>
                  {active ? <Badge label="Open now" color={colors.pink} /> : null}
                </Row>
                <Text v="small" numberOfLines={1}>
                  {storeKindLabel(s.kind)}
                  {s.location ? ` / ${s.location}` : ''}
                </Text>
                <Text v="tiny">Store code {s.code}</Text>
              </View>
            </Row>
            <Row gap={8} style={{ marginTop: 12 }}>
              <View style={{ flex: 1 }}>
                <Button
                  title={active ? 'Go to dashboard' : 'Open this business'}
                  size="sm"
                  variant={active ? 'outline' : 'primary'}
                  onPress={() => {
                    setActive(s.id);
                    navigation.popToTop();
                  }}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Button title="Edit" size="sm" variant="outline" icon="edit-2" onPress={() => navigation.navigate('StoreForm', { id: s.id })} />
              </View>
            </Row>
          </Card>
        );
      })}

      {stores.length >= MAX_STORES ? (
        <Notice tone="info">
          <Text v="body" color={colors.text}>
            You have reached the limit of {MAX_STORES} businesses.
          </Text>
        </Notice>
      ) : (
        <Button title="Add another business" icon="plus" onPress={() => navigation.navigate('StoreForm')} style={{ marginTop: 6 }} />
      )}
    </Screen>
  );
}
