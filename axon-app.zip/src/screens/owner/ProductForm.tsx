import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { getProduct } from '../../api/customer';
import { deleteProduct, saveProduct, type ProductInput } from '../../api/owner';
import { PRODUCT_KINDS } from '../../lib/content';
import { friendly } from '../../lib/errors';
import { money, num, parseNumber } from '../../lib/format';
import { deleteImageByUrl, pickImage, uploadImage } from '../../lib/images';
import { toast } from '../../lib/toast';
import { useData } from '../../lib/useData';
import type { RootParams } from '../../nav/types';
import { useBiz } from '../../state/biz';
import { useActiveStore } from '../../state/session';
import { colors, radius } from '../../theme';
import type { ProductKind } from '../../types';
import { Button } from '../../ui/Button';
import { Chip, ChipWrap } from '../../ui/Chips';
import { MenuRow, Notice, SwitchRow } from '../../ui/Fields';
import { Icon } from '../../ui/Icon';
import { Input } from '../../ui/Input';
import { Card, SectionTitle } from '../../ui/Layout';
import { ProductImage } from '../../ui/Product';
import { Header, Screen } from '../../ui/Screen';
import { Sheet } from '../../ui/Sheet';
import { ErrorState, Loading } from '../../ui/States';
import { Text } from '../../ui/Text';

type Props = NativeStackScreenProps<RootParams, 'ProductForm'>;

const UNITS = ['piece', 'kg', 'litre', 'dozen', 'tray', 'head', 'bag', 'hour'];

const CATEGORY_IDEAS: Record<ProductKind, string[]> = {
  good: ['General', 'Groceries', 'Drinks', 'Household'],
  farm: ['Dairy', 'Eggs', 'Produce', 'Grains'],
  animal: ['Cattle', 'Goats', 'Poultry', 'Sheep'],
  service: ['Delivery', 'Repairs', 'Consulting', 'Labour'],
};

/** Empty means zero for the optional number boxes. */
const n0 = (s: string) => (s.trim() === '' ? 0 : parseNumber(s));

export function ProductFormScreen({ navigation, route }: Props) {
  const id = route.params?.id;
  const store = useActiveStore();
  const bump = useBiz((s) => s.bump);
  const existing = useData(() => getProduct(id!), [id], !!id);

  const [hydrated, setHydrated] = useState(!id);
  const [name, setName] = useState('');
  const [kind, setKind] = useState<ProductKind>('good');
  const [category, setCategory] = useState('General');
  const [description, setDescription] = useState('');
  const [unit, setUnit] = useState('piece');
  const [price, setPrice] = useState('');
  const [cost, setCost] = useState('');
  const [stock, setStock] = useState('0');
  const [track, setTrack] = useState(true);
  const [lowAlert, setLowAlert] = useState('0');
  const [active, setActive] = useState(true);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [removeImage, setRemoveImage] = useState(false);
  const [picker, setPicker] = useState(false);
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const p = existing.data;
    if (!p || hydrated) return;
    setName(p.name);
    setKind(p.kind);
    setCategory(p.category);
    setDescription(p.description);
    setUnit(p.unit);
    setPrice(String(p.price));
    setCost(p.cost ? String(p.cost) : '');
    setStock(String(p.stock));
    setTrack(p.track_stock);
    setLowAlert(String(p.low_alert));
    setActive(p.active);
    setImageUrl(p.image_url);
    setHydrated(true);
  }, [existing.data, hydrated]);

  if (!store) return null;
  const cur = store.currency;

  const priceN = parseNumber(price);
  const costN = n0(cost);
  const stockN = n0(stock);
  const lowN = n0(lowAlert);
  const errs = {
    name: name.trim().length < 1 || name.trim().length > 120 ? 'Enter a name (up to 120 characters).' : null,
    price: !Number.isFinite(priceN) || priceN < 0 ? 'Enter the selling price.' : null,
    cost: !Number.isFinite(costN) || costN < 0 ? 'Enter a number, or leave empty.' : null,
    unit: unit.trim().length < 1 ? 'Enter a unit, for example kg.' : null,
    stock: track && (!Number.isFinite(stockN) || stockN < 0) ? 'Enter how many you have.' : null,
    low: track && (!Number.isFinite(lowN) || lowN < 0) ? 'Enter a number, or 0 for no alert.' : null,
  };
  const bad = Object.values(errs).some(Boolean);
  const show = (k: keyof typeof errs) => (touched ? errs[k] : null);

  const shownImage = imageUri ?? (removeImage ? null : imageUrl);

  const choose = async (source: 'library' | 'camera') => {
    setPicker(false);
    try {
      const uri = await pickImage(source);
      if (uri) {
        setImageUri(uri);
        setRemoveImage(false);
      }
    } catch (e) {
      toast.error(friendly(e));
    }
  };

  const changeKind = (k: ProductKind) => {
    setKind(k);
    if (!id) {
      // a sensible start for each kind; everything stays editable
      setCategory(CATEGORY_IDEAS[k][0]);
      setTrack(k !== 'service');
      setUnit(k === 'animal' ? 'head' : k === 'service' ? 'hour' : k === 'farm' ? 'kg' : 'piece');
    }
  };

  const submit = async () => {
    setTouched(true);
    setError(null);
    if (bad) return;
    setBusy(true);
    let uploaded: string | null = null;
    try {
      let image_url: string | null = removeImage ? null : imageUrl;
      if (imageUri) {
        uploaded = await uploadImage(store.id, imageUri);
        image_url = uploaded;
      }
      const input: ProductInput = {
        name: name.trim(),
        category: category.trim() || 'General',
        kind,
        description: description.trim(),
        unit: unit.trim(),
        price: priceN,
        cost: costN,
        stock: track ? stockN : 0,
        track_stock: track,
        low_alert: track ? lowN : 0,
        image_url,
        active,
      };
      await saveProduct(store.id, input, id);
      const old = existing.data?.image_url;
      if (old && (imageUri || removeImage)) await deleteImageByUrl(old);
      bump();
      toast.success(id ? 'Item updated.' : 'Item added.');
      navigation.goBack();
    } catch (e) {
      if (uploaded) await deleteImageByUrl(uploaded);
      setError(friendly(e));
    } finally {
      setBusy(false);
    }
  };

  const confirmDelete = () => {
    const p = existing.data;
    if (!p) return;
    Alert.alert('Delete this item?', `${p.name} will be removed from your store. Past sales stay in your records.`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteProduct(p);
            bump();
            toast.success('Item deleted.');
            navigation.goBack();
          } catch (e) {
            toast.error(friendly(e));
          }
        },
      },
    ]);
  };

  if (id && existing.loading && !existing.data) {
    return (
      <Screen>
        <Header title="Edit item" />
        <Loading />
      </Screen>
    );
  }
  if (id && existing.error && !existing.data) {
    return (
      <Screen>
        <Header title="Edit item" />
        <ErrorState message={existing.error} onRetry={existing.reload} />
      </Screen>
    );
  }

  const margin = Number.isFinite(priceN) && priceN > 0 && costN > 0 ? priceN - costN : null;

  return (
    <Screen>
      <Header title={id ? 'Edit item' : 'Add item'} subtitle={store.name} />
      {error ? (
        <Notice tone="bad">
          <Text v="body" color={colors.text}>
            {error}
          </Text>
        </Notice>
      ) : null}

      <Pressable
        onPress={() => setPicker(true)}
        accessibilityRole="button"
        accessibilityLabel="Add or change the picture"
        style={{
          alignSelf: 'center',
          width: 168,
          height: 168,
          borderRadius: radius.xl,
          overflow: 'hidden',
          borderWidth: 1,
          borderColor: colors.border2,
          marginBottom: 6,
        }}
      >
        <ProductImage uri={shownImage} style={{ width: '100%', height: '100%' }} />
        <View
          style={{
            position: 'absolute',
            right: 8,
            bottom: 8,
            width: 34,
            height: 34,
            borderRadius: 17,
            backgroundColor: colors.pink,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name="camera" size={17} color={colors.white} />
        </View>
      </Pressable>
      <Text v="small" center style={{ marginBottom: 16 }}>
        Tap to add a picture
      </Text>

      <Text v="label" style={{ marginBottom: 8 }}>
        What is it
      </Text>
      <ChipWrap>
        {PRODUCT_KINDS.map((k) => (
          <Chip key={k.key} label={k.label} selected={kind === k.key} onPress={() => changeKind(k.key)} />
        ))}
      </ChipWrap>
      <Text v="small" style={{ marginTop: 6, marginBottom: 14 }}>
        {PRODUCT_KINDS.find((k) => k.key === kind)?.hint}
      </Text>

      <Input label="Name" value={name} onChangeText={setName} placeholder="e.g. Friesian cow A, or Fresh milk" maxLength={120} error={show('name')} />
      <Input
        label="Description"
        value={description}
        onChangeText={setDescription}
        multiline
        placeholder="Breed, size, quality, how much it produces"
        maxLength={600}
      />

      <Input label="Category" value={category} onChangeText={setCategory} maxLength={40} containerStyle={{ marginBottom: 8 }} />
      <ChipWrap>
        {CATEGORY_IDEAS[kind].map((c) => (
          <Chip key={c} label={c} selected={category === c} onPress={() => setCategory(c)} />
        ))}
      </ChipWrap>
      <View style={{ height: 14 }} />

      <SectionTitle title="Price" style={{ marginTop: 6 }} />
      <Input
        label={`Selling price per ${unit.trim() || 'unit'}`}
        prefix={cur}
        value={price}
        onChangeText={setPrice}
        keyboardType="decimal-pad"
        error={show('price')}
        hint="This is the price customers see. There are no extra fees on top."
      />
      <Input
        label="What it costs you per unit (optional)"
        prefix={cur}
        value={cost}
        onChangeText={setCost}
        keyboardType="decimal-pad"
        error={show('cost')}
        hint={
          margin != null
            ? `Margin per unit: ${money(margin, cur)} (${num((margin / priceN) * 100, 1)}%)`
            : 'Helps you see how much you earn on each sale.'
        }
      />
      <Text v="label" style={{ marginBottom: 8 }}>
        Sold by the
      </Text>
      <ChipWrap>
        {UNITS.map((u) => (
          <Chip key={u} label={u} selected={unit === u} onPress={() => setUnit(u)} />
        ))}
      </ChipWrap>
      <View style={{ height: 8 }} />
      <Input label="Or type your own unit" value={unit} onChangeText={setUnit} maxLength={20} error={show('unit')} />

      <SectionTitle title="Stock" style={{ marginTop: 6 }} />
      <Card>
        <SwitchRow
          label="Keep count of stock"
          hint="Each sale reduces the count. Turn off for services or things you never run out of."
          value={track}
          onChange={setTrack}
        />
        {track ? (
          <>
            <Input
              label={`How many ${unit.trim() || 'units'} do you have now`}
              value={stock}
              onChangeText={setStock}
              keyboardType="decimal-pad"
              error={show('stock')}
            />
            <Input
              label="Warn me when it falls to"
              value={lowAlert}
              onChangeText={setLowAlert}
              keyboardType="decimal-pad"
              error={show('low')}
              hint="Use 0 for no warning."
              containerStyle={{ marginBottom: 0 }}
            />
          </>
        ) : null}
      </Card>

      <View style={{ height: 10 }} />
      <Card>
        <SwitchRow
          label="Show to customers"
          hint="Turn off to hide it from your online store without deleting it."
          value={active}
          onChange={setActive}
        />
      </Card>

      <View style={{ height: 18 }} />
      <Button title={id ? 'Save changes' : 'Add item'} icon="check" onPress={submit} loading={busy} />
      {id && existing.data ? (
        <Button title="Delete item" variant="danger" icon="trash-2" onPress={confirmDelete} style={{ marginTop: 10 }} />
      ) : null}

      <Sheet visible={picker} onClose={() => setPicker(false)} title="Picture">
        <MenuRow icon="camera" label="Take a photo" onPress={() => void choose('camera')} color={colors.pink} />
        <MenuRow icon="image" label="Choose from gallery" onPress={() => void choose('library')} />
        {shownImage ? (
          <MenuRow
            icon="trash-2"
            label="Remove picture"
            danger
            onPress={() => {
              setImageUri(null);
              setRemoveImage(true);
              setPicker(false);
            }}
          />
        ) : null}
        <View style={{ height: 8 }} />
      </Sheet>
    </Screen>
  );
}
