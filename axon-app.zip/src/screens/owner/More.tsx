import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import React from 'react';
import type { RootParams } from '../../nav/types';
import { useOutbox } from '../../state/outbox';
import { useSession } from '../../state/session';
import { colors } from '../../theme';
import { MenuRow } from '../../ui/Fields';
import { SectionTitle } from '../../ui/Layout';
import { Header, Screen } from '../../ui/Screen';

type Props = NativeStackScreenProps<RootParams, 'More'>;

export function MoreScreen({ navigation }: Props) {
  const count = useSession((s) => s.stores.length);
  const uid = useSession((s) => s.profile?.id);
  const saved = useOutbox((s) => s.items.filter((i) => i.ownerId === uid).length);
  return (
    <Screen>
      <Header title="More" />
      <MenuRow
        icon="briefcase"
        label="Your businesses"
        sub={`${count} ${count === 1 ? 'business' : 'businesses'}. Add, edit or switch.`}
        onPress={() => navigation.navigate('Businesses')}
        color={colors.pink}
      />
      <MenuRow
        icon="upload-cloud"
        label="Waiting to send"
        sub={saved === 0 ? 'Nothing is waiting. Sales and expenses saved offline show here.' : `${saved} saved on this phone`}
        onPress={() => navigation.navigate('Outbox')}
        color={colors.amber}
      />
      <MenuRow icon="settings" label="Settings" sub="Profile, password, sign out" onPress={() => navigation.navigate('Settings')} />

      <SectionTitle title="Help" />
      <MenuRow icon="edit-3" label="Suggestions and feedback" sub="Advice for your business and a line to the AXON team" onPress={() => navigation.navigate('Suggestions')} color={colors.green} />
      <MenuRow icon="message-circle" label="Contact us" onPress={() => navigation.navigate('Contact')} color={colors.green} />
      <MenuRow icon="info" label="About AXON" onPress={() => navigation.navigate('About')} />
      <MenuRow icon="file-text" label="Privacy Policy" onPress={() => navigation.navigate('Privacy')} color={colors.purple} />
    </Screen>
  );
}
