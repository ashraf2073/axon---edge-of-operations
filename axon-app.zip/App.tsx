import { DMSans_400Regular, DMSans_500Medium, DMSans_700Bold } from '@expo-google-fonts/dm-sans';
import { Syne_600SemiBold, Syne_700Bold, Syne_800ExtraBold } from '@expo-google-fonts/syne';
import { DarkTheme, NavigationContainer, type Theme } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { IS_CONFIGURED } from './src/config';
import { RootNavigator } from './src/nav/RootNavigator';
import { usePrefs } from './src/state/prefs';
import { useSession } from './src/state/session';
import { useOfflineSync } from './src/state/sync';
import { colors } from './src/theme';
import { Splash } from './src/ui/Splash';
import { ToastHost } from './src/ui/Toast';

// Keep the native splash up until the fonts are ready, so there is no flash of plain text.
SplashScreen.preventAutoHideAsync().catch(() => undefined);

const navTheme: Theme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.bg,
    card: colors.dk,
    border: colors.border,
    text: colors.text,
    primary: colors.pink,
    notification: colors.pink,
  },
};

/** The AXON splash always shows for at least this long when the app opens. */
const MIN_SPLASH_MS = 1600;

export default function App() {
  const [fontsLoaded, fontError] = useFonts({
    Syne_600SemiBold,
    Syne_700Bold,
    Syne_800ExtraBold,
    DMSans_400Regular,
    DMSans_500Medium,
    DMSans_700Bold,
  });
  const [minElapsed, setMinElapsed] = useState(false);
  const prefsLoaded = usePrefs((s) => s.loaded);
  const sessionReady = useSession((s) => s.ready);

  useEffect(() => {
    const t = setTimeout(() => setMinElapsed(true), MIN_SPLASH_MS);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    void usePrefs.getState().load();
  }, []);

  useEffect(() => {
    if (!IS_CONFIGURED) return;
    return useSession.getState().init();
  }, []);

  useOfflineSync(IS_CONFIGURED);

  const fontsDone = fontsLoaded || !!fontError;
  useEffect(() => {
    if (fontsDone) void SplashScreen.hideAsync().catch(() => undefined);
  }, [fontsDone]);

  if (!fontsDone) return null;

  const booting = !minElapsed || !prefsLoaded || (IS_CONFIGURED && !sessionReady);

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      {booting ? (
        <Splash />
      ) : (
        <NavigationContainer theme={navTheme}>
          <RootNavigator />
        </NavigationContainer>
      )}
      <ToastHost />
    </SafeAreaProvider>
  );
}
